#!/bin/sh


REPOBASE="/tmp/smsprj"


CLASSPATH="${REPOBASE}/vinzi/vinzi.sms/0.1.0-SNAPSHOT/vinzi.sms-0.1.0-SNAPSHOT.jar:\
${REPOBASE}/org/apache/ant/ant-launcher/1.7.0/ant-launcher-1.7.0.jar:\
${REPOBASE}/org/clojure/data.zip/0.1.1/data.zip-0.1.1.jar:\
${REPOBASE}/javax/servlet/servlet-api/2.3/servlet-api-2.3.jar:\
${REPOBASE}/org/apache/poi/poi-ooxml/3.9/poi-ooxml-3.9.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-painters/1.6.3/swingx-painters-1.6.3.jar:\
${REPOBASE}/org/fife/ui/rsyntaxtextarea/2.0.4.1/rsyntaxtextarea-2.0.4.1.jar:\
${REPOBASE}/jline/jline/0.9.94/jline-0.9.94.jar:\
${REPOBASE}/org/clojure/core.cache/0.6.3/core.cache-0.6.3.jar:\
${REPOBASE}/commons-collections/commons-collections/3.2/commons-collections-3.2.jar:\
${REPOBASE}/commons-lang/commons-lang/2.4/commons-lang-2.4.jar:\
${REPOBASE}/jaxen/jaxen/1.1/jaxen-1.1.jar:\
${REPOBASE}/org/slf4j/slf4j-api/1.7.5/slf4j-api-1.7.5.jar:\
${REPOBASE}/pentaho/pentaho-bi-platform-engine-core/3.9.0-stable/pentaho-bi-platform-engine-core-3.9.0-stable.jar:\
${REPOBASE}/org/codehaus/groovy/groovy-all/1.5.6/groovy-all-1.5.6.jar:\
${REPOBASE}/vinzi/vinzi.tools/0.2.0-SNAPSHOT/vinzi.tools-0.2.0-SNAPSHOT.jar:\
${REPOBASE}/org/clojure/math.combinatorics/0.0.2/math.combinatorics-0.0.2.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-action/1.6.3/swingx-action-1.6.3.jar:\
${REPOBASE}/org/clojure/data.json/0.2.2/data.json-0.2.2.jar:\
${REPOBASE}/org/postgresql/postgresql/9.2-1003-jdbc4/postgresql-9.2-1003-jdbc4.jar:\
${REPOBASE}/junit/junit/3.8.2/junit-3.8.2.jar:\
${REPOBASE}/com/miglayout/miglayout/3.7.4/miglayout-3.7.4.jar:\
${REPOBASE}/pentaho/pentaho-bi-platform-api/3.9.0-stable/pentaho-bi-platform-api-3.9.0-stable.jar:\
${REPOBASE}/j18n/j18n/1.0.1/j18n-1.0.1.jar:\
${REPOBASE}/xerces/xmlParserAPIs/2.6.2/xmlParserAPIs-2.6.2.jar:\
${REPOBASE}/org/apache/xmlbeans/xmlbeans/2.3.0/xmlbeans-2.3.0.jar:\
${REPOBASE}/org/clojure/data.xml/0.0.7/data.xml-0.0.7.jar:\
${REPOBASE}/com/ambrosebs/dynalint/0.1.1/dynalint-0.1.1.jar:\
${REPOBASE}/vinzi/vinzi.pentaho/0.2.0-SNAPSHOT/vinzi.pentaho-0.2.0-SNAPSHOT.jar:\
${REPOBASE}/org/clojure/core.unify/0.5.3/core.unify-0.5.3.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-autocomplete/1.6.3/swingx-autocomplete-1.6.3.jar:\
${REPOBASE}/org/apache/poi/poi/3.9/poi-3.9.jar:\
${REPOBASE}/org/clojure/core.typed/0.2.34/core.typed-0.2.34.jar:\
${REPOBASE}/org/clojure/core.contracts/0.0.4/core.contracts-0.0.4.jar:\
${REPOBASE}/com/jgoodies/forms/1.2.1/forms-1.2.1.jar:\
${REPOBASE}/org/springframework/spring-context/2.0.8/spring-context-2.0.8.jar:\
${REPOBASE}/commons-logging/commons-logging/1.1.1/commons-logging-1.1.1.jar:\
${REPOBASE}/pentaho/pentaho-bi-platform-util/3.9.0-stable/pentaho-bi-platform-util-3.9.0-stable.jar:\
${REPOBASE}/pentaho/pentaho-xul-core/3.3.1/pentaho-xul-core-3.3.1.jar:\
${REPOBASE}/seesaw/seesaw/1.4.3/seesaw-1.4.3.jar:\
${REPOBASE}/org/springframework/spring-aop/2.0.8/spring-aop-2.0.8.jar:\
${REPOBASE}/jdom/jdom/1.0/jdom-1.0.jar:\
${REPOBASE}/xerces/xercesImpl/2.9.1/xercesImpl-2.9.1.jar:\
${REPOBASE}/pentaho/pentaho-connections/2.2.3/pentaho-connections-2.2.3.jar:\
${REPOBASE}/dom4j/dom4j/1.6.1/dom4j-1.6.1.jar:\
${REPOBASE}/commons-beanutils/commons-beanutils/1.6/commons-beanutils-1.6.jar:\
${REPOBASE}/ch/qos/logback/logback-classic/1.0.13/logback-classic-1.0.13.jar:\
${REPOBASE}/enlive/enlive/1.1.4/enlive-1.1.4.jar:\
${REPOBASE}/mysql/mysql-connector-java/5.1.26/mysql-connector-java-5.1.26.jar:\
${REPOBASE}/xalan/xalan/2.6.0/xalan-2.6.0.jar:\
${REPOBASE}/org/clojure/data.priority-map/0.0.2/data.priority-map-0.0.2.jar:\
${REPOBASE}/slingshot/slingshot/0.10.3/slingshot-0.10.3.jar:\
${REPOBASE}/pentaho/pentaho-actionsequence-dom/2.3.4/pentaho-actionsequence-dom-2.3.4.jar:\
${REPOBASE}/org/clojure/tools.nrepl/0.2.3/tools.nrepl-0.2.3.jar:\
${REPOBASE}/vinzi/vinzi.eis.config/0.2.1-SNAPSHOT/vinzi.eis.config-0.2.1-SNAPSHOT.jar:\
${REPOBASE}/clj-http-lite/clj-http-lite/0.2.0/clj-http-lite-0.2.0.jar:\
${REPOBASE}/org/clojure/tools.logging/0.2.6/tools.logging-0.2.6.jar:\
${REPOBASE}/org/ccil/cowan/tagsoup/tagsoup/1.2.1/tagsoup-1.2.1.jar:\
${REPOBASE}/pentaho/pentaho-bi-platform-engine-services/3.9.0-stable/pentaho-bi-platform-engine-services-3.9.0-stable.jar:\
${REPOBASE}/org/clojure/clojure/1.5.1/clojure-1.5.1.jar:\
${REPOBASE}/vinzi/vinzi.data/0.1.0-SNAPSHOT/vinzi.data-0.1.0-SNAPSHOT.jar:\
${REPOBASE}/clojure-complete/clojure-complete/0.2.3/clojure-complete-0.2.3.jar:\
${REPOBASE}/org/apache/poi/poi-ooxml-schemas/3.9/poi-ooxml-schemas-3.9.jar:\
${REPOBASE}/commons-codec/commons-codec/1.6/commons-codec-1.6.jar:\
${REPOBASE}/org/jsoup/jsoup/1.7.2/jsoup-1.7.2.jar:\
${REPOBASE}/aopalliance/aopalliance/1.0/aopalliance-1.0.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-core/1.6.3/swingx-core-1.6.3.jar:\
${REPOBASE}/org/springframework/security/spring-security-core/2.0.5.RELEASE/spring-security-core-2.0.5.RELEASE.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-plaf/1.6.3/swingx-plaf-1.6.3.jar:\
${REPOBASE}/org/clojure/java.jdbc/0.2.3/java.jdbc-0.2.3.jar:\
${REPOBASE}/org/clojure/data.csv/0.1.2/data.csv-0.1.2.jar:\
${REPOBASE}/org/springframework/spring-core/2.0.8/spring-core-2.0.8.jar:\
${REPOBASE}/org/springframework/spring-support/2.0.8/spring-support-2.0.8.jar:\
${REPOBASE}/org/clojure/jvm.tools.analyzer/0.6.0/jvm.tools.analyzer-0.6.0.jar:\
${REPOBASE}/stax/stax-api/1.0.1/stax-api-1.0.1.jar:\
${REPOBASE}/org/apache/ant/ant/1.7.0/ant-1.7.0.jar:\
${REPOBASE}/xml-apis/xml-apis/1.0.b2/xml-apis-1.0.b2.jar:\
${REPOBASE}/ch/qos/logback/logback-core/1.0.13/logback-core-1.0.13.jar:\
${REPOBASE}/xom/xom/1.0/xom-1.0.jar:\
${REPOBASE}/org/springframework/spring-beans/2.0.8/spring-beans-2.0.8.jar:\
${REPOBASE}/pentaho/pentaho-bi-platform-engine-security/3.9.0-stable/pentaho-bi-platform-engine-security-3.9.0-stable.jar:\
${REPOBASE}/org/clojure/tools.namespace/0.2.4/tools.namespace-0.2.4.jar:\
${REPOBASE}/vinzi/vinzi.cdp/0.2.0-SNAPSHOT/vinzi.cdp-0.2.0-SNAPSHOT.jar:\
${REPOBASE}/com/ibm/icu/icu4j/2.6.1/icu4j-2.6.1.jar:\
${REPOBASE}/postgresql/postgresql/9.1-901-1.jdbc4/postgresql-9.1-901-1.jdbc4.jar:\
${REPOBASE}/org/swinglabs/swingx/swingx-common/1.6.3/swingx-common-1.6.3.jar"



SRCFOLDER="/tmp/smsprj/src"
# NOTE: create folders and add the files.


JVMOPTS=



# OPTION 2: RUN as flexible script (does not require a main)
#   (WARNING: do not start the script twice as the temporary scriptfile
#    will be overwritten!)
#
CSCRIPT=tmp.clj
PARAM="\"sagtest\""
cat >${CSCRIPT} <<EOL
;; check this source
(println "\n loading core.typed")
  (load "clojure/core/typed")
(println "\n Checking matchRecs")
(load "vinzi/sms/matchRecs")
;; loading a source-file
(load-file "src/vinzi/sms/core.clj")
;;  or require a file from the classpath
(require 'vinzi.sms.core)

(in-ns 'vinzi.sms.core)
;; inserting shell-script parameters is easy.
(test-run ${PARAM})
EOL

echo "executing:"
echo "java ${JVMOPTS} -cp ${SRCFOLDER}:${CLASSPATH} clojure.main - < ${CSCRIPT}"
java ${JVMOPTS} -cp ${SRCFOLDER}:${CLASSPATH} clojure.main - < ${CSCRIPT}
#rm ${CSCRIPT}
