(ns vinzi.ctCrash
  (:use [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias Seqable Option 
                                    AnyInteger 
                                    fn> print-env Seq tc-ignore]]])
  (:import [clojure.lang IPersistentList IPersistentVector 
            IPersistentSet IPersistentMap Keyword Symbol]))


(def-alias DbMsg (HMap :mandatory {:nme String} 
                       :optional {:tpe (U Keyword nil)
                                  :constraint String
                                  :default (U Number String nil)
                                  :st_issues (U (IPersistentVector String)
                                                String)
                                  :st_state String
                                  :xt_event_time String
                                  :xt_event_zvl String
                                  :xt_event_time_2 String
                                  :xt_event_zvl_2 String
                                  :xt_msg String
                                  :st_type String
                                  :st_notif String
                                  })) 
(def-alias DbMsgSeq (U nil (Seqable DbMsg)))


(ann mmc-get-time-range [DbMsgSeq -> String])
(defn- mmc-get-time-range [evts]
  (print-env "start mmc-get-time-range")
  (let [res (:xt_event_time (first evts))]
    (print-env "mmc-get-time-range")
    res))

