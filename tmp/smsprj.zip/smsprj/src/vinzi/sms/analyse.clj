(ns vinzi.sms.analyse
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
         [clojure.tools 
         [logging :only [error info trace debug warn]]])
  (:require [clojure 
              [edn :as edn]
              [string :as str]]
            [clojure.java [jdbc :as sql]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vSql :as vSql]]))

(def AnalStateTbl "anal_state")

(def AnalStateFields [{:nme "id"  :tpe :serial :constraint "PRIMARY KEY"}
                        {:nme "st_type"   :tpe :text :default nil}
                        {:nme "st_state"   :tpe :text :default nil}
                {:nme "vandaag"  :tpe :integer :default 0}
                {:nme "week"  :tpe :integer :default 0}
                {:nme "maand"  :tpe :integer :default 0}
                {:nme "jaar"  :tpe  :integer :default 0}
                {:nme "gisteren"  :tpe  :integer :default 0}
                {:nme "vorige_week"  :tpe :integer :default 0}
                {:nme "vorige_maand" :tpe :integer :default 0}
                {:nme "vorig_jaar" :tpe :integer :default 0}
])

(defn get-current-index-dates 
   "Get the index numbers of the different dates in the database." 
   []
   (let [lpf "(get-current-index-dates): " 
         qry (str "SELECT EXTRACT(YEAR FROM now()) AS year "
                  "  , EXTRACT(MONTH FROM now()) AS month "
                  "  , EXTRACT(week FROM now()) AS week " 
                  "  , to_char(now(), 'YYYY-MM-DD')  AS today " 
                  "  , to_char(now() - INTERVAL '1 day', 'YYYY-MM-DD') AS yesterday "
                  "  , EXTRACT(MONTH FROM now() - INTERVAL '1 month') AS lmonth "
                  "  , EXTRACT(YEAR FROM now() - INTERVAL '1 month') AS lmonthyear "
                  "  , EXTRACT(WEEK FROM now() - INTERVAL '1 week') AS lweek "
                  "  , EXTRACT(YEAR FROM now() - INTERVAL '1 week') AS lweekyear "
                  "  , EXTRACT(YEAR FROM now() - INTERVAL '1 year') AS lyear "
                  "  ;" )]
     (println lpf qry)
     (sql/with-query-results res [qry]
       (first res))))

(defn run-analysis []
   (let [lpf "(run-analysis): "
         {:keys [year month week today yesterday lmonth lmonthyear lweek lweekyear lyear]} (get-current-index-dates) 
         checkDate (str "CAST(CASE WHEN st_state=" (sqs STATE_SUBMITTED) 
                         " THEN st_submit_date ELSE st_create_date END AS DATE)")
         sum-period (fn [perLbl period year]
                        (str " CASE WHEN EXTRACT(" perLbl " FROM " checkDate ")=" period 
                           " AND EXTRACT(year FROM " checkDate ")=" year " 
                              THEN 1 ELSE 0 END "))
         qry (str " INSERT INTO " (qsp Schema AnalStateTbl) 
                   " (st_type, st_state, vandaag, gisteren, week, maand, jaar, "
                   "       vorige_week, vorige_maand, vorig_jaar) \n"
                   " SELECT st_type, st_state "
                   "  , SUM(vandaag) AS vandaag, SUM(gisteren) AS gisteren "
                   "  , SUM(week) AS week, SUM(maand) AS maand "
                   "  , SUM(jaar) AS jaar, SUM(vorige_week) AS vorige_week "
                   "  , SUM(vorige_maand) AS vorige_maand"
                   "  , SUM(vorig_jaar) AS vorig_jaar \n"
                   " FROM (SELECT st_type, st_state " 
                   "   , CASE WHEN " checkDate "=" (sqs today) 
                   "::DATE THEN 1 ELSE 0 END AS vandaag \n"
                   "   , CASE WHEN " checkDate "=" (sqs yesterday) 
                   "::DATE THEN 1 ELSE 0 END AS gisteren \n"
                   "   ," (sum-period "WEEK" week year) " AS week \n"
                   "   ," (sum-period "MONTH" month year) " AS maand \n"
                   "   , CASE WHEN EXTRACT(year FROM " checkDate ")=" year 
                   "       THEN 1 ELSE 0 END AS jaar \n"
                   "   ," (sum-period "WEEK" lweek lweekyear) " AS vorige_week \n"
                   "   ," (sum-period "MONTH" lmonth lmonthyear)  
                   " AS vorige_maand \n"
                   "   , CASE WHEN EXTRACT(year FROM " checkDate ")=" lyear 
                   "       THEN 1 ELSE 0 END AS vorig_jaar \n"
                   "      FROM " (qsp Schema MsgTbl) " ) AS sub \n"
                   " GROUP BY  st_type, st_state \n"
                   " ORDER BY  st_type, st_state; " 
                )]
    (println lpf " query: "  qry)
    (vSql/trunc-table Schema AnalStateTbl)
    (sql/do-commands qry)
    
))

(defn check-initialize-analysis
  "This function assumes an open database connection and checks whether the
   table for storing the analysis exists.When not present it is created."
  []
  (vSql/create-table Schema AnalStateTbl AnalStateFields false))
