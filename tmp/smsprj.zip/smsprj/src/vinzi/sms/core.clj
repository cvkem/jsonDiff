(ns vinzi.sms.core
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [debug-repl [debug-repl :as dr]]
;;	    [clojure.core.typed :refer [check-ns ann cf]]
            [clojure.java [jdbc :as sql]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vSql :as vSql]]
            [vinzi.eis.config.initialize.readConfiguration :as rc]
            [vinzi.sms
              [analyse :as anal]
              [database :as db]
              [intervals :as intv]
              [matchRecs :as mr]
;;             [setExtractInterface :as sei] ;; load it to force initialization
              [patientInfo :as pi]
              [sms :as sms]
              ;;  [SmsCharMap :as scm]
	      [submit :as subm]
              [timeExclusion :as te]]
	    [vinzi.sms.scipio.extract :as xt]
	    [vinzi.sms [globals :as gl]]  ;; not strictly required
            [vinzi.pentaho.connect :as pc]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; setting jndi (shouldn't this be more general, with path coming from
;; a properties file.
;; (include in vinzi.pentaho)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



;(when-not (find-ns 'clojure.core.typed)
;  ;; if core typed does not exist nilify the annotations.
;  (defmacro ann [_ _] ))


(def JndiSet (atom nil))

;;(ann set-pentaho-solution-folder [ -> nil])

(defn set-pentaho-solution-folder
  "Called by set-jndi"
  []
  (pc/set-pentaho-solution-folder "/var/pentaho/bi/ps"))

(defn set-jndi 
  "Install a jndi mapping from Tdat --> loc. Jndi can be set only once during a run of the JVM!"
  [loc]
  ;; set pentaho-solution folder for testing and standalone operation.
  (set-pentaho-solution-folder)
;;  (when (and @JndiSet (not= @JndiSet loc))
;;    (vExcept/throw-except "(set-jndi " loc "): loc can only be set once to prevent data-integrity issues. Loc was already set to " @JndiSet))
  (pc/set-jndiPreMapping {"Tdat" loc})
  (reset! JndiSet loc))


(defn xml-true [x]
  (when x
    (= (str/lower-case x) "true")))


(defn get-sms-locs
 "Get the specifications of all locations with vinzi/sms = true."
 []
  (->> (rc/read-eisConfig)
       (:locations )
       (vals )
       (filter (comp xml-true :sms :vinzi)  )))


(defn get-locSpecs [jndi]
  (->> (rc/read-eisConfig)
       (:locations )
       (vals )
       (filter #(= (-> % (:vinzi ) (:jndi)) jndi) )
       (first)))



;;;;;;;;;;;;;;;;;;;;;;;;
;;  The main loops for different sub-processes.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn collect-sms-run [locSpecs]
  (let [lpf "(collect-sms-run): "
        locSpecs (if (string? locSpecs)
                   (get-locSpecs locSpecs)  ;; locSpecs is a jndi
                   locSpecs)
	;; extact all types of messages and the patientInfo
        jour (-> (xt/extract-journal locSpecs intv/JourInterval)
                 (#(do (def TMP_JOUR %) %)))
        _ (debug "DUMP extract-journal: " jour)

        calNotif (-> (xt/extract-calendar+notifications locSpecs intv/CalendarInterval)
                 (#(do (def TMP_CAL %) %)))
        _ (te/check-extend-exclusions calNotif)
;;        _ (debug "TMP: DUMP extract-calNotif: " calNotif)
	ptntInfo (pi/get-fresh-ptnt-info locSpecs)
	;; and process them to a single list of (merged) messages
        extrMsg (sms/process-sms-messages jour calNotif ptntInfo)
        _ (debug lpf " after processing the list of " (count jour) " journal-items and " 
               (count calNotif) " calNotif has size " (count extrMsg) " remaining messages"
               "\n\t  DELTA: "  (- (count extrMsg) (+ (count jour) (count calNotif))) "  messages.")
        ;; currMsg are limited to the current period in order to be able to detect
        ;;  and mark deletes during 'process-deletes (and to keep volumes limited)
        unionInterval (intv/get-union-interval intv/JourInterval intv/CalendarInterval)
        [currMsg updDel] (-> (db/get-current-messages unionInterval)
		             (mr/detect-deletes extrMsg intv/JourInterval intv/CalendarInterval))
	_ (do (debug lpf " check currMsg with count: " (count currMsg))
             (sms/check-seq-hm currMsg))
        [appends updates] (mr/get-msg-appends-and-updates currMsg extrMsg)
        ;; submitted records can not be deleted.
        updDel (remove #(= (:st_state %) STATE_SUBMITTED) updDel) ]

;    (def TMP_extrMsg extrMsg)  ;; for debugging
;    (def TMP_appends appends)
;    (def TMP_updates updates)
;    (def TMP_currMsg currMsg)
;    (def TMP_updDel updDel)
    (mr/show-updates currMsg updates)
;;(println "\n######################\nTEMPORARY No Updates")

    ;; some checks
    (debug lpf " check-appends")
    (sms/check-seq-hm appends)
    (sms/check-seq-hm updates)
    (sms/check-seq-hm updDel)
    ;; add and update messages table (deletes have been flagged already).
    (db/update-state-messages updDel STATE_DEL_UPDATE)
    (db/add-messages appends)
    (db/update-messages updates)
))

(defn test-run
  [jndi]
  (let [locSpecs {:todo "FIXIT"
                  :jndi jndi}]
   (println "\n===================================="
            " Start collection run for locSpecs=" locSpecs)
   ; (collect-sms-run locSpecs)
   (println "\n====================================="
            "\nFinished testrun")))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  Auxiliary functions.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defn pr-ind [s]
  (println " Sequence has " (count s) " items.")
  (doseq [[i d] (map #(vector %1 %2) (next (range)) s)]
     (println i ": "  d)))
  
(defn ppr-ind [s]
  (println " Sequence has " (count s) " items.")
  (doseq [[i d] (map #(vector %1 %2) (next (range)) s)]
     (print i ": ") (pprint  d)))
  

;; replacement string
;; (str/replace px #"(?iu)(<[\w]*password>)[^<]*(</[\w]*password>)" "$1REMOVED$2")

;; run-queries on mysql
(defmacro db-form
  "Run a form on the sag04-scipio mysql database."
  [jndi form]
  `(sql/with-connection (xt/build-db-descr (get-locSpecs ~jndi)) ~form))

(defmacro db4-form
  "Run a form on the sag04-scipio mysql database."
  [form]
  `(sql/with-connection (xt/build-db-descr (get-locSpecs "sag04")) ~form))

(defn db4-qry [qry]
  (db4-form (sql/with-query-results res [qry] (doall res))))

(defn db-qry [jndi qry]
  (db-form jndi (sql/with-query-results res [qry] (doall res))))

(defn db4-do [act]
  (db4-form (sql/do-commands act)))

;; run-queries on postgres
(defmacro pgdb-form
 [jndi form] 
  `(do (set-pentaho-solution-folder) 
        (sql/with-connection (pc/find-connection ~jndi) ~form)))

(defn pgdb4-qry [qry]
  (pgdb-form "sag04" (sql/with-query-results res [qry] (doall res))))

(defn pgdb4-do [act]
  (pgdb-form "sag04" (sql/do-commands act)))

(defmacro pgdb4-form [act]
  `(pgdb-form "sag04" ~act))


(def InitializedProps (atom false))
(defn initialization-from-props
  "Perform all initializations in the correct order."
  []
    (let [lpf "(initialization-from-props): "]
      ;; initialization
      (if (not @InitializedProps)
        (do
          (debug lpf "Starting initialization")
          (let [props    (gl/get-sms-properties)]
            (debug lpf " Read properties  " props)
            (subm/init-sms-service-props props)

            )
          (swap! InitializedProps (fn [_] true))
          (debug lpf "Finished"))
	(debug lpf "System has been initialized already. Skipping"))))


(defn initialization-from-db
  "Perform all initializations in the correct order.
   Assume the (correct) database connection is established."
  []
    (let [lpf "(initialization-from-db): "]
      ;; initialization
      (debug lpf "Starting initialization")
      (db/check-initialize-sms)
      (let [settings (db/read-settings-from-db)]
        (debug lpf " Read settings:  " settings)
        (anal/check-initialize-analysis)
        (subm/init-sms-service-db settings)

        (sms/init-sms-generator settings)
        (sms/set-tag-mapping  (db/read-all-tag-defs))
        (sms/set-calendar-name-mapping  (db/read-calendar-name-mapping))
        (te/init-time-exclusions settings)
          (debug lpf "Finished"))))

(defn do-with-connection
  "Set up a (global) database connection based on jndi and
   run the analysis defined by process-location."
  [process-location jndi]
  (let [lpf "(do-with-connection): "]
    (debug lpf " with process-location=" process-location)
    (initialization-from-props)
    (if (= jndi "All")
      (let [locs (get-sms-locs)]
        (println "Found " (count locs) " sms-locations")
        (doseq [locSpec locs]
          (let [jndi ((comp :jndi :vinzi) locSpec)]
            (debug lpf " Processing location jndi=" jndi)
            (try
              (process-location locSpec)
              (catch Throwable th
                (vSql/printSQLExcept lpf th))))))
    (process-location jndi))))

(defn get-jndi-from-locSpec
  "If locSpec is a string, assume it is a jndi, otherwise"
  [locSpecs]
  (if (string? locSpecs) locSpecs ((comp :jndi :vinzi) locSpecs)))


(defn collect-sms-with-connection-aux
  "locSpecs should be a locSpecification, or just a jndi (in which case the
   function collect-sms-run will have to lookup the locSpecs)."
  [locSpec]
  (let [jndi (get-jndi-from-locSpec locSpec)]
    ;(prn locSpecs)
    ;(println "jndi=" jndi)
    (set-jndi jndi)
    (sql/with-connection (pc/find-connection jndi)
      (initialization-from-db)
      (db/check-deadline-messages)
      (collect-sms-run locSpec) 
      (anal/run-analysis))))

(defn collect-sms-with-connection
  "Set up a (global) database connection based on jndi and
   run the analysis.
   If connection is 'All' then do-with-connection will iterate over 
   all connections that have been marked to have an SMS service."
  [jndi]
  (do-with-connection collect-sms-with-connection-aux jndi))



(defn analyze-with-connection-aux
  "Set up a (global) database connection based on jndi and
   run the analysis."
  [locSpec]
  (let [jndi (get-jndi-from-locSpec locSpec)]
    (set-jndi jndi)
    (sql/with-connection (pc/find-connection jndi)
      (initialization-from-db)
      (db/check-deadline-messages)
      (anal/run-analysis))))


(defn analyze-with-connection
  "Set up a (global) database connection based on jndi and
   run the analysis.
   If connection is 'All' then do-with-connection will iterate over 
   all connections that have been marked to have an SMS service." 
  [jndi]
  (do-with-connection analyze-with-connection-aux jndi))


(defn submit-sms-run
  "Check deadlines whether messages passed deadine and set to STATE_TIMEOUT   
   and submit all remaining sms messages with state STATE_CONFIRM. " 
  []
  (let [lpf "(submit-sms-run): " 
        cntSubmitted (atom 0)
        cntFailed    (atom 0)
        set-submitting (fn []
	                 (let [qry (str "UPDATE " (qsp Schema MsgTbl) 
	                            " SET st_state = " (sqs STATE_SUBMITTING)
	                            " WHERE st_state = " (sqs STATE_CONFIRM) ";")]
                           (sql/do-commands qry)))
        get-curr-time-str #(-> (java.util.Date.) 
                                      (.getTime ) 
                                      (vDate/correct-time-zone) 
                                      (java.sql.Timestamp. )
                                      (vDate/generate-sql-date-str))
        submitFmt (str "UPDATE " (qsp Schema MsgTbl) 
	                      " SET st_state = " (sqs STATE_SUBMITTED)
                              "  , st_submit_date = '%s' " 
	                      " WHERE id = %d;")
	mark-submitted (fn [id]
                         (swap! cntSubmitted inc)
                         (sql/do-commands (format submitFmt (get-curr-time-str) id)))
        submitFailFmt (str "UPDATE " (qsp Schema MsgTbl) 
	                      " SET st_state = " (sqs STATE_FAILURE)
                              "  , st_submit_date = '%s' " 
			      "  , st_issues = '|' || '%s' " 
	                      " WHERE id = %d;")
	mark-submit-failed (fn [id {:keys [state errors]}]
                             (swap! cntFailed inc)
                             (let [state (if (sequential? state)
                                           (apply str state) state)
                                   errors (if (sequential? errors)
                                            (apply str errors) errors)]
                             (db/add-note (str "Verzending van bericht " id 
                                 " mislukt. Status: " state " en melding " errors))
			     (let [err (str "HTTP-RESPONSE=" state " "
                                                 (str/join "|" errors))]
                          (sql/do-commands (format submitFailFmt 
                                      (get-curr-time-str) err id)))))
        submit-msg (fn [msg]
                      (let [{:keys [id sms_mobiel sms_msg]} msg]
			(println " (subm/submit-sms-rec " sms_msg " " sms_mobiel ")")
			(let [ret (subm/submit-sms-rec msg)]
			  (println "submit-sms-rec returned: " ret)
                          (debug lpf "submitting: " sms_msg " to " sms_mobiel 
                                  " returned: "  ret)
                            (if (:success ret)	     
			      (mark-submitted id)
                              (mark-submit-failed id ret)))))
        to-submit-qry (str "SELECT id, sms_mobiel, sms_msg " 
                          " FROM " (qsp Schema MsgTbl) 
                          " WHERE st_state = " (sqs STATE_SUBMITTING) ";")]

   (db/check-deadline-messages) ;; first exclude messages that are over their deadline.
   (set-submitting)
   (sql/with-query-results msgs [to-submit-qry]
     (doseq [m msgs]
       (submit-msg m))
     (let [note (if (> (count msgs) 0)
                   (str @cntSubmitted " berichten succesvol verzonden" 
                     (if (> @cntFailed 0) (str " en " @cntFailed " mislukt.") "."))
                     "Geen berichten te verzenden.")]
       (println " Adding Note: "  note)
       (db/add-note note))
     ;; update the analysis
     (anal/run-analysis))))


(defn submit-sms-with-connection-aux
  "Set up a (global) database connection based on jndi and
   run the analysis."
  [locSpec]
  (let [jndi (get-jndi-from-locSpec locSpec)]
    (set-jndi jndi)
    (sql/with-connection (pc/find-connection jndi)
      (initialization-from-db)
      (submit-sms-run ))))


(defn submit-sms-with-connection
  "Set up a (global) database connection based on jndi and
   run the analysis.
   If connection is 'All' then do-with-connection will iterate over 
   all connections that have been marked to have an SMS service."
  [jndi]
  (do-with-connection submit-sms-with-connection-aux jndi))


(defn -main [& args]
;;  (vSql/defDb-form (db/check-initialize-sms))

 ;; (set-extraction-interface (sei/get-extraction-interface))

  (let [lpf "(vinzi.sms.core/-main): "]
    (if (= (count args) 1)
      (case (first args)
        "collect" (collect-sms-with-connection "All")
        "submit"  (submit-sms-with-connection "All")
        "analyze"  (analyze-with-connection "All")
        (vExcept/throw-except lpf "Invalid argument: "  (first args)))
    (vExcept/throw-except lpf "Invalid number of arguments: "  
      (count args) " (expected 1 argument)" ))))


(defn check-tel-fields []
  (let [sags (map #(format "sag%02d" %) (range 13)) ]
    (doseq [sag sags]
      (let [mob (db-qry sag "SELECT * from ptnt LIMIT 1;" )
            telFlds (filter #(re-find #"tel" %) (map name (keys (first mob))))]
        (println sag ": " telFlds)))))

