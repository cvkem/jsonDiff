(ns vinzi.sms.submit
  (:use vinzi.sms.globals
	clojure.tools.logging)
  (:require [clj-http.lite.client :as client]
            [clojure.string :as str]
           ;; [clojure.java.shell :as sh]
            [vinzi.sms
              [globals    :as gl]
              [SmsCharMap :as scm]]
            [vinzi.tools
              [vExcept :as vExcept]]
            [net.cgrand [enlive-html :as html]]
              ))


;; will be read from Properties
;(def OrcaSMS "http://apps20.orcagroup.com/SmsGateway/SendSmsPost.aspx")
;(def ProxyHost "10.20.40.85")
;(def ProxyPort "3128")

(def OrcaSMS)

;;  Authorization/Credentials
(def LicenseKey)
(def Application)
(def ClientName)  ;; name on contract
(def ClientId)

(def Footer (atom ""))

(def Originator (atom ""))

;;(def ProxyHost)
;;(def ProxyPort)


(def SmsFormat "<sms version=\"1.0\">
 <authorization>
  <licensekey>%s</licensekey>
  <application>%s</application>
  <clientname>%s</clientname>
  <clientid>%s</clientid>
 </authorization>
 <message>
  <tariffclass>0</tariffclass>
  <originator>%s</originator>
  <submitdate>%s</submitdate>
  <smsdata type=\"0\"><![CDATA[%s]]></smsdata>
 </message>
 <destinations>
  <destination>%s</destination>
 </destinations>
</sms>")


;; format dates appropriately

(def sdt (java.text.SimpleDateFormat. "yyyy-MM-dd HH:mm:ss"))
(defn get-now [] (.format sdt (java.util.Date. )))

(def ErrMobIncorrEmpty "Mobiel: Incorrecte (lege) invoer.")
(def ErrMobOnlyNum "Mobiel nummer mag alleen cijfers bevatten: ")
(def ErrInvalidMob "Geen geldig mobiel nummer: ")

(defn cleanse-mobile-number
  "Try to convert mob to a mobile telephone number.
    Returns a hashmap with keys :mobile and :error (optional)."
  [mob]
  (if (seq mob)
    (let [lpf "(cleanse-mobiel): " 
          mob (str/replace mob #"[\s\-]" "")]
       (if (->> (if (= (first mob) \+) (subs mob 1) mob)
                (re-find #"\D+" ))
         {:mobile nil
          :error (str ErrMobOnlyNum mob)} 
         (if (and (= (count mob) 10)
                  (.startsWith mob "06"))
            {:mobile (str "+31" (subs mob 1)) }
           (if (and (= (count mob) 12)
                    (.startsWith mob "+31"))
              {:mobile mob}
              {:mobile nil
               :error (str ErrInvalidMob mob)}))))
      {:mobile nil
       :error  (str ErrMobIncorrEmpty mob)}))



(defn generate-sms-xml
  "Generate an xml-string based on the parameters + current date-time."
  [originator msg telNr]
  (format SmsFormat LicenseKey Application ClientName ClientId originator (get-now) msg telNr)) 

(defn generate-sms-envelope [smsXml]
  {:debug true               ;;; TODO: set to false during production
;;  NOTE: next params only needed for clj-http. In clj-http-lite the
;;   proxy is set via system-properties.
;;   :proxy-host  ProxyHost
;;   :proxy-port (Integer/parseInt ProxyPort)
   :body smsXml
   :content-type  "application/xml"})


(defn post-orca
  "Post and smsEnvelope to the Orca-server."
  [smsEnvelope]
  (client/post OrcaSMS smsEnvelope))


(def SrcBerichtFout "Fouten in berichttekst?")
(def SrcInternetFout   "Storing in de internet verbinding?")
(def SrcOrcaTegoed   "Nul berichten verzonden, sms-tegoed op?") 
(def SrcOrcaResponseFormatChange "Formaat van Orca antwoorden gewijzigd. Foutdetectie aanpassen")
(def SrcMobileNrInvalid "Ongeldig mobiel nummer")

(defn process-orca-response
  [{:keys [headers status body]}]
  (let [response  (-> body
                     (html/html-snippet )
                     (html/select [:div])
		     ((partial map html/text) )
                     ((partial map str/split-lines) ))
	_ (when-not (= (count response) 1)
            (error " expected 1 response-section, but received " (count response)
                "\n\t in body: " body
                "\n\tonly using first section"))
        numPhone (->> (first response)
                     (apply str )
                     (re-find #"\s*(\d*)\s*Phonenumber\(s\) queued" )
                     (second ))
        numPhone (when numPhone (Long/parseLong numPhone))
        errors (filter #(re-find #"\[[\w\s/:]*\]\s*Error" %) (first response))]
  (if (and (= status 200) (not (seq errors)) numPhone (> numPhone 0))
    {:success true
     :state status}
    {:success false
     :type (if (= status 200) :permanent :temporary)
     :source (if (= status 200)
                (if (seq errors)
                   SrcBerichtFout
                   (if (and numPhone (< numPhone 1))
                     SrcOrcaTegoed
                     SrcOrcaResponseFormatChange))
                SrcInternetFout)
     :state status
     :errors (seq errors)})))

(defn set-http-proxy [ProxyHost ProxyPort]
  ;; clj-http-lite uses system-properties to set proxy and port.
   (let [lpf "(set-http-proxy): "
         sp (System/getProperties)]
     (debug lpf "About to set system properties for http.proxy*")
     (System/setProperty "http.proxyHost" ProxyHost)
     (System/setProperty "http.proxyPort" ProxyPort)
     ;; show results in log-file
     (debug lpf (filter #(.startsWith (first %) "http") (zipmap (keys sp) (vals sp)))))
  )

(def RawResponses (atom []))

(defn submit-sms-aux
  "Generate an sms based on 'msg' and send to 'telNr'
   The telNr will be validated before submitting the message.
   The response contains :success (boolean), :source (string describing type
   of issues), :state (the html-response status) and :errors (a sequence of errors).
   When in debug-mode additional output is sent to stdout.
   (Assumes sms-message does not exceed length constraint.)"
  [originator msg mobile]
     (-> (generate-sms-xml originator msg mobile)
         (generate-sms-envelope )
         (post-orca )
         (#(do (swap! RawResponses conj %) %))
         (process-orca-response)))


(def SmsMaxLen 160)
(def SepParts "...")

;;(ann SplitStr (PersistentHashSet String))

(def SplitStr #{" " "\t" "\n" "." "," ";"})


;;(ann  find-split-backward [String AnyInteger -> AnyInteger])

(defn find-split-backward 
  "Find the first position at position <= pos where the string can be split
   at one of the one-character strings in SplitStr.
   Returns the index of the split-position." 
  [msg pos]
  (when (< pos 1)
    (vExcept/throw-except "(find-spit-backward): message can not be split: " msg))
  (if (SplitStr (subs msg (dec pos) pos))
     pos
     (recur msg (dec pos))))

;;(ann ^:no-check split-long-sms (Fn [(HMap :mandatory {:sms_msg String}) -> (Seqable (HMap))]
;;                      [(HMap :mandatory {:sms_msg String}) Integer -> (Seqable (HMap))]))

(defn split-long-sms 
  "If the sms-msg is longer than 160 characters, the message will be split.
   Returns a sequence of one of more messages."
  ([sms_msg]  (split-long-sms sms_msg SmsMaxLen))
  ([sms_msg SmsMaxLen]
    (let [split-sms (fn [cumm sms_msg]
		      (if (<= (count sms_msg) SmsMaxLen)
                        (conj cumm sms_msg)
                        (let [pos (find-split-backward sms_msg (- SmsMaxLen (count SepParts )))
			      part1 (str (subs sms_msg 0 pos) SepParts)
			      part2 (str SepParts (subs sms_msg pos))]
                          (recur (conj cumm part1) part2))))]
    (split-sms [] sms_msg))))

(defn andf 
  "andf as   (apply and '(...)) is not allowed."
  [& bools]
  (not (some not bools)))
     

(defn merge-responses 
  [rets]
  (let [resp {:success (apply andf (map :success rets))
              :num-parts (count rets)
              :state (map :state rets)}]
    (if (:success resp)
      resp
      (assoc resp  :type (if (some #(= % :permanent) (map :type rets)) :permanent :temporary)
                    :errors (apply concat (map :errors rets))))))

(defn submit-sms-rec
  "Remove non-transmitable characters, split the sms_msg if it is longer than  160 characters and
   subsequently submit these sms-messages. "
  [{:keys [sms_mobiel sms_msg originator footer]}]
    (let [{:keys [mobile error]} (cleanse-mobile-number sms_mobiel)]
     (if mobile 
       (let [lpf "(submit-sms-rec): " 
             originator (or originator @Originator)
             footer     (or footer     @Footer)
             msgs  (-> (if (= (last sms_msg) \newline) 
                          (str sms_msg footer)
                          (str sms_msg "\n" footer))
                       (scm/fix-sms-special-chars )
                       (split-long-sms ))
             rets (doall (map #(submit-sms-aux originator % mobile) msgs))
             _ (doseq [[i r] (map #(vector %1 %2) (next (range)) rets)]
                  (debug lpf " Part " i ": " r))
             response (merge-responses rets)]
         response)
       ;; error: no a valid number
       {:success false
        :source  SrcMobileNrInvalid
        :errors (list error) })))

(defn submit-sms-rec-cdp
  "This version calls submit-sms-rec and flattens the result to a string for cdp."
  [pars]
  (let [ret (submit-sms-rec pars)]
    (if (:success ret)
      (list "OK")
      (list (str (:source ret) " -- " (str/join ", " (:errors ret)))))))


(def InitializedFromProps (atom nil))
(def InitializedFromDb (atom nil))

(defn init-sms-service-props 
  ([] (init-sms-service-props (gl/get-sms-properties)))
  ([{:keys [http_ProxyHost http_ProxyPort submit_OrcaSMS submit_LicenseKey submit_Application submit_ClientName submit_ClientId] :as props}]
   (let [lpf "(init-sms-service-props): "]
     (when-not (and http_ProxyHost http_ProxyPort submit_OrcaSMS submit_LicenseKey submit_Application submit_ClientName submit_ClientId)
       (vExcept/throw-except lpf " Some properties are missing from: " props))
 
     (if (compare-and-set! InitializedFromProps nil props)
       (do
         (set-http-proxy http_ProxyHost http_ProxyPort)

         ;; these globals can only be set once!!
         (def OrcaSMS submit_OrcaSMS)
         (def LicenseKey submit_LicenseKey)
         (def Application submit_Application)
         (def ClientName submit_ClientName)
         (def ClientId   submit_ClientId))
      (warn lpf " Properties were already set to: " @InitializedFromProps))
  )))

(defn init-sms-service-db [{:keys [submit_Originator submit_Footer] :as settings}]
   (let [lpf "(init-sms-service-db): "]
     ;; some validity checks
     (when-not (and submit_Originator submit_Footer)
       (vExcept/throw-except lpf " Some properties are missing from: " settings))

   ;  (if (compare-and-set! InitializedFromDb nil settings)
   ;    (do
          (reset! Originator submit_Originator)
          (reset! Footer     (if (seq submit_Footer) submit_Footer ""))
    ; )
    ;  (warn lpf " Settings were already set to: " @InitializedFromDb)
    ;   )
  ))

