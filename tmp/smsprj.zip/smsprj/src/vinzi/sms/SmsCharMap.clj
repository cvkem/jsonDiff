(ns vinzi.sms.SmsCharMap
  (:use [clojure.core [typed :only [check-ns cf ann ann-form def-alias
                                    EmptySeqable Option 
                                    fn> print-env Seq tc-ignore]]])
  (:import [clojure.lang IPersistentMap])
)

;(when-not (find-ns 'clojure.core.typed)
;  ;; if core typed does not exist nilify the annotations.
;(println " trying to define macro as:" (find-ns 'clojure.core.typed))
;  (defmacro ann [_ _] )
;)


(ann UnknownChar Character)

(def UnknownChar \?)

(ann Unknown  Integer)

(def Unknown  (int UnknownChar))

(ann CharMap (IPersistentMap Long Integer))

(def CharMap { 
	 0    (int \?)  ;;   --
	 1    (int \?)  ;;   --
	 2    (int \?)  ;;   --
	 3    (int \?)  ;;   --
	 4    (int \?)  ;;   --
	 5    (int \?)  ;;   --
	 6    (int \?)  ;;   --
	 7    (int \?)  ;;   --
	 8    (int \?)  ;;   --
	 9    (int \?)  ;;   --
	 10    (int 10)  ;;   --
	 11    (int \?)  ;;   --
	 12    (int \?)  ;;   --
         13    (int 13)
	 14    (int \?)  ;;   --
	 15    (int \?)  ;;   --
	 16    (int \?)  ;;   --
	 17    (int \?)  ;;   --
	 18    (int \?)  ;;   --
	 19    (int \?)  ;;   --
	 20    (int \?)  ;;   --
         21    (int \?)  ;;   formfeed??
	 22    (int \?)  ;;
	 24    (int \?)  ;;   
	 25    (int \?)  ;;   
	 26    (int \?)  ;;   
	 29    (int \?)  ;;   
	 30    (int \?)  ;;   
	 31    (int \?)  ;;   
	 32    (int \ )  ;;    
	 33    (int \!)  ;;   !
	 34    (int \")  ;;   "
	 35    (int \#)  ;;   #
	 36    (int \$)  ;;   $
	 37    (int \%)  ;;   %
	 38    (int \&)  ;;   &
	 39    (int \')  ;;   '
	 40    (int \()  ;;   (
	 41    (int \))  ;;   )
	 42    (int \*)  ;;   *
	 43    (int \+)  ;;   +
	 44    (int \,)  ;;   ,
	 45    (int \-)  ;;   -
	 46    (int \.)  ;;   .
	 47    (int \/)  ;;   /
	 48    (int \0)  ;;   0
	 49    (int \1)  ;;   1
	 50    (int \2)  ;;   2
	 51    (int \3)  ;;   3
	 52    (int \4)  ;;   4
	 53    (int \5)  ;;   5
	 54    (int \6)  ;;   6
	 55    (int \7)  ;;   7
	 56    (int \8)  ;;   8
	 57    (int \9)  ;;   9
	 58    (int \:)  ;;   :
	 59    (int \;)  ;;   ;
	 60    (int \<)  ;;   <
	 61    (int \=)  ;;   =
	 62    (int \>)  ;;   >
	 63    (int \?)  ;;   ?
	 64    (int \@)  ;;   @
	 65    (int \A)  ;;   A
	 66    (int \B)  ;;   B
	 67    (int \C)  ;;   C
	 68    (int \D)  ;;   D
	 69    (int \E)  ;;   E
	 70    (int \F)  ;;   F
	 71    (int \G)  ;;   G
	 72    (int \H)  ;;   H
	 73    (int \I)  ;;   I
	 74    (int \J)  ;;   J
	 75    (int \K)  ;;   K
	 76    (int \L)  ;;   L
	 77    (int \M)  ;;   M
	 78    (int \N)  ;;   N
	 79    (int \O)  ;;   O
	 80    (int \P)  ;;   P
	 81    (int \Q)  ;;   Q
	 82    (int \R)  ;;   R
	 83    (int \S)  ;;   S
	 84    (int \T)  ;;   T
	 85    (int \U)  ;;   U
	 86    (int \V)  ;;   V
	 87    (int \W)  ;;   W
	 88    (int \X)  ;;   X
	 89    (int \Y)  ;;   Y
	 90    (int \Z)  ;;   Z
	 91    (int \[)  ;;   [
	 92    (int \\)  ;;   \
	 93    (int \])  ;;   ]
	 94    (int \^)  ;;   ^
	 95    (int \_)  ;;   _
	 96    (int \?)  ;;   `
	 97    (int \a)  ;;   a
	 98    (int \b)  ;;   b
	 99    (int \c)  ;;   c
	 100    (int \d)  ;;   d
	 101    (int \e)  ;;   e
	 102    (int \f)  ;;   f
	 103    (int \g)  ;;   g
	 104    (int \h)  ;;   h
	 105    (int \i)  ;;   i
	 106    (int \j)  ;;   j
	 107    (int \k)  ;;   k
	 108    (int \l)  ;;   l
	 109    (int \m)  ;;   m
	 110    (int \n)  ;;   n
	 111    (int \o)  ;;   o
	 112    (int \p)  ;;   p
	 113    (int \q)  ;;   q
	 114    (int \r)  ;;   r
	 115    (int \s)  ;;   s
	 116    (int \t)  ;;   t
	 117    (int \u)  ;;   u
	 118    (int \v)  ;;   v
	 119    (int \w)  ;;   w
	 120    (int \x)  ;;   x
	 121    (int \y)  ;;   y
	 122    (int \z)  ;;   z
	 123    (int \{)  ;;   {
	 124    (int \|)  ;;   |
	 125    (int \})  ;;   }
	 126    (int \~)  ;;   ~
	 127    (int \?)  ;;  
	 128    (int \?)  ;;   
	 129    (int \?)  ;;   
	 130    (int \?)  ;;   
	 131    (int \?)  ;;   
	 132    (int \?)  ;;   
	 133    (int \?)  ;;   
	 134    (int \?)  ;;   
	 135    (int \?)  ;;   
	 136    (int \?)  ;;   
	 137    (int \?)  ;;   
	 138    (int \?)  ;;   
	 139    (int \?)  ;;   
	 140    (int \?)  ;;   
	 141    (int \?)  ;;   
	 142    (int \?)  ;;   
	 143    (int \?)  ;;   
	 144    (int \?)  ;;   
	 145    (int \?)  ;;   
	 146    (int \?)  ;;   
	 147    (int \?)  ;;   
	 148    (int \?)  ;;   
	 149    (int \?)  ;;   
	 150    (int \?)  ;;   
	 151    (int \?)  ;;   
	 152    (int \?)  ;;   
	 153    (int \?)  ;;   
	 154    (int \?)  ;;   
	 155    (int \?)  ;;   
	 156    (int \?)  ;;   
	 157    (int \?)  ;;   
	 158    (int \?)  ;;   
	 159    (int \?)  ;;   
	 160    (int \?)  ;;    
	 161    (int \?)  ;;   ¡
	 162    (int \?)  ;;   ¢
	 163    (int \?)  ;;   £
	 164    (int \?)  ;;   ¤
	 165    (int \?)  ;;   ¥
	 166    (int \?)  ;;   ¦
	 167    (int \?)  ;;   §
	 168    (int \?)  ;;   ¨
	 169    (int \?)  ;;   ©
	 170    (int \?)  ;;   ª
	 171    (int \?)  ;;   «
	 172    (int \?)  ;;   ¬
	 173    (int \?)  ;;   ­
	 174    (int \?)  ;;   ®
	 175    (int \?)  ;;   ¯
	 176    (int \?)  ;;   °
	 177    (int \?)  ;;   ±
	 178    (int \?)  ;;   ²
	 179    (int \?)  ;;   ³
	 180    (int \?)  ;;   ´
	 181    (int \?)  ;;   µ
	 182    (int \?)  ;;   ¶
	 183    (int \?)  ;;   ·
	 184    (int \?)  ;;   ¸
	 185    (int \?)  ;;   ¹
	 186    (int \?)  ;;   º
	 187    (int \?)  ;;   »
	 188    (int \?)  ;;   ¼
	 189    (int \?)  ;;   ½
	 190    (int \?)  ;;   ¾
	 191    (int \?)  ;;   ¿
	 192    (int  \A )  ;;   À
	 193    (int  \A )  ;;   Á
	 194    (int  \A )  ;;   Â
	 195    (int  \A )  ;;   Ã
	 196    (int  \A )  ;;   Ä
	 197    (int  \A )  ;;   Å
	 198    (int  \A )  ;;   Æ
	 199    (int  \C )  ;;   Ç
	 200    (int  \E )  ;;   È
	 201    (int  \E )  ;;   É
	 202    (int  \E )  ;;   Ê
	 203    (int  \E )  ;;   Ë
	 204    (int  \I )  ;;   Ì
	 205    (int  \I )  ;;   Í
	 206    (int  \I )  ;;   Î
	 207    (int  \I )  ;;   Ï
	 208    (int  \? )  ;;   Ð
	 209    (int  \N )  ;;   Ñ
	 210    (int  \O )  ;;   Ò
	 211    (int  \O )  ;;   Ó
	 212    (int  \O )  ;;   Ô
	 213    (int  \O )  ;;   Õ
	 214    (int  \O )  ;;   Ö
	 215    (int  \x )  ;;   ×
	 216    (int  \O )  ;;   Ø
	 217    (int  \U )  ;;   Ù
	 218    (int  \U )  ;;   Ú
	 219    (int  \U )  ;;   Û
	 220    (int  \U )  ;;   Ü
	 221    (int  \Y )  ;;   Ý
	 222    (int  \? )  ;;   Þ
	 223    (int  \B )  ;;   ß
	 224    (int  \a )  ;;   à
	 225    (int  \a )  ;;   á
	 226    (int  \a )  ;;   â
	 227    (int  \a )  ;;   ã
	 228    (int  \a )  ;;   ä
	 229    (int  \a )  ;;   å
	 230    (int  \? )  ;;   æ
	 231    (int  \c )  ;;   ç
	 232    (int  \e )  ;;   è
	 233    (int  \e )  ;;   é
	 234    (int  \e )  ;;   ê
	 235    (int  \e )  ;;   ë
	 236    (int  \i )  ;;   ì
	 237    (int  \i )  ;;   í
	 238    (int  \i )  ;;   î
	 239    (int  \i )  ;;   ï
	 240    (int  \o )  ;;   ð
	 241    (int  \n )  ;;   ñ
	 242    (int  \o )  ;;   ò
	 243    (int  \o )  ;;   ó
	 244    (int  \o )  ;;   ô
	 245    (int  \o )  ;;   õ
	 246    (int  \o )  ;;   ö
	 247    (int  \: )  ;;   ÷
	 248    (int  \o )  ;;   ø
	 249    (int  \u )  ;;   ù
	 250    (int  \u )  ;;   ú
	 251    (int  \u )  ;;   û
	 252    (int  \u )  ;;   ü
	 253    (int  \t )  ;;   ý
	 254    (int  \? )  ;;   þ
	 255    (int  \y )  ;;   ÿ
         8364   (int \E)    ;;   €
})

;;; check fails on CharMap
(ann ^:no-check cleanse-string [String -> String])

(defn cleanse-string 
  "Apply the CharMap and return a cleansed string. " 
   [s]
   (->> s
	(map #(char (if-let [ci (CharMap (long %))] ci Unknown)) )
        (apply str )))


(ann SmsSpecialCharMap (IPersistentMap Long Integer))

(def SmsSpecialCharMap {
;;	 64    (int 0)  ;;   @
;;	 36    (int 2)  ;;   $
  })


;;; check fails on SmsSpecialCharMap
(ann ^:no-check fix-sms-special-chars [String -> String])

(defn fix-sms-special-chars
  "Apply the SmsSpecialCharMap to fix the special characters (currently only @ and $).
   All other characters remain unchanged." 
   [s]
   (->> s
	(map #(char (if-let [ci (SmsSpecialCharMap (int %))] ci %)) )
        (apply str )))


(ann ^:no-check gen-base-mapping [ -> nil])
(defn gen-base-mapping
   "Generates a base map which needs to be corrected by hand" 
   []
   (let [map-to (fn [x] 
                        (let [valid (-> (concat (list 10, 13, 27) (range 32 64) 
                                      (range 65 91) (range 97 123)
					(range 192 256))
				      (set ))]
                           (if (valid x) x 63)))]
   (println "(def CharMap { " )
   (doseq [x (range 256)] 
      (let [mapped (map-to x)]
      (println "\t" (int x) (str "   (int \\" (char mapped)  ")  ;;  ") (if (> x 20) (char x) "--" ))))
   (println "})")
   (println "\n###### let op bij char 21 en 27 gaat het fout (via het clipboard)")))

