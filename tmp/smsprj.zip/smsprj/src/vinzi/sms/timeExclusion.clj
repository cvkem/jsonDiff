(ns vinzi.sms.timeExclusion
  (:use vinzi.sms.globals
        [clojure.tools 
          [logging :only [error info trace debug warn]]]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias Seqable Option 
                                    AnyInteger 
                                    fn> doseq>
                                    print-env Seq tc-ignore]]] )
  (:require [clojure 
              [set :as set]
              [string :as str]]
            [vinzi.tools
              [vDateTime :as vDate]
              [vExcept :as vExcept]]
            [vinzi.sms
              [database :as db]])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Here you find  functions related to:
;;    1. management of the TimeExclusion (timeinterval)
;;    2. detect overlap between two sequences of apointments

(ann get-time [(Option String) -> String])
(defn get-time 
   "Cleanse a timestamp or string to retrieve only the string hh:mm."
   [t] 
   (->> t 
        (str ) 
        (str/trim ) 
        ((fn> [a :- String]
           (str/split a #":")))
        (take 2) 
        (str/join ":")))


(ann ^:no-check cleanse-time-exclusion [String -> (HMap :mandatory {:success Boolean :result String} :optional {:error String})])
(defn cleanse-time-exclusion
  [timeExcl]
  (let [timeExcl (str/trim timeExcl)
        patch-space-sep (fn [parts]
                          (let [patch-it (fn [p]
                                           (if (seq (last p))
                                             p
                                             (concat (drop-last p) (list ","))))]
                   (if (seq parts)
                     (concat (map patch-it (drop-last parts)) (list (last parts)))
                     parts)))
        parts (-> timeExcl 
                  (str/replace #"u" ":") 
                  (str/replace #";" ",") 
                  ((partial re-seq #"\s*+(\d{1,2}\:\d{0,2})\s*([\-,]{0,1})"))
                  (patch-space-sep ))
        reconstruct (apply str (map first parts))
        fix-time (fn [[t sep]]
                   ;; fix time to two digits on minutes and append sep
                   (let [[_  t1 t2] (re-find #"(\d*):(\d*)" t)
                         t2 (if (= (count t2) 0)
                              "00"
                              (if (= (count t2) 1) 
                                (str "0" t2)
                                t2))]
                     (str t1 ":" t2 sep)))
        result   (->> parts
                      (map rest )
                      (map fix-time )
                      (apply str )
                      (str ))
        ret {:success false :result result}]
   (if (= (count reconstruct) (count timeExcl))
     (let [seps (map last parts)]
       (if (seq (remove seq (drop-last seps)))
         (assoc ret :error   "scheidingsteken , of - ontbreekt")
         (if (some identity (map #(= %1 %2 "-") seps (next seps)))
           (assoc ret :error "meerdere - na zonder , ertussen kan niet")
           (if (seq (last seps))
             (assoc ret :error "scheidingsteken aan einde van regel")
             (assoc ret :success true)))))
     (assoc ret :error  (str "exclusie bevat ongeldige karakters")))))




(ann DefaultTimeExclusion String)
(def DefaultTimeExclusion (let [te (cleanse-time-exclusion "12:00-12:25")]
                             (assert (:success te))
                             (:result te)))


(ann ^:no-check add-update-time-exclusion [String -> nil])
(defn add-update-time-exclusion
   "Cleanse the time-exclusion and add it to the database."
  [timeExcl]
  (let [lpf "(add-update-time-exclusion): " 
        cte (cleanse-time-exclusion (:exclusie timeExcl))]
    (if (:success cte)
      (db/add-update-time-exclusion-raw (assoc timeExcl :exclusie (:result cte)))
      (vExcept/throw-except lpf "Invalid time-exclusion. Result: " (:result cte)))
    nil)) ;; added for core.typed


(ann  ^:no-check check-extend-exclusions [SmsMsgSeq -> nil])
(defn check-extend-exclusions
  "Run a check over all data and see whether (possible empty) exclusion
   entries exist for each combination of Zorgverlener and day-of-week." 
  [data]
  (let [lpf "(check-extend-exclusions): " 
        _ (when-let [empties (seq (remove #(> (count (keys %)) 0) data))]
             ;; nils or empty hash-maps detected
             (vExcept/throw-except lpf (count empties) " empty items in data" ))
        get-zvl-dag #(hash-map :zorgverlener (str/trim (str (:xt_event_zvl %)))
                               :dag (->> (:xt_event_date %)
                                      (vDate/get-day-of-week )
                                      (get vDate/dayOfWeek )))
        ;;_ (db/invalidate-teCache ) ;; essential when running multiple locations
        ;;   turned of this caching, as it does not make sense.
        currTE (->> (db/get-time-exclusions)
                    (map #(select-keys % [:zorgverlener :dag]) )
                    (set ) )
        _ (debug lpf "TMP:  current exclusion: "  currTE)
        data (->> data
                  (map get-zvl-dag )
                  (set )
                  (#(set/difference % currTE) )
                  (map #(assoc % :exclusie DefaultTimeExclusion) ))
        _ (debug lpf " TMP: new zvl-dag combinations: " data)
                    ]
    (doseq> [d :- SmsMsg data]
      (let [{:keys [zorgverlener dag exclusie]} d]
        (db/add-note (str "Voor zorgverlener " zorgverlener " is op " dag
            " de standaard-exclusie " exclusie " toegevoegd.")))
      (db/add-update-time-exclusion-raw d))
      ))


(ann get-match-te-func [String -> (Fn [String -> Boolean])])
(defn ^:no-check get-match-te-func 
  "Return a function that takes a time-string and return whether it is
   covered by the constraint 'te' (should be properly formatted)."
  [te]
  (let [ranges (->> (str/split te #",")
                    (map #(str/split % #"-") )
                    (map #(if (= (count %) 1)
                             (fn [t] (= t (first %)))
                             (fn [t] (and (>= (compare t (first %)) 0)
                                          (<= (compare t (second %)) 0)))) ))]
   (fn [t]
     (let [t (get-time t)]
       (some #(% t) ranges)))))


(ann ^:no-check get-check-timeExclusions-func [ -> (Fn [SmsMsg -> SmsMsg])]) 
(defn get-check-timeExclusions-func 
  "Capture the current timeExclusion, build the lookupfunctions and return
   a function that checks whether a time-range exclusions applies 
     and flag these messages with a TimeExclude issue."
  []
  (let [lpf "(get-check-timeExclusions-func): "
        te (->> (db/get-time-exclusions)
               (group-by #(map % [:zorgverlener :dag]) )
               ;; extract first and only record
               (map #(let [[k v] %]
                       (if (not= (count v) 1)
                       (vExcept/throw-except lpf " expected only one match for: " %)
                       [k (:exclusie (first v))])) )
              (#(zipmap (map first %) (map (comp get-match-te-func second)  %))) )
       match-te (fn [zvl dag time] 
                  ;; find matcher and apply the match.
;                  (println lpf "TMP: check for zvl=" zvl " dag=" dag " tijd=" time)
(def ^:dynamic TMP_te te)                  
;                  (println lpf "TMP: te has type: " (type te) )
;                  (println "  and count=" (count te))
;                  (println lpf "TMP: first field is: " (first te))
;                  (println lpf "TMP keys van te zijn: " (str/join "|" (keys te)))
                  (when-let [mf (get te [(str/trim zvl) (str/trim dag)])]
                    (let [time (str time)]
;                      (println lpf " TMP found a matcher. Match time: " time )
                      (mf time))))
       ]
    (fn [rec]
      (let [{:keys [xt_event_zvl xt_event_time xt_event_date]} rec
             dag (->> xt_event_date 
                   (vDate/get-day-of-week )
                   (get vDate/dayOfWeek ))]
         (if (match-te xt_event_zvl dag xt_event_time)
           (add-issue rec TIME_EXCLUSION)
           rec)))))

(ann init-time-exclusions [(HMap ) -> nil])
(defn init-time-exclusions [{:keys [to_be_implemented] :as settings}]
  ;; TODO:  to be implemented to grab settings from database
  nil)

(ann stf java.text.SimpleDateFormat)
(def stf (java.text.SimpleDateFormat. "hh:mm"))

(ann-many Long SlotLength MaxSlotLength)
(def SlotLength (long (* vDate/Interval1minuteMillis 10)))
;; Assistente has 15 minute slA ots. One minute extra for comparison)
(def MaxSlotLength (long (* vDate/Interval1minuteMillis 16)))  


(ann vinzi.tools.vDateTime/Interval1minuteMillis Long)

(ann ^:no-check get-timeLong (Fn [(Option SmsMsg) -> Long]
                                 [(Option SmsMsg) Long -> Long]))
(defn get-timeLong 
  "Get the time of this record and translate it to a long-value for comparison.
   The optional value is a long value that serves as an offset.
   :xt_event_time can be a java.sql.Time or a string-value!"
  ([rec]
    (if rec
      (->> (:xt_event_time rec)
           (#(if (string? %) (.parse stf %) %) )
           (.getTime ))
      0))   ;; added to satify core-checked (seeing nil all over the place)
  ([rec offset]
   (long (+ (get-timeLong rec) offset))))

(ann time-overlap [SmsMsgSeq SmsMsgSeq -> (U Boolean nil)])
(defn time-overlap 
  "Takes the first two records sequences and determines whether these overlap in time.
   recs1 and recs2 are both sequences of events and the end time is take 'SlotLength' after
   the last time in the sequence. "
  [recs1 recs2]
  (when (and (> (count recs1) 1) (> (count recs2) 1))
    (let [lpf "(check-overlap): "
          _ (print-env " just before gtl ")
          s1 (get-timeLong (first recs1))
          s2 (get-timeLong (first recs2))
          e1 (get-timeLong (last recs1)  SlotLength)
          e2 (get-timeLong (last recs2)  SlotLength)]
      (when (or (< e1 s1)
              (< e2 s2))
        (vExcept/throw-except lpf "Start time before end time for interval " s1 "-" e1 " or " s2 "-" e2))
      (let [c1 (and  (< s2 s1) (<= e2 s1))
            c2 (and  (>= s2 e1) (> e2 e1))
            res (not (or c1 c2))]
        ;;(println "int1= " s1 "-" e1 "    and int2= " s2 "-" e2 "    result c1="c1 " and  c2=" c2 " res=" res)
        res ))))

