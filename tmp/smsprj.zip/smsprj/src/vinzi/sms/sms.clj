(ns vinzi.sms.sms
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias Seqable Option 
                                    AnyInteger 
                                    fn> doseq>
                                    print-env Seq tc-ignore]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [clojure.java [jdbc :as sql]]
            [vinzi.sms 
              [SmsCharMap :as scm]
              [timeExclusion :as te]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vString :as vStr]
             [vSql :as vSql]])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))

;(when-not (find-ns 'clojure.core.typed)
;  ;; if core typed does not exist nilify the annotations.
;  (defmacro ann [_ _] ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; This modules defines all functions to set up and format the
;;   sms messages that will be inserted in the sms-table
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(ann calendarSmsFormat String)

;; TODO: read from configuration file
(def calendarSmsFormat "Op %d% om %t% heeft u een afspraak met %z%.")


(ann ^:no-check get-hour-offset [SmsDate -> Double])
(defn get-hour-offset
  "Get the offset in terms of hours."
  [dt1 dt2]
  (when (and dt1 dt2)
    (let [diff (- (.getTime dt2) (.getTime dt1))]
      (double (/ diff vDate/Interval1hourMillis)))))

(ann TagMap (IPersistentMap String (HMap :mandatory {:format String})))
(def TagMap)


(ann-many (IPersistentSet Keyword)
  TagExists TagIsNotification TagIsCalendar)
;(ann TagExists (IPersistentSet Keyword))
;(ann TagIsNotification (IPersistentSet Keyword))
;(ann TagIsCalendar (IPersistentSet Keyword))

;;  a series of datastructure to process tags
(def TagExists)
(def TagIsNotification)
(def TagIsCalendar)

(def SmsName)


(ann ^:no-check set-tag-mapping [(Seqable (HMap )) -> nil])
(defn set-tag-mapping
  "Set the tag-mappings based on a tags sequence.
   (Also used during unit-testing with a default tag-set)"
  [tags]
  {:pre [(sequential? tags)]}
     (let [tags (map #(assoc % :tag (str/lower-case (:tag %))) tags) ;; ensure lower-case
           filtered-set (fn [tg] (->> tags
                                      (filter #(= (:type %) tg) )
                                      (map :tag )
                                      (set )))]
	;; map to a full record
	       (def TagMap (into {} (map #(vector (:tag %) %) tags)))
		;; map to type
	       (def TagType (zipmap (keys TagMap) (map :type (vals TagMap))))
	       (def TagExists (conj (set (map :tag tags)) IgnoreTag))
	       (def TagIsNotification (filtered-set ST_NOTIF))
	       (def TagIsCalendar (filtered-set ST_CAL))
	       (def TagIsCalNotif nil)
	       nil))

;; strip space and tranform to lower-case to prevent 
;; the difficult to find typing errors like trailing spaces of lower-case characters.
;;(ann ^:no-check key-calendar-name [(Option String) -> String])
(ann ^:no-check key-calendar-name [Any -> String])
;; stringe it can not type-check this
(def key-calendar-name (comp str/lower-case str/trim str))


(ann SmsName (IPersistentMap String String))

(ann ^:no-check set-calendar-name-mapping [Any -> nil])
(defn set-calendar-name-mapping  
  [nmeMap]
  {:pre [(or (sequential? nmeMap) (nil? nmeMap))]}
  (def SmsName (into {} (map #(vector (key-calendar-name (:calendar_header %))
                                      (:sms_name %)) nmeMap)))
  nil)

(ann ^:no-check add-calNotif-type [(HMap ) -> (HMap )])

(defn add-calNotif-type 
  "Determine type of record based on tags. If no tag is found default to ST_CAL." 
  [rec]
  (let [tps (->> rec
                 (:st_notif )
                 (#(if (sequential? %)  ;; currently we only accept one tag
		   (map TagType %)
                   (list (TagType %))) )
                 (set ))
        tpe (if (or (contains? tps nil) (= tps #{}) (tps ST_CAL))
              ST_CAL
              ST_NOTIF)]
    (println "TMP-add-calNot-tpe: record with st_notif: " (:st_notif rec)
       " has types: " tps " and maps to tpe: " tpe)
    (assoc rec :st_type tpe)))
   

;;(ann cal (U java.util.Calendar java.util.Locale nil))
(ann ^:no-check cal java.util.Calendar)
(def cal (java.util.Calendar/getInstance (java.util.Locale/getDefault)))


(ann Month (Seqable String))
(def Month ["Jan" "Febr" "Mrt" "Apr" "Mei" "Juni" "Juli" "Aug" "Sept" "Okt" "Nov" "Dec"])


(ann ^:no-check get-date-string [SmsDate -> String])
(defn get-date-string 
  [dt]
  (if dt
    (do
      (.setTime cal dt)
      (let [dow (get vDate/dayOfWeek (.get cal java.util.Calendar/DAY_OF_WEEK))
            mon (get Month (.get cal java.util.Calendar/MONTH))
            day (.get cal java.util.Calendar/DAY_OF_MONTH)]
      (str dow " " day " " mon)))
    ""))


(ann get-zvl-name [(Option String) -> String])
(defn get-zvl-name
  "Lookup the zorgverlener name based on the name of the calendar. If
   no mapping is given return the calendar name."
  [calNme]
  (str (if-let [zvlNme (get SmsName (key-calendar-name calNme))]
         zvlNme
         calNme)))  ;; no mapping available


(ann expand-sms-params [SmsMsg -> SmsMsg])
(defn expand-sms-params
  [rec]
  (if-let [msg (:sms_msg rec)]
    (let [;;get-time (fn [t] (->> t (str ) (#(str/split % #":")) (take 2) (str/join ":")))
          pars {:z (get-zvl-name (:xt_event_zvl rec))
                :z2 (get-zvl-name (:xt_event_zvl_2 rec))
                :t  (te/get-time (:xt_event_time rec))
                :t2 (te/get-time (:xt_event_time_2 rec))
                :d  (get-date-string (:xt_event_date rec))
                }
          _     (println "TMP: msg=" msg)
          _     (println "TMP and pars=" pars)
;;          msg (ann-form (str msg) String)
          newMsg (vStr/replace-params msg pars ["%" "%"])]
      (assoc rec :sms_msg (:code newMsg)))
    rec))



(ann  cleanse-validate-sms [SmsMsg -> SmsMsg])
(defn cleanse-validate-sms
  "Replace all characters that aren't allowed and generate
   and issue if the sms is invalid.
   Currently no validation required."
  [rec]
  ;; (str added to allow type-checking
  (assoc rec :sms_msg (scm/cleanse-string (str (:sms_msg rec)))))


(comment ;; OLD code
(ann SmsMaxLen Integer)


(ann SplitStr (IPersistentSet String))
(def SplitStr #{" " "\t" "\n" "." "," ";"})



(ann  find-split-backward [String AnyInteger -> AnyInteger])
(defn find-split-backward 
  "Find the first position at position <= pos where the string can be split
   at one of the one-character strings in SplitStr.
   Returns the index of the split-position." 
  [msg pos]
  (when (< pos 1)
    (vExcept/throw-except "(find-spit-backward): message can not be split: " msg))
  (if (SplitStr (subs msg (dec pos) pos))
     pos
     (recur msg (dec pos))))

(ann SepParts String)
(def SepParts "...")


;;(ann  split-long-sms (Fn [(PersistentHashMap Keyword Any) -> (Seqable (PersistenHashMap Keyword Any))]
 ;;                     [(PersistentHashMap Keyword Any ) Integer -> (Seqable (PersistentHashMap Keyword Any))]))
(ann ^:no-check split-long-sms (Fn [(HMap :mandatory {:sms_msg String}) -> (Seqable (HMap))]
                      [(HMap :mandatory {:sms_msg String}) Integer -> (Seqable (HMap))]))
(defn split-long-sms 
  "DEPRECATED:Split of long sms now in module vinzi.sms.submit
   If the sms-msg is longer than 160 characters, the message will be split.
   Returns a sequence of one of more messages."
  ([rec]  (split-long-sms rec SmsMaxLen))
  ([rec SmsMaxLen]
    (let [split-sms (fn [cumm rec]
                    (let [msg (:sms_msg rec)
                          inc-kd (fn [rec] 
                                    ;; increase key-date to ensure unique key-dates
                                    (if-let [kd (:st_key_date rec)]
                                       (assoc rec :st_key_date (-> kd
                                                                  (.getTime )
                                                                  (inc )
                                                                  (java.sql.Timestamp. )))
                                    rec))]
		      (if (<= (count msg) SmsMaxLen)
                        (conj cumm rec)
                        (let [pos (find-split-backward msg (- SmsMaxLen (count SepParts )))
			      part1 (assoc rec :sms_msg (str (subs msg 0 pos) SepParts))
			      part2 (assoc (inc-kd rec) :sms_msg (str SepParts (subs msg pos)))]
                          (recur (conj cumm part1) part2)))))]
    (split-sms [] rec))))

(defn split-sms-filter 
  "DEPRECATED:  splitting now happens just before submission.
     This filter splits long sms, and thus can increase the number of records."
  [cumm rec]  
  ;; filter-items
  (let [recs (split-long-sms rec)]
    (apply conj cumm recs)))

)   ;; end comment - old code        
 
;; inner function lifted to global scope for type-checking


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  tag processing

(ann  add-tag [SmsMsg String -> SmsMsg])
(defn add-tag [rec tg ]
                  ;; currently only one tag allowed
                  (if (TagExists tg)
                    (if (= tg IgnoreTag)
                      (add-issue rec IGNORE_MSG)
                      (if-not (seq (:st_notif rec))
                        (assoc rec :st_notif tg)
                        (add-issue rec (str "meerdere tags: " tg " geweigerd"))))
                    (add-issue rec (str tg " bestaat niet"))))


#_(ann ^:no-check clojure.core/reduce
    (All [a c] (Fn 
                 [(Fn [a c -> (U a (Reduced a))]) (clojure.core.typed/NonEmptySeqable c) -> a] 
                 [(Fn [a c -> (U a (Reduced a))] [-> (U a (Reduced a))]) (Option (clojure.lang.Seqable c)) -> a] 
                 [(Fn [a c -> (U a (Reduced a))]) a (Option (clojure.lang.Seqable c)) -> a]))
     
     )

(ann  extract-add-tags [SmsMsg -> SmsMsg])
(defn extract-add-tags
  "Extract all tags from the :xt_msg and add them to :st_notif."
  [rec]
  (let [tags (when-let [msg (:xt_msg rec)]
                ;; str added to allow type-check
               (re-seq #"#[\w]*" (str msg)))
        ;;  next filter is needed for core.typed as re-seq can contains sub-sequences
        ;;   (however not with this regexp)
        tags  (filter string? tags)  ;; needed for core.typed
        tags (map str/lower-case tags)
        res (if (nil? tags)
              rec
              (reduce add-tag rec tags))]
      res))



(ann  derive-sms_msg-fmt [SmsMsg -> SmsMsg])
(defn derive-sms_msg-fmt
  "Derive the :sms_msg from the st_notif. :sms_msg should be empty."
  [rec]
  {:pre []}
  (let [res (if-not (seq (:sms_msg rec))
              (let [add-notif (fn> [notif :- (U String nil)] 
                                 (if-let [msg (-> notif (TagMap ) (:format))]
                                   (assoc rec :sms_msg (if-let [curr (:sms_msg rec)]
                                                         (str curr "|" msg)
                                                         (str msg)))  ;; <-- core.typed requires str as it thinks msg might be character
                                   (add-issue rec (str "Notificatie " notif " niet herkend"))))
                    notifs (:st_notif rec)] 
                (print-env " in derive-sms_msg-fmt")
                (if (or (seq? notifs) (vector? notifs))
                  (doseq> [n :- (U String nil) (filter string? notifs)] 
                    (add-notif n))
                  (if (string? notifs)   ;;; core.typed: extra check to satify core.typed (ct inferred it might be a seqable still
                    (add-notif notifs)
                    rec)))
              (add-issue rec "Message is set, can not override"))]
    (if (nil? res)   ;; core-typed requires this additional test
      rec
    res)))

(tc-ignore

(ann  derive-sms_msg-cal-fmt [SmsMsg -> SmsMsg])
(defn derive-sms_msg-cal-fmt
  "Derive the sms-msg for a calendar items. If notifications are present these are
   used, otherwise a standard message is created."
  [rec]
  (let [res (if (:st_notif rec)
              (derive-sms_msg-fmt rec)
              (assoc rec :sms_msg calendarSmsFormat))]
    res))


(ann  derive-sms_msg-calNotifs-fmt [SmsMsgSeq -> SmsMsgSeq])
(defn derive-sms_msg-calNotifs-fmt [recs]
  (let [dsm (fn> [rec :- SmsRec]
               (if (= (:st_type rec) ST_CAL) 
                 (derive-sms_msg-cal-fmt rec)
                 (derive-sms_msg-fmt rec)))]
    (map dsm recs)))


(ann NO-MERGE Boolean)
(def NO-MERGE false)

(when NO-MERGE
   (println "################  NO-MERGING of records!!! ################"))


;;  using Union type to get the right functional behavior
;;(ann secondaryZvl (U IPersistentSet (Fn [String -> Boolean])))
;; Not needed as long as you define the type of the IPersistentSet
(ann secondaryZvl (IPersistentSet String))
(def secondaryZvl #{"Assistenten"})


(ann mmc-get-key [SmsMsg -> (Seqable String)])
(defn- mmc-get-key
  "Annotated helper of merge-multi-calNotif."
  [rec]
  (let [res (map rec [:xt_ptnt_nr :xt_event_date])]
    res))


(ann mmc-get-time-range [SmsMsgSeq -> String])
(defn- mmc-get-time-range [evts]
  (let [res (:xt_event_time (first evts))]
    res))


(ann mmc-get-multi-rec [(Seqable SmsMsgSeq) SmsMsg -> SmsMsg])
(defn- mmc-get-multi-rec 
  "DEPRECATED:
  When there are 2 sequences in recs there are two zorgverlener, with overlapping
   time-intervals for the same patient. Resolve this conflict here.
   Where secondary_zvl is removed when possible."
  [recs mrec]
  (let [res (if (> (count recs) 1)
              (let [evt2 (second recs)
                    zvl2 (:xt_event_zvl (first evt2))
                    time2 (mmc-get-time-range evt2)]
                (if (and (= time2 (:xt_event_time mrec))
                         (or (secondaryZvl (:xt_event_zvl mrec))
                             (secondaryZvl zvl2)))
                  ;; Special case that both appointments start at the 
                  ;; same time, and one is marked as secondary
                  ;; (might be reservation of a room or an
                  ;;  additional pair of hands)
                  (if (secondaryZvl zvl2)
                    mrec
                    (assoc mrec :xt_event_zvl zvl2))
                  ;; not same time, so do not check for secondary
                  (assoc mrec
                         :xt_event_zvl_2 zvl2
                         :xt_event_time_2 time2)))
              ;; else: it is onlty a single record
              mrec)]
    res))


(ann  mmc-get-merge-zvl-sort-time [SmsMsgSeq -> (Seqable SmsMsgSeq)])
(defn- mmc-get-merge-zvl-sort-time 
  "Group all records by zvl and subsequently sort by time."
  [recs]
  (let [res (->> recs
                 ;;(     (partition-by :xt_event_zvl ))
                 ;; using group-by+sort-by instead of partition-by
                 ;; to filter out when someone comes back to the
                 ;; first zvl
                 (group-by :xt_event_zvl )
                 (vals )
                 (map (partial sort-by te/get-timeLong) ) ;; sorteer per zorgverlener
                 (sort-by (comp te/get-timeLong first) )
;;                 (DbMsg_TcC )
                 )] ;; sorteer alle records
                           ;; extend this to a time-range (when multiple events)
                           ;; NOTE: currently only takes start-time !!
    res))

(defn mmc-split-on-gaps 
  "Recs is a list of lists. Where each item is a time-ordered list of all appointments between the same
   patient and the same zorgverlener at the same day. Where appointsments are order
   ascending in time. This function splits sequences containing gaps of more than 15 minutes
   (non-contiguous sequences of appointments)."
  [recs]
  (let [red-split-list (fn [cumm zrecs] 
                         (let [red (fn [{:keys [cumm lstTime]} r]
                                     (let [rtime (te/get-timeLong r)]
                                       (if (or (nil? lstTime) (> (- rtime lstTime) te/MaxSlotLength))
                                         ;; start a new appointmentgroup.
                                         {:cumm (conj cumm [r]) 
                                          :lstTime rtime}
                                         ;; extend the existing appointment group
                                         (let [head (drop-last cumm)
                                               lst  (-> (last cumm)
                                                        (conj r))]
                                           {:cumm (conj head lst)
                                            :lstTime rtime}))))
                               ;; redue a single list
                               zrecs (->> (reduce red {:cumm []
                                                       :lstTime 0} zrecs)
                                          :cumm)]
                           (apply conj cumm zrecs)))]
    (reduce red-split-list [] recs)))


(defn mmc-red-appointment-sets
  "The recs is a time-sequenced set of appointsment of the same patient with the same zvl.
   Cumm is a cumnmulator containing a sequences sets of recs that do not overlap.
  The reduction function determines the overlap with each of the (elements of the) sets. If
  recs belongs to multple sets these sets are merged. If overlaps with non of the other recs 
  it will become a set by itself." 
  ;; The cummulator is is list of lists of lists 
  ;; (list of aapointment-clusters (set of zvl (list of timeslots per zvl)))
  [cumm recs]
  (let [overlaps-with-set (fn [recsSet]
                            (let [check-overlap #(te/time-overlap recs %)]
                              [(some check-overlap recsSet) recsSet]))
        ;; find all sets that do overlap and that do not overlap
        [overlap nonOverlap] (let [cumm (map overlaps-with-set cumm)
                                   cumm (group-by first cumm)
                                   overlap (map second (get cumm true))
                                   nonOverlap (map second (get cumm nil))]
                               [overlap nonOverlap])
        ;; all sets from the verlapping sets are merged with sets
        recs (set (list recs)) ;; turn recs into a singleton set (contains one list of records)
;        _ (do
;            (println "interm overlap = " overlap)
;            (println "interme nonOverlap = " nonOverlap) 
;            (println "singleton set = " recs))
        overlap (apply set/union recs overlap) 
        res (conj nonOverlap overlap)]
;    (println " corrected overlap= " overlap)
;    (println "  results = " res)
    res))


(ann mmc-get-st_notif [SmsMsgSeq -> (Seqable String)])
(defn- mmc-get-st_notif
  [recs] 
  (let [lpf "(mmc-get-st_notif): "
        st_notif (->> recs
		      (map :st_notif)
                      (map str )  ;; translate nils to empty strings
                      (map str/trim )
		      (set )
		      (#(disj % nil ""))
		      (seq )
	              (sort ) 
                      (seq ) )]  ;; TODO: silent ignore in case of multiple notifs !! (voorkeursoptie van Sanne)
   (when (> (count st_notif) 1)
     (debug lpf " multiple notifs for records: " (str/join "|" st_notif)))
   (first st_notif)))

(defn mmc-remove-secondary-zvl 
  "Receives a set of appointment that overlaps and removes the appointments with a
   secondary-zvl, unless no primary zvl remain."
  [recGroup]
  (let [{:keys [prim sec]} (group-by #(if (secondaryZvl (:xt_event_zvl %))
                                        :sec
                                        :prim) recGroup)]
    (if (seq prim)
      prim
      sec)))


(defn mmc-merge-rec 
  "Gets a set/sequence of overlapping appointments and reduces them to
   a single appointment (merging times and messages)."
  [recs]
  (if (= (count recs) 1)
    (ffirst recs) ;; no merge needed (only single record)
    (let [recs (sort-by (comp te/get-timeLong first) recs) ;; determine hich zvl starts
          event_time (mmc-get-time-range (first recs)) ;; determin his/her timerange
          recs (apply concat recs)
          recs (sort-by te/get-timeLong  recs)
          st_notif (mmc-get-st_notif recs)
          st_type  (->> recs
                        (map :st_type )
                        (set )
                        (#(if (% ST_CAL) ST_CAL ST_NOTIF) ))  ;; Reduce to single label, prefer ST_CAL
          xt_msg (->> recs
                      (map :xt_msg )
                      (filter #(and (seq %) (seq (str/trim (str %)))) ) ;; remove empty messages
                      (str/join "| " ))
          otherZvl  (->> (map :xt_event_zvl (rest recs))
                         (set )
                         (#(disj % (:xt_event_zvl (first recs))) )
                         (str/join "," ))
          otherTime (:xt_event_time (second recs))
          mrec (assoc  (first recs) ;;(ffirst recs) 
                      :xt_event_zvl_2 otherZvl
                      :xt_event_time_2 otherTime
                      :st_type  st_type
                      :st_notif st_notif
                      :xt_msg xt_msg
                      :xt_event_time event_time)
          ]
      mrec
  )))



(ann merge-multi-calNotif [SmsMsgSeq -> SmsMsgSeq])
(defn merge-multi-calNotif
  "Perform a merge operations over the processed Notification and Calendar messages
   to merge them into a single message per patient (per event-date).
   This operation is performed after processing the individual messages, so 
   it can concatenate/merge st_notif and st_msg."
  [msgs]  
  (if NO-MERGE
    msgs
  (let [lpf "(merge-multi-calNotif): " 
;;        get-key #(map % [:xt_ptnt_nr :xt_event_date])
	merge-msgs (fn> [recs :- SmsMsgSeq]
                     ;; receives a set of records belonging to a single
                     ;; patients appointments at a specific event-date.
                     ;; All these records should be merge to a single record.
                     (if (= (count recs) 1)
                        recs  ;; no merge needed
		     (let [recs (mmc-get-merge-zvl-sort-time recs)
                           recs (mmc-split-on-gaps recs)
                           recGroups (reduce mmc-red-appointment-sets [] recs)
                           recGroups (map mmc-remove-secondary-zvl recGroups)            
                   _ (println "\trecGroups= " recGroups)        
                           mrecs  (map mmc-merge-rec recGroups)
                   _ (println "\tmrecs (pre)= " mrecs)        
                           ;; take one level out of neste lists
                   ;        mrecs (apply concat mrecs)
			]
 (println "\tmrecs = " mrecs
          "\n\t\t  having type: " (type mrecs))
                       mrecs)))
        msgs (->>  msgs
                (group-by mmc-get-key )
		(vals )
                (map merge-msgs )
                (apply concat ))
        ]
  msgs)))



#_(ann process-list-func [(Fn [(HMap) -> (HMap)])
                        (Fn [(Seqable (HMap)) -> (Seqable (HMap))])
                        (Fn [(Seqable (HMap)) (HMap) -> (Seqable (HMap))])
                        -> (Fn [(Seqable (HMap)) -> (Seqable (HMap))]) ])
(ann process-list-func [String
                        (Fn [SmsMsg -> SmsMsg])
                        (Fn [SmsMsgSeq -> SmsMsgSeq])
                        (Fn [SmsMsgSeq SmsMsg -> SmsMsgSeq])
                        -> (Fn [SmsMsgSeq -> SmsMsgSeq]) ])

(defn process-list-func
  "Do the processing a list of messages with a specific set of functions."
  [lpf process-item process-list filter-items]
  (fn [data]
    (->> data
         (#(do (debug lpf "Received " (count %) " items.") %) )
         (map process-item )
         (#(do (debug lpf "After map process-item " (count %) " items.") %) )
	 (process-list )
         (#(do (debug lpf "After process-list " (count %) " items.") %) )
         (reduce filter-items [] )
         (#(do (debug lpf "After filter-items " (count %) " items.") %) )
     )))



(ann get-jour-message [SmsMsg -> String])
(defn get-jour-message 
  "Extract the journal tekst from the plain-tekst by taking everything
   after #sms."
  [rec]
  (->> rec
       (:xt_msg )
       (str )
       (re-find #"(?iu)#sms[\s]*([\w\W]*)" )
       (second )))


(ann add-jour-deadline [SmsMsgSeq -> SmsMsgSeq])
(defn add-jour-deadline 
  "Messages should be submitted within DMlifetimeDays after being created."
  [recs]
  (let [add-deadline (fn> [rec :- SmsMsg]
                       (let [dl (vDate/get-TS-dayOffset 
                                    (:xt_key_date rec) DMlifetimeDays)]
                       (assoc rec :st_submit_deadline dl)))]
    (map add-deadline recs)))


(ann process-jour [SmsMsgSeq -> SmsMsgSeq])
(def process-jour (process-list-func
		   "(process-jour): " 
                   (fn> [rec :- SmsMsg]  ;; process-item
                     (assoc rec
                       :st_type ST_MSG
                       :sms_msg (get-jour-message rec)))
		   add-jour-deadline
                   (fn> [cumm :- SmsMsgSeq rec :- SmsMsg]  ;; filter-items
                     ;; no specific filtering on journal items
                     (conj cumm rec))))


(ann ^:no-check getTime [java.sql.Timestamp -> Long])
(defn getTime 
  "Function used as I can not annotate .getTime (yet)."
  [dt] 
  (.getTime dt))




(ann add-calNotif-deadline [(Seqable (HMap)) -> (HMap)])

(defn add-calNotif-deadline 
  "Add a deadline relative to the event-date."
  [recs]
  (let [add-deadline (fn [rec]
                       (let [rec (if (sequential? rec)
                                   (let [msg (str "(add-calNotif-deadline): record is sequential with " (count rec) " items: " rec " (taking first item only)")]
					(println msg) (debug msg)
                                        (first rec)) 
                                   rec)
                             dl (if (= (:st_type rec) ST_NOTIF)
                                  LatestNotifHours
                                  LatestReminderHours)
                             ed (:xt_event_date rec) 
                             et (:xt_event_time rec) 
                            ;; replace as I can not annotate .getTime (yet)
                            ;; dt (when (and ed et)
                            ;;      (java.sql.Timestamp. 
                            ;;        (+ (.getTime ed)
                            ;;         (.getTime et))))
                             dt (when (and ed et)
                                  (java.sql.Timestamp. 
                                    (+ (getTime ed)
                                     (getTime et))))
                             dl (when dt (vDate/get-TS-hourOffset dt dl))]
                       (assoc rec :st_submit_deadline dl)))]
    (map add-deadline recs)))

(defn get-event-datetime 
  "Compute event timestamp assuming :xt_event_time is still in sql-format (not a string)." 
  [rec]
  (-> (+ (.getTime (:xt_event_date rec)) (.getTime (:xt_event_time rec)))
    ;; correction as times also have a 1 hour correction relative to UTC
    (+ vDate/Interval1hourMillis)
    (java.sql.Timestamp. ) ))

;; actually no check
(ann ^:no-check process-calNotif (Fn [(Seqable (HMap)) -> (Seqable (HMap))]))

(def process-calNotif (process-list-func
                          ;; calNotif processing of a single item
                          "(process-calNotif): " 
                            (fn [rec]  ;; process-item
                              (-> rec
                                  ;;(assoc :st_type ST_CAL)
                                  (extract-add-tags )
                                  (add-calNotif-type )
                                  ;; generate a function that performs the check
                                  ((te/get-check-timeExclusions-func) )
                                 ;; (derive-sms_msg-cal) 
                             ))
                        ;; calNotif Processing of the complete list
		       (comp derive-sms_msg-calNotifs-fmt
                          add-calNotif-deadline
                          merge-multi-calNotif)  ;; merge AFSPR (?or CAL?) and NOTIF 
                       ;; calNotif  filter the list
                       (fn [cumm rec]  ;; filter-items
                         (let [lpf "(filter-calNotif): "
                               tpe (:st_type rec)
                               event_dt   (get-event-datetime rec)
                               event_hoffs (or (get-hour-offset vDate/Now event_dt)
                                              0.0)]
                           (debug lpf " TMP: :xt_event_date=" (:xt_event_date rec) " :xt_event_time=" (:xt_event_time rec)
                               " translates to: " event_dt  "  and has :xt_key_date="  (:xt_key_date rec)
                               "  and has an hours-offset relative to now " vDate/Now " of " event_hoffs)
                           (if (or (and (= tpe ST_CAL)  ;; 
                                         (>  event_hoffs AfsprHoursLatest))
                                    (and (= tpe ST_NOTIF)
                                         (> event_hoffs NotifHoursLatest)
                                           ;; er moeten notificaties zijn
                                           (seq (:st_notif rec)))) 
                             (conj cumm rec)
                             (let [showReject true
                                   showFullRec false] 
				(when showFullRec (debug "DUMP FILTER dropping: " rec))
				(when showReject
                                  (debug "TMP-REJECT: " 
                                      (select-keys rec [:xt_event_date :xt_event_time 
                                                        :xt_key_notif :st_type] ) 
                                      "\n\tCHECK HOUR-OFFS: " event_hoffs " > "
                                        (if (= tpe ST_CAL) AfsprHoursLatest NotifHoursLatest)
					(if (and (= tpe ST_NOTIF) 
                                                   (not (seq (:st_notif rec)))) 
                                           " AND no notifications" "")))
                                cumm))))))



;(def process-notifications (process-list-func
;                             "--decprecated--" 
;                            (fn [rec]  ;; process-item
;                              (-> rec
;                                  (assoc :st_type ST_NOTIF)
;                                  (extract-add-tags )
;                                  (derive-sms_msg )))
;                            (fn [cumm rec]  ;; filter-items
;                              (let [tag (:st_notif rec)]
;                                (if (TagIsNotification tag)
;                                  (conj cumm rec)
;                                  cumm)))))


(ann update-rec-state [(HMap) -> (HMap)])

(def AutoConfirm (atom false))

(ann AcceptStatOnbekend Boolean)
(def AcceptStatOnbekend (atom false))

(defn update-rec-state
  "Update state of record based on auto-confirm and presence of issues. "
  [rec]
  (let [nweState (if (seq (:st_issues rec))
                   STATE_ISSUE   ;; always fail on issues
                   (if @AutoConfirm
                     STATE_CONFIRM
                     STATE_READY))]
 ;;   (print "state updated to: " nweState " for record: " rec)
    (assoc rec :st_state nweState)))


(ann update-state-recs [(Seqable (HMap)) -> (Seqable (HMap))])

(defn update-state-recs
  [recs]
  {:pre [(sequential? recs)]}
  (map update-rec-state recs))


(defn identity-filter
  [cumm rec]
   (conj cumm rec))

(ann post-process-generic [(Seqable (HMap)) -> (Seqable (HMap))])

(def post-process-generic (process-list-func
                           "(post-process-generic): " 
                           (fn [rec]   ;; post-processing
                             (-> rec
                                 (expand-sms-params )
                                 (cleanse-validate-sms )
                              ;;   (update-state )
                                 ))
                           identity
			   identity-filter ;; split-sms-filter
))



(ann  add-ptntInfo [(Seqable (HMap)) (Seqable (HMap)) -> (Seqable (HMap))])

(defn add-ptntInfo
  "Add mobiel and SMS status to all records in data."
  [ptntInfo data]
  (let [lpf "(add-ptntInfo): "
        orgPtntInfo ptntInfo  ;; for debugging
        ptntInfo (into {} (map #(vector (:ptnt_nr %) %) ptntInfo))
        ;;  WEIRD: Here I shadow the name of the surrounding function (with a different arity  !!
        add-ptntInfo (fn [rec]
                       (if-let [pi (ptntInfo (:xt_ptnt_nr rec))]
			(if (:actief pi)
                          (-> (case (:sms_status pi)
                                      SMS_ON rec
                                      SMS_OFF (add-issue rec "SMS OFF")
                                      SMS_?   (if @AcceptStatOnbekend
                                                (do
                                                  (debug lpf "accept ONBEKEND for rec: " rec)
                                                rec)
                                                (add-issue rec "SMS status onbekend"))
                                      (add-issue rec "Invalid SMS-state"))
                           (assoc 
                           :sms_mobiel (:sms_mobiel pi)
                           :sms_status (:sms_status pi)
                           :st_issues (vec (concat (:st_issues rec)
                                                        (:st_issues pi)))))
                         (add-issue rec PAT_UITGESCHR))
                         (do
                           (error lpf "No patient data for record: " rec)
                           (assoc rec :sms_mobiel nil
                                  :sms_status nil
                                  :st_issues (conj (vec (:st_issues rec))
                                                   NO_PATIENT_DATA)))))]
    (let [res (map add-ptntInfo data)
          frec (first res)
          fkey (:ptnt_nr frec)
          pi (ptntInfo fkey)
          ]
      (println lpf "Ready")
      (println lpf "first three result: " (take 3 res))
      (println lpf "first three ptntInfo: " (take 3 ptntInfo))
      (println lpf "ptntInfo of first three: "
           (into {} (map #(vector (:ptnt_nr %) %) (take 3 orgPtntInfo))))

      (println "first had key: " fkey " and info " pi)
      res)))


(defn check-seq-hm [shm]
  (let [lpf "(check-seq-hm): "]
     (when-let [incorrect (seq (remove map? shm))]
      (vExcept/throw-except lpf " Check failed on: " incorrect))
    shm))



(ann post-sms-messages [(Seqable (HMap)) (Seqable (HMap)) (Seqable (HMap)) -> (Seqable (HMap))])


(def TMPSTORE (atom {}))

(defn store-count-check
  " Store data, report size and check if it still is a sequence of hash-maps." 
   [lbl data]
   (swap! TMPSTORE assoc lbl data)
   (debug " (count-and-store): After stage " (name lbl) " counting "  (count data) " items")
   (check-seq-hm data)
   data)

(defn process-sms-messages 
  "Collecting all sms-messages and processing them. The journal and calNotif items are first processed separately
   and next the generic processing is applied to the combined list."
  [jour calNotif ptntInfo]
  (let [lpf "(process-sms-messages): " 
        ;; First do the separate processing
        _ (debug lpf " initial count of journal items: " (count jour))
        jour (process-jour jour)
        _ (store-count-check :processedJournalItems jour)
        _ (debug lpf " initial count of calNotif items: " (count calNotif))
        calNotif (process-calNotif calNotif)
        _ (store-count-check :processedCalNotif calNotif)
	;; Next do the generic postprocessing for jour and call-notif combined
        extrMsg (->> (concat calNotif jour)
                    (store-count-check :concatenated )
                    (post-process-generic )
                    (store-count-check :postProcessGeneric )
                    (add-ptntInfo ptntInfo )
                    (store-count-check :add-ptntInfo )
                    (update-state-recs )
                    (store-count-check :updateStateRecs )
                    (stringify-st_issues )
                    (store-count-check :stringifySt_issues )
                    )]
  extrMsg))


(ann init-sms-generator [ -> nil])

(defn init-sms-generator [{:keys [sms_AutoConfirm sms_AcceptOnbekend]}]
  (let [lpf "(init-sms-generator): "]
    ;; TODO:  to be implemented to grab settings from database
    (reset! AutoConfirm (= (str/upper-case (str/trim (str sms_AutoConfirm))) "JA"))
    (debug lpf "AutoConfirm=" @AutoConfirm)
    (reset! AcceptStatOnbekend (= (str/upper-case (str/trim (str sms_AcceptOnbekend))) "JA"))
    (debug lpf "AcceptStatOnbekend=" @AcceptStatOnbekend)
    ;; set the status
    (set-accept-status (if @AcceptStatOnbekend #{SMS_ON SMS_?} #{SMS_ON}))
    (debug lpf "Accept-status=" Accept-status)
 ))



(defn report-diffs [s1 s2]
  (let [trim-same (fn [s1 s2]
                    (if (= (first s1) (first s2))
                      (recur (rest s1) (rest s2))
                      [s1 s2]))
        [t1 t2] (trim-same s1 s2)
        [u1 u2] (if (and (seq t1) (seq t2))
                  (let [[t1 t2] (trim-same (reverse t1) (reverse t2))]
                    [(reverse t1) (reverse t2)])
                  [t1 t2])
        u1 (apply str u1)
        u2 (apply str u2)]
    (println u1 " ==> " u2)))

(defn report-diffs-seq [s]
  (let [s1 (first s)]
    (println s1)
    (doseq [[n s] (map #(vector %1 %2) (next (range)) (rest s))]
      (print "\t" n ": " (report-diffs s1 s)))))


(comment
(require '[clojure.edn :as edn])

(defn compare-hmaps [hm]
  (let [hm (map edn/read-string hm)
        get-diffs (fn [m1 m2]
                    (let [m1 (set (seq m1))
                          m2 (set (seq m2))]
                     {:extra  (set/difference m2 m1)
                      :removed (set/difference m1 m2)})) 
        mand (map #(get (vec %) 2) hm)
        m1 (first mand)]
    (doseq [[n mx] (map #(vector %1 %2) (next (range)) (rest mand))]
      (if (map? mx)
        (let [{:keys [extra removed]} (get-diffs m1 mx)]
          (println "\t" n ": REMOVED: " removed " and ADDED " extra))
          (println "\t" n ": no hashmap : " mx)))))

(def srd "(HMap :mandatory {:xt_ptnt_nr java.lang.Integer
                                    :xt_create_by java.lang.String
                                    :xt_key_date  (Option SmsDate)
                                    :xt_modif_by    (Option java.lang.String)
                                    :xt_modif_date  (Option SmsDate)
                                    :xt_event_zvl   (Option java.lang.String)
                                    :xt_event_date   SmsDate
                                    :xt_event_time   java.lang.String
                                    :xt_event_descr  (Option java.lang.String)
                                    :xt_msg          (Option java.lang.String) 
                                    :st_state        (Option java.lang.String)
                                    :st_type         (Option java.lang.String)
                                    :st_create_date  SmsDate
                                    :st_modif_date        SmsDate
                                    :st_num_Modif         (U Integer Long)
                                    :st_submit_date       (Option SmsDate)
                                    :st_submit_deadline   (Option SmsDate)
                                    :st_issues            (U String (IPersistentVector java.lang.String))
                                    :st_notif             (U String nil (Seqable java.lang.String))
                                    :sms_mobiel           (Option java.lang.String)
                                    :sms_status           (Option java.lang.String)
                                    :sms_msg    (Option java.lang.String) 
                                    }
                       :optional {:xt_event_time_2 java.lang.String
                                  :xt_event_zvl_2 java.lang.String
                                  })) ")
(defn compare-hmaps-SmsMsg [hm]
  (compare-hmaps (cons srd hm)))
)  ;; end comment

)  ;; end tc-ignore

