(ns vinzi.sms.setExtractInterface
  (:use [vinzi.sms.globals]
        clojure.tools.logging
        clojure.pprint)
  (:require [vinzi.sms.scipio.extract :as xt]
            [vinzi.tools 
              [vDateTime :as vDate]
              [vSql :as vSql]]))



(def Dummy-interface-nr -1) ;; a negative values implies using the real/mysql interface

(def Dummy-interfaces [
  ;; interface 0
   {:extract-patient-data 
                     (fn [_] (list 
                                   {:ptnt_nr 1 :ptnt_ruiter "SO*" :ptnt_telefoon2 "+31612345678" :ptnt_huisartsnu "jan" :ptnt_geboren vDate/Now}
                                   {:ptnt_nr 2 :ptnt_ruiter "" :ptnt_telefoon2 "+31612345678" :ptnt_huisartsnu "piet" :ptnt_geboren vDate/Now}))
    :extract-calendar+notifications 
                     (fn [_ _] (list 
                                   {
:xt_ptnt_nr     1
:xt_create_by   "B"
:xt_create_date vDate/Now
:xt_modif_by   "A"
:xt_modif_date vDate/Now
:xt_msg        "test"
:xt_event_date vDate/Now
:xt_event_time "09:50:00.089867698"
:xt_event_zvl "jan"
:xt_event_descr ""
}))
    :extract-journal  
                     (fn [_ _] (list 
                                   {
:xt_ptnt_nr     1
:xt_create_by   "B"
:xt_create_date vDate/Now
:xt_modif_by   "A"
:xt_modif_date vDate/Now
:xt_msg        "test"
:xt_event_date vDate/Now
:xt_event_time "09:50:00.089867698"
:xt_event_zvl "jan"
:xt_event_descr ""
}))
    :build-db-descr   (fn [_] vSql/defaultDb)}
  ;; interface 1
  
  ])
      

(defn get-extraction-interface []
  (if (>= Dummy-interface-nr 0)
   (get Dummy-interfaces Dummy-interface-nr)
   {:extract-patient-data xt/extract-patient-data
    :extract-calendar+notifications xt/extract-calendar+notifications
    :extract-journal  xt/extract-journal
    :build-db-descr   xt/build-db-descr}))


;;(set-extraction-interface (get-extraction-interface))
