(ns vinzi.sms.globals
  (:use [vinzi.tools [vSql :only [sqs]]]
        [clojure.core [typed :only [check-ns ann ann-form fn> cf doseq>
                                    EmptySeqable Option AnyInteger
                                    def-alias Option print-env tc-ignore]]]
  )
  (:require [clojure [string :as str]]
            [vinzi.tools 
              [vDateTime :as vDate]
              [vFile :as vFile]
              [vExcept :as vExcept]
              [vProperties :as vProps]
              [vString :as vStr]   ;; just to collect some annotations
              [vSql :as vSql]])
 (:import [clojure.lang IPersistentSet IPersistentMap PersistentList IPersistentVector ISeq Seqable
           ;;PersistentHashSet PersistentHashMap 
           Keyword Symbol])) 

;;(when-not (find-ns 'clojure.core.typed)
;;  ;; if core typed does not exist nilify the annotations.
;;  (defmacro ann [_ _] ))

;;(tc-ignore 

(ann Debug Boolean)
(def Debug false)

(ann CvK-system Boolean)
(def CvK-system false)

(ann Schema String)
(def Schema "sms")

(ann MsgTbl String)
(def MsgTbl "messages")

(ann STATE_NONE String)
(def STATE_NONE "")
(ann STATE_READY String)
(def STATE_READY  "GEREED")
(ann STATE_CONFIRM String)
(def STATE_CONFIRM  "BEVESTIGD")
(ann STATE_SUBMITTING String)
(def STATE_SUBMITTING "ZENDEN") ;; transitional state to prevent concurrency issues
(ann STATE_SUBMITTED String)
(def STATE_SUBMITTED "VERZONDEN")
(ann STATE_TIMEOUT String)
(def STATE_TIMEOUT   "OVERTIJD")
(ann STATE_ISSUE String)
(def STATE_ISSUE   "PROBLEEM")
(ann STATE_FAILURE String)
(def STATE_FAILURE   "GEFAALD")
(ann STATE_DEL_UPDATE String)
(def STATE_DEL_UPDATE   "DEL_UPDATE")
(ann STATE_CANCELLED String)
(def STATE_CANCELLED  "CANCEL")

;; states where a record can be modified
(ann ModifiableState (IPersistentSet String))
(def ModifiableState #{STATE_NONE STATE_ISSUE STATE_READY STATE_CONFIRM STATE_CANCELLED})


;;(ann  state-count [(Seqable (HMap :mandatory {:st_state String})) String -> (IPersistentMap String Number)])
(ann  state-count [(Seqable (IPersistentMap Keyword String)) -> (IPersistentMap String Number)])
;; nocheck as it fails on keys and vals
(defn ^:no-check state-count 
   "Retrieve the state from all records and count them."
   [recs]
   {:pre [(sequential? recs)]}
   (->> (group-by :st_state recs)
        ;; (anonymous function requires annotation.
        ((fn* [x] (zipmap (keys x) (map count (vals x)))) )))


(comment  ;;; TRAsh to learn core.typed
(tc-ignore
(defn ^:no-check state-count-old 
   "Retrieve the state from all records and count them."
   [recs]
   {:pre [(sequential? recs)]}
  (print-env "pre-exec")
   (->> (group-by :st_state recs)
        (#(let [grp (ann-form % (IPersistentMap String (Seqable (IPersistentMap String Number))))]
            (print-env "na grouping: ")
            %))
        (#(let [grp-2 (ann-form % (IPersistentMap String (Seqable (IPersistentMap String Number))))]
            (print-env "na grouping-2 (type same?): ")
            %))
        (#(let [ks (keys %)
                vs (vals %)]
              (print-env "before check")
            (when (and ks vs)
              (print-env "before zipmap")
              (zipmap ks (map count vs)))))))
)

;;(ann  state-count-nt [(Seqable (HMap :mandatory {:st_state String})) String -> (IPersistentMap String Number)])
(ann  state-count-nt [(Seqable (IPersistentMap Keyword String)) -> (IPersistentMap String Number)])
;; nocheck as it fails on keys and vals
(defn state-count-nt 
   "Retrieve the state from all records and count them."
   [recs]
   {:pre [(sequential? recs)]}
  (print-env "pre-exec")
  (let [;;recs_tc (ann-form recs (Seqable (IPersistentMap Keyword String)))
        grp (group-by :st_state recs)
;;        _    (print-env "na grouping: ")
;;        ks (keys grp)
;;        vs (vals grp)]
;;    (when (and ks vs)
;;      (print-env "before zipmap")
;;      (zipmap ks (map count vs)))))
        ]
      (zipmap (keys grp) (map count (vals grp)))))

(ann ^:no-check  state-count-3-exp [(Seqable (IPersistentMap Keyword String)) -> (IPersistentMap String Number)])
(defn state-count-3-exp
  [recs]
  (do ;;(fn* [p1__51267#] (zipmap (keys p1__51267#) (count (vals p1__51267#)))) 
   (group-by :state recs)))

(ann  checked-group-by [(Seqable (IPersistentMap Keyword String)) ->(IPersistentMap String (Seqable (IPersistentMap Keyword String)))])
(defn checked-group-by
  [recs]
  (let [oper (fn> [r :- (Seqable (IPersistentMap Keyword String))]
               (group-by :state r))]
    (oper recs)))

(ann  checked-group-by-keys [(Seqable (IPersistentMap Keyword String)) ->(Seqable String)])
(defn checked-group-by-keys
  [recs]
  (->> (group-by :state recs)
       ;; the annotation below is required otherwise it does not pass
       ((ann-form #(keys %) [(IPersistentMap String (Seqable (IPersistentMap Keyword String))) -> (Seqable String)]) )))

(ann  checked-group-by-keys-2 [(Seqable (IPersistentMap Keyword String)) ->(Seqable String)])
(defn checked-group-by-keys-2
  [recs]
  (let [gk (fn> [x :- (IPersistentMap String (Seqable (IPersistentMap Keyword String)))]
               (keys x))] 
    (->> (group-by :state recs)
       ;; the annotation below is required otherwise it does not pass
         (gk ))))

(ann  dummy-3 [(Seqable (HMap :mandatory {:st_state String})) -> (Option (Seqable Keyword))])
(defn ^:no-check dummy-3 
   "Retrieve the state from all records and count them."
   [recs]
  ;; when-let is needed to pass type-checker as type-definition of keys does not accept nil
  (when-let [r (first recs)]
    (print-env "in dummy2: ")
    (keys r)))

(ann  dummy-2 [(Seqable (IPersistentMap Keyword String)) -> (Option (Seqable Keyword))])
(defn dummy-2 
   "Retrieve the state from all records and count them."
   [recs]
  ;; when-let is needed to pass type-checker as type-definition of keys does not accept nil
  (when-let [r (first recs)]
    (print-env "in dummy2: ")
    (keys r)))

;; passes typecheck
(ann  dummy [(IPersistentMap Keyword String) -> (Seqable Keyword)])
(defn dummy 
   "Retrieve the state from all records and count them."
   [rec]
  (keys rec))

)  ;;; end Trash to learn core.typed

(ann SMS_ON String)
(def SMS_ON "AAN")
(ann SMS_OFF String)
(def SMS_OFF "UIT")
(ann SMS_? String)
(def SMS_?    "ONBEKEND")

(ann IgnoreTag String)
(def IgnoreTag "#geen")

(ann MOB_INCORR String)
(def MOB_INCORR "Incorrect mobiel nummer: %s")
(ann MOB_NONE String)
(def MOB_NONE "Geen mobiel nummer")
(ann SMS_STAT_INCORRECT String)
(def SMS_STAT_INCORRECT  "SMS-status %s accepteert geen berichten")
(ann IGNORE_MSG String)
(def IGNORE_MSG  (str IgnoreTag " in bericht"))
(ann TIME_EXCLUSION String)
(def TIME_EXCLUSION "Telef.afspr.")

(ann Accept-status (IPersistentSet String))
(def ^:dynamic Accept-status #{SMS_ON})

(defn set-accept-status [newSet]
  (def Accept-status newSet))
(ann NO_PATIENT_DATA String)
(def NO_PATIENT_DATA "Geen patient-data")
(ann PAT_UITGESCHR String)
(def PAT_UITGESCHR "Patient uitgeschreven")


;; a direct message should be submitted within DMlifetimeDays after creation
(ann DMlifetimeDays Number)
(def DMlifetimeDays 4.0)
(ann LatestNotifHours Number)
(def LatestNotifHours -2.0)   
(ann LatestReminderHours Number)
(def LatestReminderHours -24.0)

(def-alias DbDescr (HMap :mandatory {:nme String }
                       :optional {
                                  :tpe (U Keyword nil)
                                  :constraint String
                                  :default (U Number String nil)}))

(def-alias DbDescrVec (IPersistentVector DbDescr))


(def-alias Interval (HMap :mandatory {:endTS java.sql.Timestamp
                                      :startTS java.sql.Timestamp
                                      :endDayTS java.sql.Timestamp
                                      :startDayTS java.sql.Timestamp}))


(comment 
(ann  DtS [DbMsgVec -> (Seqable (IPersistentMap Keyword String))])
(def ^:no-check DtS identity)

(ann  DbMsgVec-to-SIP [DbMsgVec -> (Seqable (IPersistentMap Keyword String))])
(def ^:no-check DbMsgVec-to-SIP identity)
) ;; end comment


(def-alias SmsDate (U java.sql.Date java.sql.Timestamp nil))

(def-alias SmsRaw (HMap :mandatory {:xt_ptnt_nr Integer
                                    :xt_create_by String
                                    :xt_key_date  SmsDate 
                                    :xt_modif_by  String
                                    :xt_modif_date SmsDate
                                    :xt_event_zvl String
                                    :xt_event_date SmsDate
                                    :xt_event_time String
                                    :xt_event_descr String
                                    :xt_msg String  }
                       :optional {:xt_event_time_2 String
                                  :xt_event_zvl_2 String
                                  })) 

(def-alias SmsMsg (HMap :mandatory {:xt_ptnt_nr Integer
                                    :xt_create_by String
                                    :xt_key_date  (Option SmsDate)
                                    :xt_modif_by    (Option String)
                                    :xt_modif_date  (Option SmsDate)
                                    :xt_event_zvl   (Option String)
                                    :xt_event_date   SmsDate
                                    :xt_event_time   String
                                    :xt_event_descr  (Option String)
                                    :xt_msg          (Option String) 
                                    :st_state        (Option String)
                                    :st_type         (Option String)
                                    :st_create_date  SmsDate
                                    :st_modif_date        SmsDate
                                    :st_num_Modif         (U Integer Long)
                                    :st_submit_date       (Option SmsDate)
                                    :st_submit_deadline   (Option SmsDate)
                                    :st_issues            (U (IPersistentVector String) String)
                                    :st_notif             (U String (Seqable String))
                                    :sms_mobiel           (Option String)
                                    :sms_status           (Option String)
                                    :sms_msg    (Option String) 
                                    }
                       :optional {:xt_event_time_2 String
                                  :xt_event_zvl_2 String
                                  })) 

(def-alias SmsMsgSeq (U nil (Seqable SmsMsg)))

(comment
(ann ^:no-check DbMsg_TcB 
     [   (U nil (Seqable (HMap :mandatory {}))) 
      -> DbMsgSeq])
(defn DbMsg_TcB 
  "A typecast of to DbMsgSeq."
  [x] identity x)

(ann ^:no-check DbMsg_TcC 
     [   (U nil (Seqable (Seqable (HMap :mandatory {})))) 
      -> (Seqable DbMsgSeq)])
(defn DbMsg_TcC 
  "A typecast of to (Seqable DbMsgSeq)."
  [x] identity x)

  ) ;; end comment old code

;;(ann MsgFields  (IPersistentVector (HMap :mandatory {:nme String :tpe Keyword} 
 ;;                                        :optional {:constraint String :default (U String Number nil)})))
(ann MsgFields DbDescrVec)
(def MsgFields [{:nme "id"  :tpe :serial :constraint "PRIMARY KEY"}
                {:nme "st_type"   :tpe :text :default nil}
                {:nme "st_create_date"  :tpe :timestamp :default "NOW()"}
                {:nme "st_modif_date"  :tpe :timestamp :default "NOW()"}
                {:nme "st_num_modif"   :tpe :integer :default 0}
                {:nme "st_submit_date"  :tpe :timestamp :default nil}
                {:nme "st_submit_deadline"  :tpe :timestamp :default nil}
                {:nme "st_issues"  :tpe :text :default nil}
                {:nme "st_state"  :tpe :text :default STATE_NONE}
                {:nme "xt_ptnt_nr" :tpe :integer :constraint "NOT NULL"}
                {:nme "xt_create_by" :tpe :text :default nil}
                {:nme "xt_key_date" :tpe :timestamp :default nil}
                {:nme "xt_modif_by" :tpe :text :default nil}
                {:nme "xt_modif_date" :tpe :timestamp :default nil}
                {:nme "xt_msg"  :tpe :text :default nil}
                {:nme "xt_event_date"  :tpe :timestamp :default nil}
                {:nme "xt_event_time"  :tpe :text :default nil}
                {:nme "xt_event_zvl_2"  :tpe :text :default nil}
                {:nme "xt_event_time_2"  :tpe :text :default nil}
                {:nme "xt_event_zvl"  :tpe :text :default nil}
                {:nme "xt_event_descr"  :tpe :date :default nil}
                {:nme "st_notif"  :tpe :text :default nil}
                {:nme "sms_mobiel"  :tpe :text :default nil}
                {:nme "sms_status"  :tpe :text :default nil}
                {:nme "sms_msg"     :tpe :text :default nil}
                ])

(ann TagTbl String)
(def TagTbl   "tag_definitions")
(ann ST_NOTIF String)
(def ST_NOTIF "NOTIF")
(ann ST_CAL String)
(def ST_CAL  "AFSPR")  ;; calendar
(ann ST_MSG String)
(def ST_MSG  "BERICHT")  ;; journal-item

(ann TagFields DbDescrVec)
(def TagFields [{:nme "id"  :tpe :serial :constraint "PRIMARY KEY"} 
                {:nme "tag"   :tpe :text :constraint "NOT NULL"} 
                {:nme "format"  :tpe :text :constraint "NOT NULL" :default "not defined"} 
                {:nme "type"         :tpe :text :default ST_NOTIF}]) 


;;(ann PtntFields  (IPersistentVector (HMap :mandatory {:nme String :tpe Keyword} 
;;                                         :optional {:constraint String :default (U String nil)}))) 
(ann PtntFields DbDescrVec)
(def PtntFields [{:nme "ptnt_nr"   :tpe :text :constraint "PRIMARY KEY"}
                {:nme "huisarts"  :tpe :text}
                {:nme "sms_status"  :tpe :text}
                {:nme "sms_mobiel"  :tpe :text}
                {:nme "st_issues"  :tpe :text}
                {:nme "geboortedatum"  :tpe :date}
                {:nme "roepnaam"  :tpe :text}
                {:nme "voorletters"  :tpe :text}
                {:nme "voorvoegsel"  :tpe :text}
                {:nme "achternaam"  :tpe :text}
                {:nme "actief"  :tpe :boolean}
                ])

(ann PtntTbl String)
(def PtntTbl "ptnt_contact")

(ann TimeExcludeFields  (IPersistentVector (HMap :mandatory {:nme String} 
                                         :optional {:tpe (U Keyword nil)
                                                    :constraint String 
                                                    :default (U String nil)}))) 
(def TimeExcludeFields [
                {:nme "zorgverlener"  :tpe :text}
                {:nme "dag"  :tpe :text}
                {:nme "exclusie"  :tpe :text}
                {:nme "time_exclusion_pkey" :constraint "PRIMARY KEY(zorgverlener, dag)"}])

(ann TimeExcludeTbl String)
(def TimeExcludeTbl "time_exclusion")
                
(ann MinutesWait Number)
(def MinutesWait -30)
(ann DaysInterval Number)
(def DaysInterval -4)
(ann HoursToMinutes Number)
(def HoursToMinutes 60)
(ann DaysToMinutes Number)
(def DaysToMinutes (* 24 HoursToMinutes))

(ann AfsprHoursLatest Number)
(def AfsprHoursLatest 24)  ;; notify at latest one day before appointment
(ann NotifHoursLatest Number)
(def NotifHoursLatest 2)   ;; notify at latest 2 hours before appointment

(ann JourCreatedAfter Number)
(def JourCreatedAfter (* -5 DaysToMinutes))


;;)  ;; end tc-ignore

;;   Attach issues to a record (for later reporting)

(ann ^:no-check add-issue [SmsMsg String -> SmsMsg])
(defn add-issue
  "Add an issue to the :st_issues vector of this record."
  [rec issue]
  (assoc rec :st_issues
         (if (:st_issues rec)
           (vec (concat (:st_issues rec) (list issue)))
           (vector issue))))


(ann ^:no-check stringify-st_issues [SmsMsg String -> SmsMsg])
(defn stringify-st_issues
  [recs]
  (map #(assoc % :st_issues
               (str/join "|" (:st_issues %))) recs))

;;; storage for (global) settings


;;pp not used??
;;(ann Settings Any)
;;(def Settings)



(ann SettingsDefaults  (IPersistentVector (HMap :mandatory {:setting String 
                                                            :value String 
                                                            :description String 
                                                            :input_descr String 
                                                            :access String} )))
(def SettingsDefaults [{:setting     "sms_AutoConfirm"
                        :value       "nee"
                        :description "Automatisch bevestigen van berichten (JA) of handmatig bevestigen per bericht (NEE)." 
                        :input_descr "De waarde is 'Ja' of  'Nee' (mag kleine en hoofdletters zijn)"
                        :access      "admin"}
;; settings with limited access moved to properties file
;                       {:setting     "submit_OrcaSMS"
;                        :value       "http://apps20.orcagroup.com/SmsGateway/SendSmsPost.aspx"
;                        :description "URL voor toegang tot de SMS-service" 
;                        :access      "database"}
;                       {:setting     "submit_ClientName"
;                        :value       "SAG GZC Helmerstraat"
;                        :description "Houder van SMS-contract"
;                        :access      "database"}
                       {:setting     "submit_Originator"
                        :value       "GZC-<naam>"
                        :description "De afzender vermeld in het SMS-bericht"
                        :input_descr "Maximale lengte is ... tekens."
                        :access      "admin"}
                        {:setting     "submit_Footer"
                        :value       "Reactie per SMS niet mogelijk."
                        :description "Voettekst die onder elke SMS wordt geplaatst."
                        :input_descr "Houdt voettekst s.v.p. kort."
                        :access      "admin"}
                       {:setting     "beheerders"
                        :value       ""
                        :description "Gebruikers met beheerders rechten"
                        :input_descr "Lijst van inlognamen gescheiden met spaties."
                        :access      "admin"}
                        ])

;(ann create-settings [ -> nil])
;
;(defn create-settings
;  "Should be called only once to introduce initial settings."
;  [settings]
;  (def Settings settings)
;  nil)

;;;;;;;;;;;;;;;;;;;;;;;;;; calendar name mapping  ;;;;;;;;;;;;;;;;;;;;;;;;;;;
(ann NameMapFields  (IPersistentVector (HMap :mandatory {:nme String :tpe Keyword} 
                                         :optional {:constraint String :default (U String nil)}))) 
(def NameMapFields [
                {:nme "id"  :tpe :serial :constraint "PRIMARY KEY"}
                {:nme "calendar_header"  :tpe :text :constraint "NOT NULL"}
                {:nme "sms_name"  :tpe :text :constraint "NOT NULL" } ])

(ann NameMapTbl String)
(def NameMapTbl "calendar_name_map")

;;;;;;;;;;;;;;;;;;;;;;;;;; reading properties ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(ann PropFile String)
(def PropFile "sms.properties")


(ann ^:no-check get-sms-properties [ -> (ISeq (IPersistentMap keyword String))])
(defn get-sms-properties 
  "Get the default properties from the current folder" 
  []
  (let [pf (if (vFile/file-exists PropFile) PropFile (vFile/filename "/var/vinzi/sms" PropFile))]
    (vProps/read-properties pf)))

(comment ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; create extract-binding

(def extract-patient-data)  
(def extract-calendar+notifications)
(def extract-journal)
(def build-db-descr)

(defn set-extraction-interface 
  "Install an interface by generating a root-binding for some vars."
  [extrInt]
  (let [lpf "(set-extraction-interface): "
        epd (:extract-patient-data extrInt)
        ecn (:extract-calendar+notifications extrInt)
        ej  (:extract-journal extrInt)
        bdd (:build-db-descr extrInt)]
    (if (and epd ecn ej bdd) 
      (do
        (println " setting extract-patient-data to: "  epd)
        (def extract-patient-data epd)
        (println " setting extract-calender_notifications to: "  ecn)
        (def extract-calendar+notifications ecn)
        (println " setting extract-journal to: "  ej)
        (def extract_journal ej)
        (println " setting build-db-descr to: "  bdd)
        (def build-db-descr bdd))
      (vExcept/throw-except lpf "Some parameter missing from: " extrInt
         (when (nil? epd) " extract-patient-data")
         (when (nil? ecn) " extract-calendar+notifications")
         (when (nil? ej) " extract-journal")
         (when (nil? bdd) " build-db-descr")))))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;  extract-interface


(def Dummy-interface-nr -1) ;; a negative values implies using the real/mysql interface

(def Dummy-interfaces [
  ;; interface 0
   {:extract-patient-data 
                     (fn [_] (list 
                                   {:ptnt_nr 1 :ptnt_ruiter "SO*" :ptnt_telefoon2 "+31612345678" :ptnt_huisartsnu "jan" :ptnt_geboren vDate/Now}
                                   {:ptnt_nr 2 :ptnt_ruiter "" :ptnt_telefoon2 "+31612345678" :ptnt_huisartsnu "piet" :ptnt_geboren vDate/Now}))
    :extract-calendar+notifications 
                     (fn [_ _] (list 
                                   {
:xt_ptnt_nr     1
:xt_create_by   "B"
:xt_create_date vDate/Now
:xt_modif_by   "A"
:xt_modif_date vDate/Now
:xt_msg        "test"
:xt_event_date vDate/Now
:xt_event_time "09:50:00.089867698"
:xt_event_zvl "jan"
:xt_event_descr ""
}))
    :extract-journal  
                     (fn [_ _] (list 
                                   {
:xt_ptnt_nr     1
:xt_create_by   "B"
:xt_create_date vDate/Now
:xt_modif_by   "A"
:xt_modif_date vDate/Now
:xt_msg        "test"
:xt_event_date vDate/Now
:xt_event_time "09:50:00.089867698"
:xt_event_zvl "jan"
:xt_event_descr ""
}))
    :build-db-descr   (fn [_] vSql/defaultDb)}
  ;; interface 1
  
  ])
      



(defn get-extraction-interface []
  (if (>= Dummy-interface-nr 0)
   (get Dummy-interfaces Dummy-interface-nr)
   {:extract-patient-data xt/extract-patient-data
    :extract-calendar+notifications xt/extract-calendar+notifications
    :extract-journal  xt/extract-journal
    :build-db-descr   xt/build-db-descr}))


;; now set the specified interface
(set-extraction-interface (get-extraction-interface))

)    ;; ENDccomment ??



(def-alias SmsRec (HMap :mandatory {:st_issues (U nil String) 
                                    :st_state String} ))



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for clojure.core
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(ann ^:no-check clojure.core/sequential? [Any -> Boolean])
(ann ^:no-check clojure.core/group-by  
  (All [x] 
   (Fn [;; SmsMsgSeq 
        (U Keyword 
           (Fn [SmsMsg -> x]))
        SmsMsgSeq
     -> (IPersistentMap x SmsMsg)]       
        ;; generic IPersistentMap
       [(U Keyword 
           (Fn [(IPersistentMap Keyword x) -> x]))
        (Seqable (IPersistentMap Keyword x))
     -> (IPersistentMap x (Seqable (IPersistentMap Keyword x)))]
       ;; type for HMaps
       [(U Keyword 
           (Fn [(HMap :mandatory {}) -> x]))
        (Option (Seqable (HMap :mandatory {})))
     -> (IPersistentMap x (Seqable (HMap :mandatory {})))])))

(ann ^:no-check clojure.core/sort-by  
  (All [x] 
   (Fn ;; SmsMsgSeq
       [   (U Keyword 
              (Fn [SmsMsgSeq -> x]))
           SmsMsgSeq
        -> SmsMsgSeq]
        ;; IPersistentMap
       [   (U Keyword 
              (Fn [(IPersistentMap Keyword x) -> x]))
           (Seqable (IPersistentMap Keyword x))
        -> (Seqable (IPersistentMap Keyword x))]
       ;; type for HMaps
       [   (U Keyword 
              (Fn [(HMap :mandatory {}) -> x]))
           (Seqable (HMap :mandatory {}))
        -> (Seqable (HMap :mandatory {}))]
       [   (U Keyword 
              (Fn [(HMap :mandatory {}) -> x]))
           (U nil (Seqable (HMap :mandatory {})))
        -> (U (Seqable (HMap :mandatory {})))]     
     )))

(def-alias PatInfo (HMap :mandatory {:ptnt_nr String}
                         :optional {:ptnt_vertrekdatum String
                                     :ptnt_voorv2denaam String 
                                     :ptnt_tweedenaam   String
                                     :ptnt_fullname     String
                                     :ptnt_roepnaam  String
                                     :roepnaam       String
                                     :ptnt_geboren   String
                                     :geboortedatum String
                                     :ptnt_voorletters String
                                     :voorletters String
                                     :ptnt_voorveigen   String
                                     :voorvoegsel String
                                     :actief Boolean
                                     :achternaam String
                                     :ptnt_ruiter String
                                     :sms_status String

                                     }))

(def-alias PatInfoSeq (Seqable PatInfo))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for clojure.string
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; these functions do not accept nil as input
(ann ^:no-check clojure.string/trim [String -> String])
(ann ^:no-check clojure.string/lower-case [String -> String])
(ann ^:no-check clojure.string/upper-case [String -> String])

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for clojure.tools.logging
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(def-alias LogFactoryTp Any)
(ann ^:no-check clojure.tools.logging/*logger-factory*
    Any)
(ann ^:no-check clojure.tools.logging.impl/enabled? 
     [Any Any -> Boolean])
(ann ^:no-check clojure.tools.logging/log*
     [Any Any Any Any -> nil])
(ann ^:no-check clojure.tools.logging.impl/get-logger
     [LogFactoryTp clojure.lang.Namespace -> Any])

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for vinzi.tools.vString
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(def-alias Ret_replace-params (HMap :mandatory {:code String :replCnt AnyInteger}))
(ann ^:no-check vinzi.tools.vString/replace-params
    (Fn [String (IPersistentMap Keyword String) -> Ret_replace-params]
        [String (IPersistentMap Keyword String) (Vector* String String) -> Ret_replace-params]))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for vinzi.tools.vDateTime
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(ann ^:no-check vinzi.tools.vDateTime/get-TS-minuteOffset 
     [(U java.util.Date java.sql.Date java.sql.Timestamp) Number -> java.sql.Timestamp])

(ann ^:no-check vinzi.tools.vDateTime/get-TS-startDay
     [(U java.util.Date java.sql.Date java.sql.Timestamp String) -> java.sql.Timestamp])

(ann ^:no-check vinzi.tools.vDateTime/get-TS-endDay
     [(U java.util.Date java.sql.Date java.sql.Timestamp String) -> java.sql.Timestamp])

(ann ^:no-check vinzi.tools.vDateTime/get-day-of-week
     [(U java.util.Date java.sql.Date java.sql.Timestamp String) -> Long])

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; core.typed annotations for  ...
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(ann check-all-ns [ -> nil])
(defn  check-all-ns []
  (doseq> [cns :- Symbol
           ['vinzi.sms.globals
               'vinzi.sms.sms
               'vinzi.sms.timeExclusion
               'vinzi.sms.SmsCharMap
               'vinzi.sms.matchRecs
               'vinzi.sms.intervals
               ;; 'vinzi.sms.database
               ;; 'vinzi.sms.core
               ;; 'vinzi.sms.analyse
               ;; 'vinzi.sms.patientInfo
               ;; 'vinzi.sms.submit
               ]]
    (println "\n\n###################### " cns " ################################")
    (check-ns cns))
  nil)

