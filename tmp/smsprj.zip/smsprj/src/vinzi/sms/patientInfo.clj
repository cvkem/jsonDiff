(ns vinzi.sms.patientInfo
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias ann-many Seqable Option 
                                    AnyInteger 
                                    fn> doseq>
                                    print-env Seq tc-ignore]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [clojure.java [jdbc :as sql]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vString :as vStr]
             [vSql :as vSql]]
	    [vinzi.sms 
              [globals :as gl]  ;; not strictly required
              [submit :as subm]]
            [vinzi.sms.scipio.extract :as xt])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))


;; to be improved
(ann get-ptnt-fix-naam-actief [ -> (Fn [PatInfo -> PatInfo])])
(defn ^:no-check get-ptnt-fix-naam-actief 
  "Capture current date and return a function that processes name and actief of
   a patientInfo records." 
  []
  (let [now (.getTime (java.util.Date. ))
        is-active #(or (nil? %) (> (.getTime %) now))
        surname (fn [{:keys [ptnt_voorv2denaam ptnt_tweedenaam
              		     ptnt_voorveigen ptnt_fullname]}]
                   (let [achternaam (str/replace ptnt_fullname #"~" "")]
                     (if ptnt_tweedenaam
                       (if (seq ptnt_voorv2denaam)
                         (str ptnt_voorv2denaam " " achternaam)
                         achternaam)
                       (if (seq ptnt_voorveigen)
                         (str ptnt_voorveigen " " achternaam)
                         achternaam))))]
    (fn [rec]
      (-> rec
        (dissoc :ptnt_vertrekdatum :ptnt_voorv2denaam :ptnt_tweedenaam 
              :ptnt_voorveigen :ptnt_fullname)
        (assoc :achternaam (surname rec)
             :actief (is-active (:ptnt_vertrekdatum rec)))))))

(ann ptnt-check-ruiters [PatInfo -> PatInfo])
(defn ptnt-check-ruiters
  "Check the SMS-status of a patient.
    :sms_satus Status will be set to 'ON', 'OFF' or ''"
  [rec]
  (let [smsStat (if-let [ruiters (:ptnt_ruiter rec)]
                  (let [ruiters (str/upper-case ruiters)]
                    (if (re-find #"\*SN" ruiters)
                      SMS_OFF
                      (if (re-find #"\*SO" ruiters)
                        SMS_ON
                        SMS_?)))
                  SMS_?)]
    (assoc (dissoc rec :ptnt_ruiter)
      :sms_status (str smsStat))))

(ann CleanseMobileNumber Boolean)
(def ^:dynamic CleanseMobileNumber false)


(ann set-CleanseMobileNumber [Boolean -> nil])
(defn set-CleanseMobileNumber [val]
  ;; only used for testing.
  (def CleanseMobileNumber val)
  nil)

(ann ptnt-check-mobiel [PatInfo -> PatInfo])
;; TODO: remove no-check when submit is translated to core-typed
(defn ^:no-check ptnt-check-mobiel
  "Check validity of the mobile telephone number" 
  [rec]
  (let [orgMob (:ptnt_telefoon2 rec)
       
        {:keys [mobile error]} (subm/cleanse-mobile-number orgMob)
        validmobile (and mobile
                         (= (count mobile) 12)
                         (.startsWith mobile "+31"))
        rec (assoc (dissoc rec :ptnt_telefoon2)
              :sms_mobiel (when validmobile 
			    (if CleanseMobileNumber
                              mobile
                              orgMob)))]
    (if (not validmobile) 
      (add-issue rec error)
      rec)))

(ann ptnt-check-status [SmsRec -> SmsRec])
(defn ptnt-check-status [rec]
  (let [stat (:sms_status rec)]
    (if (Accept-status stat)
      rec
      (add-issue rec (format SMS_STAT_INCORRECT stat)))))

(ann PtntRenameMap (HMap ))
(def PtntRenameMap {:ptnt_huisartsnu :huisarts
                    :ptnt_geboren    :geboortedatum
      ;;              :ptnt_fullname   :achternaam
                    :ptnt_roepnaam   :roepnaam
                    :ptnt_voorletters :voorletters
                    :ptnt_voorveigen  :voorvoegsel}) 

(ann get-fresh-ptnt-info [(HMap ) -> PatInfoSeq])
;; TODO: remove-no-check when java.jdbc in core.typed
(defn ^:no-check get-fresh-ptnt-info
  "Retrieve the most recent patient information, update the table
   and return it."
  [locSpecs]
  (let [lpf "(get-fresh-ptnt-info): "
        InsertOneByOne false
        qTbl (qsp Schema PtntTbl)
        
        ptntInfo (->> (xt/extract-patient-data locSpecs)
		      (map (get-ptnt-fix-naam-actief ))
                      (map ptnt-check-ruiters )
                      (map ptnt-check-mobiel )
                      (map ptnt-check-status )
                      (map #(set/rename-keys % PtntRenameMap) ))
        ptntRecs (stringify-st_issues ptntInfo)]
    (println "first record is: " (first ptntRecs)
             "\n\t with keys: " (keys (first ptntRecs)))
    (vSql/trunc-table Schema PtntTbl)
    (if (> (count ptntInfo) 0)
      (if InsertOneByOne
        (doseq [pt ptntRecs]
          (println "insert: " pt)
          (sql/insert-record qTbl pt))
        (apply sql/insert-records qTbl ptntRecs))
      (vExcept/throw-except lpf " No patient information found"))
    ptntInfo))

