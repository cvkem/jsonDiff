(ns vinzi.sms.scipio.extract
  (:use ;;[vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
         [clojure.tools 
         [logging :only [error info trace debug warn]]])
  (:require [clojure
             [set :as set]
             [string :as str]]
            [clojure.java [jdbc :as sql]]
            [vinzi.sms [globals :as gl]]
            [vinzi.eis.config.initialize.readConfiguration :as rc]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vFile :as vFile]
             [vSql :as vSql]]
            [vinzi.cdp.core :as cdp]))


;;(def cdpFile "sms-server.cdp.xml")


(let [sqpw rc/SqPwFile 
      sqpw (if (vFile/file-exists sqpw)
             (apply str (map first (partition 4 (drop 5 (str/trim (slurp sqpw))))))
             (do
               (warn "(vinzi.sms.scipio.extract): "
                     " No file '" rc/SqPwFile "'"
                     " containing the appropriate information!!")
             "--onbekend--"))]

  (defn build-db-descr [locSpecs]
    (let [lpf "(build-db-descr): "
          {:keys [server port database]} (:his locSpecs)]
      (if (and server port database)
        (if gl/CvK-system
          vSql/defaultDb
          (let [dbDescr {:classname "com.mysql.jdbc.Driver"
           :subprotocol "mysql"
           :subname (str "//" server ":" port "/" database)
           :user "SAGQuery"
           :password sqpw}]
	    (def ^:dynamic TMP_dbDescr dbDescr) ;; for debugging
	   dbDescr))
        (vExcept/throw-except lpf "missing parameters server="server
                              " port=" port " and database=" database))))
  )

(def JourFields [:jour_ptnt_nr :jour_wat :jour_icpc :jour_creat_dat :jour_mod_dat :jour_creat_by :jour_mod_by :jour_plantekst])

(def JourWatCode  "Q")  

(def JourMapping {:jour_ptnt_nr  :xt_ptnt_nr
                  :jour_creat_by :xt_create_by
                  :jour_creat_dat :xt_key_date
                  :jour_mod_by    :xt_modif_by
                  :jour_mod_dat    :xt_modif_date
                  :jour_plantekst :xt_msg
                  :jour_datum :xt_event_date
                  :jour_tijd  :xt_event_time
                  :jour_auteur :xt_auteur
                  })
(def JourKeys (keys JourMapping))

(def CalendarFields [:agna_arts :agna_kleur
                     :agna_creat_dat :agna_creat_by
                     :agna_mod_dat :agna_mod_by
                     :agna_creat_dat
                     :agna_datum :agna_tijd
                     :agna_afspr :agna_ptnt_nr
                     :agna_extra_tekst])

(def CalendarMapping {:agna_ptnt_nr  :xt_ptnt_nr
                      :agna_arts     :xt_event_zvl
                      :agna_creat_by :xt_create_by
                      :key_datetime  :xt_key_date
                      :agna_mod_by    :xt_modif_by
                      :agna_mod_dat   :xt_modif_date
                      :agna_datum     :xt_event_date
                      :agna_tijd      :xt_event_time
                      :agna_extra_tekst :xt_msg
                      })

(def CalendarKeys (keys CalendarMapping))

(def NotifMapping CalendarMapping)
     ;; {:agna_ptnt_nr  :xt_ptnt_nr
     ;;               :agna_arts     :xt_event_zvl
     ;;               :agna_creat_dat :xt_create_date
     ;;               :agna_datum     :xt_event_date
     ;;               :agna_tijd      :xt_event_time
     ;;               :agna_extra_tekst :xt_msg
     ;;               })

(def NotifKeys (keys NotifMapping))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  Internal functions (extractors)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



(defn extract-raw-cal-notif
;;  "Extract items the calendar that (;;;have been created before ´createdBefore')
  "Extract items the calendar that and that have a plannend time
   within the interval [startTS, endTS]."
  ([locSpec interval] (extract-raw-cal-notif locSpec interval [">=" "<="] ""))
  ([locSpec {:keys [startTS endTS]} [lComp rComp] extraConstraint]
    (let [startStr (vDate/generate-sql-date-str startTS)
          endStr (vDate/generate-sql-date-str endTS)]
      (sql/with-connection (build-db-descr locSpec)
        (let [flds (str/join ", " (map name CalendarFields)) 
              qry (str "SELECT "  flds
                     " , ADDTIME(agna_datum, agna_tijd) AS key_datetime "
                     " FROM agna WHERE "
                       " ADDTIME(agna_datum, agna_tijd) " lComp (sqs startStr)
                     " AND ADDTIME(agna_datum, agna_tijd) " rComp (sqs endStr)
	  	   " AND NOT(agna_ptnt_nr = 0) "  ;; ptnt_nr = 0 zijn lege agenda-slots
                     extraConstraint
                     " ORDER BY ADDTIME(agna_datum, agna_tijd) ASC;")]
          (debug "\nCAL/NOTIF-qry: " qry)
          (sql/with-query-results res [qry]
            (doall res)))))))

(defn extract-raw-calendar
;;  "Extract items the calendar that have been created before ´createdBefore'
  "Extract items the calendar that have a plannend time within the interval 
    [startTS, endTS].
    Two adjustments are made to handle appointments that are only partially covered by current interval.
       1. the resultset is expanded for patients having additional appointments later that day.
       2. Appointments for patients that had earlier appointments on that day, but outside the current interval are removed."
  [locSpec interval]
  (let [lpf "(extract-raw-calendar): "
        intDays (double (/ (- (.getTime (:endTS interval)) 
                              (.getTime (:startTS interval))) 
                   vDate/Interval1dayMillis))
        data  (extract-raw-cal-notif locSpec interval) 
        _   (debug lpf " raw query returned: " (count data) "  records")
        get-ptnt-constraint (fn [data]
                              (debug lpf " data has " (count data) " elements. "
                                  " first : "  (first data))
                              (when-let [ptnt_nrs (seq (map :agna_ptnt_nr data))]
                                (let [sel (str/join "," ptnt_nrs)]
                                  (debug lpf " ptnt_nrs: " sel)
                                  (str " AND agna_ptnt_nr IN (" sel ") "))))
        expand-d (fn [data]
                   ;; expand a data-set by adding appointments later on the day of patients in current selection
                   ;; prune appointments of patients that had an appointment on the same day, but before the start of this dataset.
                   (let [initNum (count data)
                         {:keys [startTS startDayTS]} interval
                         headInt (hash-map :startTS startDayTS
                                           :endTS   startTS)
                         ;; remove all patients that have an appointment earlier
                         ;; that day as these appointment have been combined already.
                         ;; (first appointment of day is leading)
                         headEod (-> (vDate/get-TS-endDay startTS) ;; end of first day of interval
                                     (.getTime ))
                         _  (debug lpf "  startTS= "  startTS  " maps to headEod=" headEod  " (" (java.sql.Timestamp. headEod) ")")
                         data (group-by #(<= (.getTime (:key_datetime %)) headEod) data)
                         rmPtnt  (if-let [ptCstrt (get-ptnt-constraint (get data true))  ]
                                   (->> (extract-raw-cal-notif locSpec headInt 
                                     [">=" "<"] ptCstrt )
                                    (map :agna_ptnt_nr )
                                    (set ))
                                    #{})
                         ;; construct the corrected dataset
                         headCnt (count (get data true))
                         tailCnt (count (get data false))
                         ;; reconstruct the data from the two parts.
                         TMP_removed (->> (get data true) 
                                          (filter #(rmPtnt (:agna_ptnt_nr %)) )
                                          (map #(hash-map :agna_ptnt_nr (:agna_ptnt_nr %)
                                                         :key_date_time (:key_date_time %)) ))
                         data (concat (get data false)
                                      (remove #(rmPtnt (:agna_ptnt_nr %)) 
                                               (get data true)))
                         removeNum (- initNum (count data))
                         _ (debug lpf " removed "  removeNum "  out of " headCnt "  as their ptnt_nr is in: " rmPtnt
                              "\n\t Now the total dataset contains: " (count data))
                         _ (debug lpf " Removed records: "  TMP_removed) 
                        {:keys [endDayTS startTS endTS]} interval
                        tailInt (hash-map :startTS endTS
                                          :endTS   endDayTS)
                        tailSod (-> (vDate/get-TS-startDay endTS)  ;; get the start of the last day of interval
                                    (.getTime ))
                         _  (debug lpf "  endTS= "  endTS  " maps to tailSod=" tailSod  " (" (java.sql.Timestamp. tailSod) ")")
                        data (group-by #(>= (.getTime (:key_datetime %)) tailSod) data)
                        addPtnt  (if-let [ptCstrt (get-ptnt-constraint (get data true))]
                                   (extract-raw-cal-notif locSpec tailInt 
                                     [">" "<="] ptCstrt)
                                     ())
                        addNum (count addPtnt)
                        data   (concat (get data true) (get data false) addPtnt)]
                      (debug "expand-d removed " removeNum " records and added "
                           addNum " records."
                           "\n\tNumber of records changed from" initNum " to "  (count data))
                      data)) ]
        (if (> intDays 1.0)
          (expand-d data)
          data)))  ;; if interval is shorter than one day expansion won't work.



(defn extract-raw-journal
  "Extract items from the journal with jour_wat = 'Q'.
   The datbase connection is retrieved from locSpecs.
   Uses jour_creat_dat to limit the time-interval,
   so edits to a message older than 4 days will not result in
   a resubmit."  
  [locSpec {:keys [startTS endTS]}]
  (sql/with-connection (build-db-descr locSpec)
    (let [startStr (vDate/generate-sql-date-str startTS)
          endStr (vDate/generate-sql-date-str endTS)
          flds (str/join ", " (map name JourFields)) 
          qry (str "SELECT "  flds " FROM jour WHERE "
                   " jour_creat_dat >= " (sqs startStr)
                   " AND jour_creat_dat <= " (sqs endStr)
      ;;             " AND jour_wat = " (sqs JourWatCode) ";")]
		    " AND UPPER(jour_plantekst) LIKE '%#SMS%' ;")]
      (debug "(extract-raw-journal) JOUR-qry: " qry)
      (if gl/Debug
        (do
         (print qry)
         (list (hash-map :jour_ptnt_nr  1
                  :jour_mod_by  vDate/Now
                  :jour_creat_dat vDate/Now
                  :jour_plantekst "test #nuchter"))) 
        (sql/with-query-results res [qry]
          (doall res))))))



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  Internal functions (standardization)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn gen-standardize
  [StdKeys StdMapping]
  (fn [data]
    (map #(-> %
              (select-keys StdKeys)
              (set/rename-keys StdMapping)) data)))

(def standardize-calendar (gen-standardize CalendarKeys CalendarMapping))
(def standardize-notif (gen-standardize NotifKeys NotifMapping))
(def standardize-journal (gen-standardize JourKeys JourMapping))

;; TODO: bij de calendar en notifications moeten duplicate
;; records gemerged worden (dubbele afspraken bij zelfde persoon)
;; (merge: agna_extra_tekst samenvoegen in eerste afspraak en volgende
;;  afspraken verwijderen)



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  Public interface to extraction functions
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn extract-journal
  "Extract items from the journal that correspond to WAT=Q"
  [locSpecs interval]
  (->> (extract-raw-journal locSpecs interval)
      (standardize-journal )
      ;; assume the creator is the zorgverlener 
      ;; (not the person that modified)
      (map #(assoc % :xt_event_zvl (:xt_create_by %)) )
      ))

(defn extract-calendar+notifications
  "Extract scheduled calender meetings for a reminder."
  [locSpecs interval]
  (-> (extract-raw-calendar locSpecs interval)
      (standardize-calendar )))


;(defn extract-notif
;  "Extract items for notification"
;  [locSpecs interval]
;  (-> (extract-raw-notif locSpecs interval)
;      (standardize-notif )))

(defn extract-patient-data
  [locSpecs]
  (sql/with-connection (build-db-descr locSpecs)
    (let [qry (str "SELECT  ptnt_nr, ptnt_ruiter, ptnt_telefoon2, "
                   " ptnt_huisartsnu, ptnt_geboren, " 
                  ;; " ptnt_keuzenaam, "
                   " ptnt_roepnaam, " 
                   " ptnt_fullname, "
                   " ptnt_voorletters, ptnt_voorveigen, "
                 ;;  " ptnt_eigennaam, " 
                   " ptnt_voorv2denaam, ptnt_tweedenaam, "
                   " ptnt_vertrekdatum " 
                   " FROM ptnt"
                  " WHERE ptnt_vertrekdatum IS NULL "
                  "   OR ptnt_vertrekdatum > DATE_SUB(NOW(), INTERVAL 31 DAY)"
                 )]
      (sql/with-query-results res [qry] (doall res)))))

