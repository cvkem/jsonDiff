(ns vinzi.sms.sms2
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias Seqable Option 
                                    AnyInteger 
                                    fn> print-env Seq tc-ignore]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [clojure.java [jdbc :as sql]]
            [vinzi.sms 
              [SmsCharMap :as scm]
;;              [sms1       :as sms1]
              [timeExclusion :as te]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vString :as vStr]
             [vSql :as vSql]])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))

;(when-not (find-ns 'clojure.core.typed)
;  ;; if core typed does not exist nilify the annotations.
;  (defmacro ann [_ _] ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; This modules defines all functions to set up and format the
;;   sms messages that will be inserted in the sms-table
;;  (part 2 of 2)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



(ann NO-MERGE Boolean)
(def NO-MERGE false)

(when NO-MERGE
   (println "################  NO-MERGING of records!!! ################"))

(ann secondaryZvl IPersistentSet)
(def secondaryZvl #{"Assistenten"})


(ann mmc-get-key [DbMsg -> (Seqable String)])

(defn- mmc-get-key
  "Annotated helper of merge-multi-calNotif."
  [rec]
  (let [res (map rec [:xt_ptnt_nr :xt_event_date])]
    (print-env "mmc-get-key")
    res))

(ann mmc-get-time-range [DbMsgSeq -> String])
(defn- mmc-get-time-range [evts]
  (print-env "start mmc-get-time-range")
  (let [res (:xt_event_time (first evts))]
    (print-env "mmc-get-time-range")
    res))

(ann mmc-get-multi-rec [DbMsgSeq DbMsg -> DbMsg])

(defn- mmc-get-multi-rec 
  [recs mrec]
  (print-env "start mmc-get-multi-rec")
  (let [res (if (> (count recs) 1)
              (let [evt2 (second recs)
                    zvl2 (:xt_event_zvl (first evt2))
                    time2 (mmc-get-time-range evt2)]
                (if (and (= time2 (:xt_event_time mrec))
                         (or (secondaryZvl (:xt_event_zvl mrec))
                             (secondaryZvl zvl2)))
                  ;; Special case that both appoints start at the 
                  ;; same time, and one is marked as secondary
                  ;; (might be reservation of a room or an
                  ;;  additional pair of hands)
                  (if (secondaryZvl zvl2)
                    mrec
                    (assoc mrec :xt_event_zvl zvl2))
                  ;; not same time, so do not check for secondary
                  (assoc mrec
                         :xt_event_zvl_2 zvl2
                         :xt_event_time_2 time2)))
              ;; else: it is onlty a single record
              mrec)]
    (print-env "mmc-get-multi-rec")
    res))


(ann  mmc-get-merge-zvl-sort-time [DbMsgSeq -> (Seqable DbMsgSeq)])
(defn- mmc-get-merge-zvl-sort-time 
  [recs]
  (print-env "starting mmc-get-merge-zvl-sort-time")
  (let [res (->> recs
                 ;;(     (partition-by :xt_event_zvl ))
                 ;; using group-by+sort-by instead of partition-by
                 ;; to filter out when someone comes back to the
                 ;; first zvl
                 (group-by :xt_event_zvl )
                 (vals )
                 (map (partial sort-by :xt_event_time) ) ;; sorteer per zorgverlener
                 (sort-by #(:xt_event_time (first %)) )
                 (DbMsg_TcC ))] ;; sorteer alle records
                           ;; extend this to a time-range (when multiple events)
                           ;; NOTE: currently only takes start-time !!
    (print-env "mmc-get-merge-zvl-sort-time ready")
    res))

(ann mmc-get-st_notif [DbMsgSeq -> (Seqable String)])
(defn- mmc-get-st_notif
  [recs] 
  (print "start mmc-get-st_notif")
  (let [st_notif (->> recs
		      (map :st_notif)
		      (set )
		      (disj nil)
		      (seq )
	              (sort ) 
                      (seq ))]
   (print-env "mmc-get-st_notif")
   st_notif))
;;
;;(ann merge-multi-calNotif [(Seqable (HMap )) (Seqable (HMap ))])
(ann merge-multi-calNotif [DbMsgSeq -> DbMsgSeq])




(defn merge-multi-calNotif
  "Perform a merge operations over the processed Notification and Calendar messages
   to merge them into a single message per patient (per event-date).
   This operation is performed after processing the individual messages, so 
   it can concatenate/merge st_notif and st_msg."
  [msgs]  
  (print-env "start merge-multi-calNotif")
  (if NO-MERGE
    msgs
  (let [lpf "(merge-multi-calNotif): " 
;;        get-key #(map % [:xt_ptnt_nr :xt_event_date])
	merge-msgs (fn> [recs :- DbMsgSeq]
                     ;; receives a set of records belonging to a single
                     ;; patients appointments at a specific event-date.
                     ;; All these records should be merge to a single record.
                     (if (= (count recs) 1)
                        recs  ;; no merge needed
		     (let [recs (->> recs
                                   (sort-by :xt_event_time ))
                           numRecs (count recs)
                           ;; prepare a sorted sequence of a st_notif
			   st_notif #_(->> recs
					(map :st_notif)
					(set )
					(disj nil)
					(seq )
					(sort ) 
					(#(if (seq %) % nil))) ;; changed this line to seq only
                                    (mmc-get-st_notif recs)
                           _ (print-env "after st_notif")
                           st_type  (->> recs
                                        (map :st_type )
                                        (set )
                                        (#(if (% ST_CAL) ST_CAL ST_NOTIF) ))
                           xt_msg (->> recs
                                        (map :xt_msg )
                                        (str/join "| " ))
                           recs (mmc-get-merge-zvl-sort-time recs)
			   numZvl (count recs)
                           ;; now merge all fields
			   mrec (assoc (ffirst recs) 
                                      :st_type  st_type
                                      :st_notif st_notif
                                      :xt_msg xt_msg
                                      :xt_event_time (mmc-get-time-range (first recs)))
                           _ (print-env "initial mrec")
                           mrec (mmc-get-multi-rec recs mrec)
                           _ (print-env "extended mrec")
_ (when (> numRecs 1) (println "TMP-MERGE: merging " numRecs " records corresponding to " numZvl
        " zorgverleners. result: " mrec))
		           _ (debug "MERGING  numRecs with " numZvl 
                                "zorgverleners. Input:\n" recs 
                                "\n--> " mrec)
			   rrecs (drop 2 recs)
			]
			(when (seq rrecs)
			  (error lpf " more than two zorgverleners on same day" recs))

			(cons mrec rrecs))  ;; additional recs will be appended to prevent loss of data.
		   ))
        msgs (->>  msgs
                (group-by mmc-get-key )
		(vals )
                (map merge-msgs )
                (apply concat ))
        ]
  msgs)))



