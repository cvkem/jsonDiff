(ns vinzi.sms.intervals
  (:use [vinzi.sms.globals]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias ann-many Seqable Option 
                                    AnyInteger 
                                    fn> doseq>
                                    print-env Seq tc-ignore]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  managing intervals
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;




;(defn OLD_add-date-strings 
;  [interval]
;  (assoc interval
;	:startStr (vDate/generate-sql-date-str (:startTS interval))
;        :endStr (vDate/generate-sql-date-str (:endTS interval))
;        :startDayStr  (vDate/generate-sql-date-str (:startDayTS interval))
;        :endDayStr (vDate/generate-sql-date-str (:endDayTS interval)) ))
  


(ann get-interval [Number Number -> Interval])
(defn get-interval
  "Get an interval of the recent past and a threshold relative to the current
   time."
  [startMn endMn]
  (let [current (java.util.Date.)
        get-timestamp (fn> [offs :- Number]
                           (-> current ;;vDate/Now
                              (vDate/get-TS-minuteOffset offs)))
        startTS (get-timestamp startMn)
        endTS   (get-timestamp endMn)
        base {:startTS startTS
              :endTS endTS
              :startDayTS (vDate/get-TS-startDay startTS)
              :endDayTS   (vDate/get-TS-endDay endTS)}]
    base))
;;    (add-date-strings base)))


(ann ^:no-check get-union-interval [Interval Interval -> Interval])
(defn get-union-interval 
  "Get the interval that contains both i1 and i2 (and add the date-strings)."
  [i1 i2]
  (let [earliest (fn [a b] (if (< (.getTime a) (.getTime b)) a b))
        latest   (fn [a b] (if (> (.getTime a) (.getTime b)) a b))]
;;  (add-date-strings 
  {:startTS (earliest (:startTS i1) (:startTS i2))
   :endTS   (latest   (:endTS i1) (:endTS i2)) }))
;;)




(ann-many Interval JourInterval CalendarInterval)

;; journal item should be no older than 5 days, but more than 30 minutes
(def JourInterval (get-interval
                   (* -1 DMlifetimeDays DaysToMinutes)
                   -30))

(debug "vinzi.sms.intervals: JourInterval: " JourInterval)

;; appointments is 1 or 2 days ahead
(def CalendarInterval (get-interval
                       ;;(* 1 DaysToMinutes) 
                       (* 2 HoursToMinutes)
		       (case (vDate/get-day-of-week (java.util.Date. )) 
                         5 (* 4 DaysToMinutes)   ;; thursday
                         6 (* 3 DaysToMinutes)   ;; thursday
                         (* 2 DaysToMinutes))))

(debug "vinzi.sms.intervals: CalendarInterval: " CalendarInterval)






