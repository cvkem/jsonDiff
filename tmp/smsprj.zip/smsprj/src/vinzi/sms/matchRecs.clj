(ns vinzi.sms.matchRecs
  (:use [vinzi.sms.globals]
        [clojure.core [typed :only [check-ns cf ann ann-form def-alias
                                    EmptySeqable Option 
                                    fn> print-env Seq tc-ignore]]]
        [clojure.tools.logging]
        [clojure.pprint])
  (:require [clojure
             [string :as str]
             [set :as set]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]]
            [vinzi.sms [database :as db]])
 (:import [clojure.lang IPersistentSet IPersistentMap 
           PersistentList IPersistentVector ISeq Seqable
           Keyword Symbol])) 
;;
;; temporary patch to fix standalone compiler-error
;(def HVec identity)

;; for testing core.typed only
(ann A Long)
(def A 1)

(ann C (U nil  (Seqable Any)))
(def C ())

(ann append-issue [SmsMsg String -> SmsMsg])
(defn append-issue [rec issue]
  (assoc rec :st_issues (str (when (seq (:st_issues rec)) "|") issue)
         :st_state STATE_FAILURE))



(ann get-message-key [  SmsMsg
                     ;; (HMap :mandatory {:xt_key_date String :xt_ptnt_nr String} )
                       -> (Seq String) ])
(defn ^:no-check get-message-key 
  "Get the key of a message."
  [rec] 
  ;; map rec is not checkable
  (map rec [:xt_key_date :xt_ptnt_nr]))




;(ann couple-records-to-lhs-aux 
;     [   (HVec [SmsMsg SmsMsgSeq])
;      -> (HVec [SmsMsg (Option SmsMsg)])] )
(defn couple-records-to-lhs-aux 
  "auxiliary routine that finds last match based on st_create_date."
  [[k v]] 
  (let [lpf "(couple-records-to-lhs-aux): "]
    (case (count v) 
      0 (vector k nil)        ;; no match
      1 (vector k (first v))  ;; a unique match
      ;; multiple matches
      (let [v (->> v
                   (sort-by :st_create_date )
                  ;; (DbMsg_TcB )
                   )]
        ;; TODO: should only happen with STATE_FAILURE records
        (tc-ignore
        (debug lpf (count v) " new record: " k 
           "\nmaps to multiple records in "
           "current table:\n" 
           (with-out-str (doseq [[nr val] 
                                 (map #(vector %1 %2) (next (range)) v)] 
                           (prn "\t" nr " " val))) 
             "\tKeeping most recent only !!!"))
        ;; when added as last does not seem to accept nil
        (vector k (last v))))))


;;(ann couple-records-to-lhs [(Seqable DbMsg) (Seqable DbMsg)
(ann ^:no-check couple-records-to-lhs [   SmsMsgSeq SmsMsgSeq
                                       ->
                                          (IPersistentMap SmsMsg (Option SmsMsg ))])
;; TODO remove the no-check!!
(defn  couple-records-to-lhs
  "Returns a hashmap with the left-hand side records as keys and the right hand side as coupled values 
  (assumes at most one match per lhs record)."
  [lhs rhs]
  (let [lpf "(couple-records-to-lhs): "
	;; make a lookup-map of the rhs (right hand side) records based on the fields as defined in get-message-key
        rhs (->> rhs
                  (group-by get-message-key ))
        ;; TODO: A cleaner solution would be possible using 
        ;;    vRelation/outer-join
        ;; couple rhs records to currently lhs (left hand side records)
        hmRes (->> lhs
                  (map (fn> [sr :- SmsMsg] 
                            (vector sr (rhs (get-message-key sr)))) )
;                   (DbMsg_TcA )
;                   ((ann-form #(do
;                                 (print-env " before typecast")
;                                 (identity %))
;                      [   (IPersistentMap DbMsg (Seqable DbMsg))
;                       -> (Seqable (HVec DbMsg (Seqable DbMsg)))]) )
;;                  ((fn> [x :- (Seqable (HVec DbMsg (Seqable DbMsg)))]
;;                       (print-env "after matching lhs and rhs")
;;                       x) )
                  ;; and check whether mapping is unique
                  (map couple-records-to-lhs-aux )
                  (into {} ))]
    (debug lpf " Received " (count lhs) " left hand records  and " (count rhs) " right hand recs. " 
       " The result has " (count hmRes) " map-entries " (when-not (= (count hmRes) (count lhs)) "ERROR??" )) 
  hmRes))


;(ann ^:no-check detect-deletes 
;     [   SmsMsgSeq 
;         SmsMsgSeq
;         Interval
;         Interval
;      ->
;         (HVec [(Option SmsMsg ) (Option SmsMsg)])])
(defn detect-deletes 
  "The records that do not exist anymore are detected.
   Deletes might be updates that result in a change of the xt_key_date !
   A tuple containing matched and non-matched is returned."
  [curr recs JourInterval CalendarInterval]
  (let [in-recs (fn [{:keys [st_type xt_key_date]}]
	          ;; check whether message is within its interval.
                  (let [interval (if (= st_type ST_MSG)
                                   JourInterval
                                   CalendarInterval)
                        key_date_ms (.getTime xt_key_date)]
                    (and (>= key_date_ms (.getTime (:startTS interval)))
                         (<= key_date_ms (.getTime (:endTS interval))))))
        ;; get current messages within range of current extract and split 
        ;; the (current) message in a list with and a list without counterpart
        ;; in the current extract
        curr  (filter in-recs curr)
        coupled (couple-records-to-lhs curr recs)
        matched (->> (filter second coupled)
                     (map first))
        not-matched (->> (remove second coupled)
                         (map first))]
;                          ;; submitted can not be updated or deleted.
;                         (remove #(= (:st_state %) STATE_SUBMITTED) ))] 
;   (db/update-state-messages not-matched STATE_DEL_UPDATE)
   [matched not-matched])) ;; only matched records are returned (for further processing)

;(ann ^:no-check get-msg-appends-and-updates
;     [   SmsMsgSeq 
;         SmsMsgSeq
;      ->
;         (HVec [(Option SmsMsg ) (Option SmsMsg)])])
(defn get-msg-appends-and-updates
  "Match the new messages to the current messages and derive the list
   of new messages and updates."
  [curr extrMsg]
  ;; NOTE: Use append-issue instead of add-issue (state is set already)
  (let [lpf "(get-msg-appends-and-updates): "
       recs (couple-records-to-lhs extrMsg curr)
       ;; split the hashmap recs in two sequences of map-entries
        newRecs (remove second recs)
        existRecs (filter second recs)
        ;;  appends are records that do not exist yet
 ;;       appends (keys newRecs)   ;;; (keys newRecs)   == (map first newRecs) in this case
        appends (map first newRecs)
        _ (debug lpf " On " (count curr) "  current and " (count extrMsg) " records from HIS we obtained:\n\t"
            (count appends) " records to be appended and \n\t" 
            (count existRecs) " that have a matching key (existing or updates)")
        ;; fields used to detect changes that require an update
        get-compare-flds  #(map % [:sms_msg :sms_mobiel :sms_status
                  :st_type :st_issues :st_submit_deadline])
        fix-record (fn [[nwe prev]]
                       (if (ModifiableState (:st_state prev))
                         (assoc nwe
                           :id (:id prev)
                           :st_modif_date (java.util.Date.)
                           :st_num_modif (inc (:st_num_modif prev)))
                         (do
                           (error lpf "new record " nwe
                                  "\n\t can not overwrite record: " prev
                                  "\n\t create " STATE_FAILURE " record")
                           (append-issue nwe (str " Origineel bericht met id "
                                         (:id prev) " reeds verzonden op "
                                         (:st_submit_date prev))))))
        matching?  (fn [[nwe prev]]
                     (if (= (get-compare-flds nwe)
                            (get-compare-flds prev))
                       :matched 
                       :noMatch))
        ;; split existing records in matching and non-matching records (and find updates)
        {:keys [matched noMatch]} (group-by matching? existRecs)
        _  (debug lpf " There are " (count existRecs) " records that exist already:\n" 
                      "   Of these records " (count matched) " are identical \n" 
                      "   and  " (count noMatch) "  require an update.")
        _ (debug lpf " First two exact matches are: " 
                    (with-out-str (do (println " first-nwe")  (pprint (ffirst matched))
                                      (println " first-prev:") (pprint (second (first matched)))
                                      (println " second-nwe")  (pprint (first (second matched)))
                                      (println " second-prev:") (pprint (second (second  matched)))
                                      (println " last-nwe")  (pprint (first (last matched)))
                                      (println " last-prev:") (pprint (second (last  matched)))
                                      (println))))
       updates (map fix-record noMatch)
        ;; the failures should not be handled as updates (update not possible)
        ;; move to the append-list
        fail?     #(#{STATE_FAILURE STATE_TIMEOUT} (:st_state %) )
        failures  (filter fail? updates)
        updates   (remove fail? updates)
        numNewAppends (count appends)
        numUpdAppends (count failures)
        appends (concat appends failures)
        totAppends  (count appends)
        msg (str "process returns:\n\t" (count updates) " updates\n\t"
                 numUpdAppends " failed changes/updates (become appends with error)\n\t"
                 numNewAppends  " records to be appended\n\t"
                 (count matched) " record existed and not changed.")
        note (str "Collectie levert: " totAppends " toe te voegen"
                  " berichten (" numNewAppends " nieuwe " 
                  " en " numUpdAppends " gefaalde updates) "
                  " en " (count updates) " wijzigingen en ")
        stAppends (state-count appends)
        ]
    ;; put this note before the next note as the notes are viewed
    ;; in from most recent to older.
    (when (seq stAppends)
      (println "Add notes for stAppends: " stAppends)
      (db/add-note (str "  de toevoegingen bevatten: " 
          (str/join ", " (map #(str (second %) " " (first %)) stAppends)))))
    (db/add-note note)
    (debug lpf msg)
    (println lpf msg)
    (println "TMP: the " (count appends) " new records appended are:" )
    (doseq [newRec appends]
      (println lpf " APPEND: " (pr-str newRec)))
  [appends updates]
  ))


(tc-ignore
;;;;;;;;;;;;;;;;;;;;;;;;
;;  A few tools for pretty-printing and debugging purposes
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn print-map-diff [x y]
                        (doseq [k (keys x)]
			;;  (print " check key: " k " with lval " (get x k))
			  (let [kx (get x k)
                                ky (get y k)]
                            (when-not (= kx ky)
                                (println "key " k " from " kx
                                       " to "  ky)))))

(defn show-updates [org upd] 
   (doseq [a upd]
     (println "\nUpdate: " a)
     (println "had matches in orig:")
     (doseq [[i o] (map #(vector %2 %1) (filter #(= (:xt_ptnt_nr a) (:xt_ptnt_nr %)) org) (next (range)))]
       (println "match: " i)
       (print-map-diff o a))))

(defn check-same-pat
 " DEPRECATED?? " 
  [msgs]
  (let [get-key #(map % [:xt_ptnt_nr :xt_event_date])
        msgs (group-by get-key msgs)
	;;_ (println " msgs has " (count msgs) " elements. First: \n" (first msgs))
        ;;_ (println " first vals msgs: " (first (vals msgs)) " with type " (type (first (vals msgs))))
        msgsSort #(do (println " sorting: " % "  of type: " (type %))
			(sort-by :xt_event_tijd %))
	;;_ (doseq [r (vals msgs)] (println (type r)))
        msgs (zipmap (keys msgs) (map msgsSort (vals msgs)))
	dbls (into {}  (filter #(> (count (second %)) 1) msgs))
        ]
  (println " showing all multi-appointments" (count dbls) " observed.")
  (doseq [[i d] (map #(vector %1 %2) (next (range)) dbls)]
    (print "\nmulti-appointment " i " for key: "  (first d))
      (doseq [a (second d)]
        (println (select-keys a [:xt_event_tijd :sms_msg :st_notif :st_type]))))
  (println "multi-app ready\n\n")))


) ;; end tc-ignore
