(ns vinzi.sms.sms1
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
        [clojure.core [typed :only [check-ns cf ann ann-many ann-form 
                                    def-alias Seqable Option 
                                    AnyInteger 
                                    fn> print-env Seq tc-ignore]]]
        clojure.tools.logging
        clojure.pprint)
  (:require [clojure
             [string :as str]
             [set :as set]]
            [clojure.java [jdbc :as sql]]
            [vinzi.sms 
              [SmsCharMap :as scm]
              [timeExclusion :as te]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vString :as vStr]
             [vSql :as vSql]])
  (:import [clojure.lang IPersistentList IPersistentVector IPersistentSet IPersistentMap Keyword Symbol]))

;(when-not (find-ns 'clojure.core.typed)
;  ;; if core typed does not exist nilify the annotations.
;  (defmacro ann [_ _] ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; This modules defines all functions to set up and format the
;;   sms messages that will be inserted in the sms-table
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



(ann calendarSmsFormat String)

;; TODO: read from configuration file
(def calendarSmsFormat "Op %d% om %t% heeft u een afspraak met %z%.")



(ann ^:no-check get-day-offset [(U java.sql.Timestamp java.sql.Date java.util.Date) -> Double])

(defn get-hour-offset
  "Get the offset in terms of hours."
  [dt1 dt2]
  (when (and dt1 dt2)
    (let [diff (- (.getTime dt2) (.getTime dt1))]
      (double (/ diff vDate/Interval1hourMillis)))))

(ann TagMap (IPersistentMap Keyword String))

(def TagMap)

(ann-many (IPersistentSet Keyword)
  TagExists TagIsNotification TagIsCalendar)
;(ann TagExists (IPersistentSet Keyword))
;(ann TagIsNotification (IPersistentSet Keyword))
;(ann TagIsCalendar (IPersistentSet Keyword))

;;  a series of datastructure to process tags
(def TagExists)
(def TagIsNotification)
(def TagIsCalendar)

(def SmsName)

(ann ^:no-check set-tag-mapping [(Seqable (HMap )) -> nil])

(defn set-tag-mapping
  "Set the tag-mappings based on a tags sequence.
   (Also used during unit-testing with a default tag-set)"
  [tags]
  {:pre [(sequential? tags)]}
     (let [filtered-set (fn [tg] (->> tags
                                      (filter #(= (:type %) tg) )
                                      (map :tag )
                                      (set )))]
	;; map to a full record
	       (def TagMap (into {} (map #(vector (:tag %) %) tags)))
		;; map to type
	       (def TagType (zipmap (keys TagMap) (map :type (vals TagMap))))
	       (def TagExists (conj (set (map :tag tags)) IgnoreTag))
	       (def TagIsNotification (filtered-set ST_NOTIF))
	       (def TagIsCalendar (filtered-set ST_CAL))
	       (def TagIsCalNotif nil)
	       nil))

;; strip space and tranform to lower-case to prevent 
;; the difficult to find typing errors like trailing spaces of lower-case characters.
(def key-calendar-name (comp str/lower-case str/trim str))

(defn set-calendar-name-mapping  
  [nmeMap]
  {:pre [(or (sequential? nmeMap) (nil? nmeMap))]}
  (def SmsName (into {} (map #(vector (key-calendar-name (:calendar_header %))
                                      (:sms_name %)) nmeMap))))

(ann ^:no-check add-calNotif-type [(HMap ) -> (HMap )])

(defn add-calNotif-type 
  "Determine type of record based on tags. If no tag is found default to ST_CAL." 
  [rec]
  (let [tps (->> rec
                 (:st_notif )
                 (#(if (sequential? %)  ;; currently we only accept one tag
		   (map TagType %)
                   (TagType %)) )
                 (set ))
        tpe (if (or (contains? tps nil) (= tps #{}) (tps ST_CAL))
              ST_CAL
              ST_NOTIF)]
    (println "TMP-add-calNot-tpe: record with st_notif: " (:st_notif rec)
       " has types: " tps " and maps to tpe: " tpe)
    (assoc rec :st_type tpe)))
   

;;(ann cal (U java.util.Calendar java.util.Locale nil))
(ann ^:no-check cal java.util.Calendar)

(def cal (java.util.Calendar/getInstance (java.util.Locale/getDefault)))


(ann Month (Seqable String))

(def Month ["Jan" "Febr" "Mrt" "Apr" "Mei" "Juni" "Juli" "Aug" "Sept" "Okt" "Nov" "Dec"])


(ann ^:no-check get-date-string [(U java.sql.Timestamp java.sql.Date java.util.Date) -> String])

(defn get-date-string 
  [dt]
  (if dt
    (do
      (.setTime cal dt)
      (let [dow (get vDate/dayOfWeek (.get cal java.util.Calendar/DAY_OF_WEEK))
            mon (get Month (.get cal java.util.Calendar/MONTH))
            day (.get cal java.util.Calendar/DAY_OF_MONTH)]
      (str dow " " day " " mon)))
    ""))

(ann ^:no-check expand-sms-params [(HMap ) -> (HMap )])

(defn get-zvl-name
  "Lookup the zorgverlener name based on the name of the calendar. If
   no mapping is given return the calendar name."
  [calNme]
  (str (if-let [zvlNme (get SmsName (key-calendar-name calNme))]
         zvlNme
         calNme)))  ;; no mapping available

(defn expand-sms-params
  [rec]
  (println "TMP1: received: " rec)
  (if-let [msg (:sms_msg rec)]
    (let [;;get-time (fn [t] (->> t (str ) (#(str/split % #":")) (take 2) (str/join ":")))
          pars {:z (get-zvl-name (:xt_event_zvl rec))
                :z2 (get-zvl-name (:xt_event_zvl_2 rec))
                :t  (te/get-time (:xt_event_time rec))
                :t2 (te/get-time (:xt_event_time_2 rec))
                :d  (get-date-string (:xt_event_date rec))
                }
          _     (println "TMP: msg=" msg)
          _     (println "TMP and pars=" pars)
          newMsg (vStr/replace-params msg pars ["%" "%"])]
          (println "TMP: newMsg: " newMsg)
      (assoc rec :sms_msg (:code newMsg)))
    rec))

(ann  cleanse-validate-sms [(HMap ) -> (HMap )])

(defn cleanse-validate-sms
  "Replace all characters that aren't allowed an generate
   and issue if the sms is invalid.
   Currently no validation required."
  [rec]
  ;; (str added to allow type-checking
  (assoc rec :sms_msg (scm/cleanse-string (str (:sms_msg rec)))))


(ann SmsMaxLen Integer)

(def SmsMaxLen 160)


(ann SplitStr (IPersistentSet String))

(def SplitStr #{" " "\t" "\n" "." "," ";"})


(ann  find-split-backward [String AnyInteger -> AnyInteger])

(defn find-split-backward 
  "Find the first position at position <= pos where the string can be split
   at one of the one-character strings in SplitStr.
   Returns the index of the split-position." 
  [msg pos]
  (when (< pos 1)
    (vExcept/throw-except "(find-spit-backward): message can not be split: " msg))
  (if (SplitStr (subs msg (dec pos) pos))
     pos
     (recur msg (dec pos))))

(ann SepParts String)

(def SepParts "...")

;;(ann  split-long-sms (Fn [(PersistentHashMap Keyword Any) -> (Seqable (PersistenHashMap Keyword Any))]
 ;;                     [(PersistentHashMap Keyword Any ) Integer -> (Seqable (PersistentHashMap Keyword Any))]))
(ann ^:no-check split-long-sms (Fn [(HMap :mandatory {:sms_msg String}) -> (Seqable (HMap))]
                      [(HMap :mandatory {:sms_msg String}) Integer -> (Seqable (HMap))]))

(defn split-long-sms 
  "DEPRECATED:Split of long sms now in module vinzi.sms.submit
   If the sms-msg is longer than 160 characters, the message will be split.
   Returns a sequence of one of more messages."
  ([rec]  (split-long-sms rec SmsMaxLen))
  ([rec SmsMaxLen]
    (let [split-sms (fn [cumm rec]
                    (let [msg (:sms_msg rec)
                          inc-kd (fn [rec] 
                                    ;; increase key-date to ensure unique key-dates
                                    (if-let [kd (:st_key_date rec)]
                                       (assoc rec :st_key_date (-> kd
                                                                  (.getTime )
                                                                  (inc )
                                                                  (java.sql.Timestamp. )))
                                    rec))]
		      (if (<= (count msg) SmsMaxLen)
                        (conj cumm rec)
                        (let [pos (find-split-backward msg (- SmsMaxLen (count SepParts )))
			      part1 (assoc rec :sms_msg (str (subs msg 0 pos) SepParts))
			      part2 (assoc (inc-kd rec) :sms_msg (str SepParts (subs msg pos)))]
                          (recur (conj cumm part1) part2)))))]
    (split-sms [] rec))))
        
 
;; inner function lifted to global scope for type-checking
(ann  add-tag [(HMap :mandatory {:st_notif (U String nil)}) String -> (HMap :mandatory {:st_notif (U String nil)})])


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  tag processing

(def add-tag (fn [rec tg]
                  ;; currently only one tag allowed
                  (print-env "add-tag")
                  (if (TagExists tg)
                    (if (= tg IgnoreTag)
                      (add-issue rec IGNORE_MSG)
                      (if-not (seq (:st_notif rec))
                        (assoc rec :st_notif tg)
                        (add-issue rec (str "meerdere tags: " tg " geweigerd"))))
                    (add-issue rec (str tg " bestaat niet")))))

(ann  extract-add-tags [(HMap :mandatory {:st_notif (U String nil)}) -> (HMap )])

(defn extract-add-tags
  "Extract all tags from the :xt_msg and add them to :st_notif."
  [rec]
  (let [tags (when-let [msg (:xt_msg rec)]
                ;; str added to allow type-check
               (re-seq #"#[\w]*" (str msg)))
;        add-tag (fn [rec tg]
;                  (if (TagExists tg)
;                    (if-not (seq (:st_notif rec))
;                      (assoc rec :st_notif tg)
;                      (add-issue rec (str "meerdere tags: " tg " geweigerd")))
;                    (add-issue rec (str tg " bestaat niet"))))
                ]
(println "TMP-tags: for record with msg|"(:xt_msg rec)"| found tags: " tags)
    (let [res (reduce add-tag rec tags)]
      (print-env "(extract-add-tags)")
      res)))


(ann  derive-sms_msg-fmt [(HMap ) -> (HMap )])

(defn derive-sms_msg-fmt
  "Derive the :sms_msg from the st_notif. :sms_msg should be empty."
  [rec]
  (let [res (if-not (seq (:sms_msg rec))
    (let [add-notif (fn [notif] (if-let [msg (-> notif (TagMap ) (:format))]
                                   (assoc rec :sms_msg (if-let [curr (:sms_msg rec)]
                                                         (str curr "|" msg)
                                                         msg))  
                                   (add-issue rec (str "Notificatie " notif " niet herkend"))))
          notifs (:st_notif rec)]
     (if (sequential? notifs)
       (doseq [n notifs] (add-notif n))
       (add-notif notifs)))
    (add-issue rec "Message is set, can not override"))]
    (print-env "derive-sms_msg-fmt")
    res))


(ann  derive-sms_msg-cal-fmt [(HMap ) -> (HMap )])

(defn derive-sms_msg-cal-fmt
  "Derive the sms-msg for a calendar items. If notifications are present these are
   used, otherwise a standard message is created."
  [rec]
  (let [res (if (:st_notif rec)
    (derive-sms_msg-fmt rec)
    (assoc rec :sms_msg calendarSmsFormat))]
    (print-env "derive-sms_msg-cal-fmt")
    res))


(ann  derive-sms_msg-calNotifs-fmt [(Seqable (HMap )) -> (Seqable (HMap ))])

(defn derive-sms_msg-calNotifs-fmt [recs]
  (let [res 
  (map #(if (= (:st_type %) ST_CAL) 
             (derive-sms_msg-cal-fmt %)
             (derive-sms_msg-fmt %))   recs)]
    (print-env "derive-sms_msg-calNotifs-fmt")
    res))




(ann process-list-func [(Fn [(HMap) -> (HMap)])
                        (Fn [(Seqable (HMap)) -> (Seqable (HMap))])
                        (Fn [(Seqable (HMap)) (HMap) -> (Seqable (HMap))])
                        -> (Fn [(Seqable (HMap)) -> (Seqable (HMap))]) ])

(defn process-list-func
  "Do the processing a list of messages with a specific set of functions."
  [lpf process-item process-list filter-items]
  (fn [data]
    (->> data
         (#(do (debug lpf "Received " (count %) " items.") %) )
         (map process-item )
         (#(do (debug lpf "After map process-item " (count %) " items.") %) )
	 (process-list )
         (#(do (debug lpf "After process-list " (count %) " items.") %) )
         (reduce filter-items [] )
         (#(do (debug lpf "After filter-items " (count %) " items.") %) )
     )))



(ann get-jour-message [(HMap) -> (HMap)])

(defn get-jour-message 
  "Extract the journal tekst from the plan-tekst by taking everything
   after #sms."
  [rec]
  (->> rec
       (:xt_msg )
       (str )
       (re-find #"(?iu)#sms[\s]*([\w\W]*)" )
       (second )))


(ann add-jour-deadline [(Seqable (HMap)) -> (HMap)])

(defn add-jour-deadline 
  "Messages should be submitted within DMlifetimeDays after being created."
  [recs]
  (let [add-deadline (fn [rec]
                       (let [dl (vDate/get-TS-dayOffset 
                                    (:xt_key_date rec) DMlifetimeDays)]
                       (assoc rec :st_submit_deadline dl)))]
    (map add-deadline recs)))


(ann process-jour [(Seqable (HMap)) -> (Seqable (HMap))])

(def process-jour (process-list-func
		   "(process-jour): " 
                   (fn [rec]  ;; process-item
                     (assoc rec
                       :st_type ST_MSG
                       :sms_msg (get-jour-message rec)))
		   add-jour-deadline
                   (fn [cumm rec]  ;; filter-items
                     ;; no specific filtering on journal items
                     (conj cumm rec))))


(ann ^:no-check getTime [java.sql.Timestamp -> Long])
(defn getTime 
  "Function used as I can not annotate .getTime (yet)."
  [dt] 
  (.getTime dt))


(ann add-calNotif-deadline [(Seqable (HMap)) -> (HMap)])

(defn add-calNotif-deadline 
  "Add a deadline relative to the event-date."
  [recs]
  (let [add-deadline (fn [rec]
                       (let [rec (if (sequential? rec)
                                   (let [msg (str "(add-calNotif-deadline): record is sequential with " (count rec) " items: " rec " (taking first item only)")]
					(println msg) (debug msg)
                                        (first rec)) 
                                   rec)
                             dl (if (= (:st_type rec) ST_NOTIF)
                                  LatestNotifHours
                                  LatestReminderHours)
                             ed (:xt_event_date rec) 
                             et (:xt_event_time rec) 
                            ;; replace as I can not annotate .getTime (yet)
                            ;; dt (when (and ed et)
                            ;;      (java.sql.Timestamp. 
                            ;;        (+ (.getTime ed)
                            ;;         (.getTime et))))
                             dt (when (and ed et)
                                  (java.sql.Timestamp. 
                                    (+ (getTime ed)
                                     (getTime et))))
                             dl (when dt (vDate/get-TS-hourOffset dt dl))]
                       (assoc rec :st_submit_deadline dl)))]
    (map add-deadline recs)))

(defn get-event-datetime 
  "Compute event timestamp   " 
  [rec]
  (-> (+ (.getTime (:xt_event_date rec)) (.getTime (:xt_event_time rec)))
    ;; correction as times also have a 1 hour correction relative to UTC
    (+ vDate/Interval1hourMillis)
    (java.sql.Timestamp. ) ))

;; actually no check
(ann ^:no-check process-calNotif (Fn [(Seqable (HMap)) -> (Seqable (HMap))]))

(def process-calNotif (process-list-func
                          ;; calNotif processing of a single item
                          "(process-calNotif): " 
                            (fn [rec]  ;; process-item
                              (-> rec
                                  ;;(assoc :st_type ST_CAL)
                                  (extract-add-tags )
                                  (add-calNotif-type )
                                  ;; generate a function that performs the check
                                  ((te/get-check-timeExclusions-func) )
                                 ;; (derive-sms_msg-cal) 
                             ))
                        ;; calNotif Processing of the complete list
		       (comp derive-sms_msg-calNotifs-fmt
                          add-calNotif-deadline
                          merge-multi-calNotif)  ;; merge AFSPR (?or CAL?) and NOTIF 
                       ;; calNotif  filter the list
                       (fn [cumm rec]  ;; filter-items
                         (let [lpf "(filter-calNotif): "
                               tpe (:st_type rec)
                               event_dt   (get-event-datetime rec)
                               event_hoffs (or (get-hour-offset vDate/Now event_dt)
                                              0.0)]
                           (debug lpf " TMP: :xt_event_date=" (:xt_event_date rec) " :xt_event_time=" (:xt_event_time rec)
                               " translates to: " event_dt  "  and has :xt_key_date="  (:xt_key_date rec)
                               "  and has an hours-offset relative to now " vDate/Now " of " event_hoffs)
                           (if (or (and (= tpe ST_CAL)  ;; 
                                         (>  event_hoffs AfsprHoursLatest))
                                    (and (= tpe ST_NOTIF)
                                         (> event_hoffs NotifHoursLatest)
                                           ;; er moeten notificaties zijn
                                           (seq (:st_notif rec)))) 
                             (conj cumm rec)
                             (let [showReject true
                                   showFullRec false] 
				(when showFullRec (debug "DUMP FILTER dropping: " rec))
				(when showReject
                                  (debug "TMP-REJECT: " 
                                      (select-keys rec [:xt_event_date :xt_event_time 
                                                        :xt_key_notif :st_type] ) 
                                      "\n\tCHECK HOUR-OFFS: " event_hoffs " > "
                                        (if (= tpe ST_CAL) AfsprHoursLatest NotifHoursLatest)
					(if (and (= tpe ST_NOTIF) 
                                                   (not (seq (:st_notif rec)))) 
                                           " AND no notifications" "")))
                                cumm))))))



;(def process-notifications (process-list-func
;                             "--decprecated--" 
;                            (fn [rec]  ;; process-item
;                              (-> rec
;                                  (assoc :st_type ST_NOTIF)
;                                  (extract-add-tags )
;                                  (derive-sms_msg )))
;                            (fn [cumm rec]  ;; filter-items
;                              (let [tag (:st_notif rec)]
;                                (if (TagIsNotification tag)
;                                  (conj cumm rec)
;                                  cumm)))))


(ann update-rec-state [(HMap) -> (HMap)])

(def AutoConfirm)

(defn update-rec-state
  "Update state of record based on auto-confirm and presence of issues. "
  [rec]
  (let [nweState (if (seq (:st_issues rec))
                   STATE_ISSUE   ;; always fail on issues
                   (if AutoConfirm
                     STATE_CONFIRM
                     STATE_READY))]
 ;;   (print "state updated to: " nweState " for record: " rec)
    (assoc rec :st_state nweState)))


(ann update-state-recs [(Seqable (HMap)) -> (Seqable (HMap))])

(defn update-state-recs
  [recs]
  {:pre [(sequential? recs)]}
  (map update-rec-state recs))

(defn split-sms-filter 
  "DEPRECATED:  splitting now happens just before submission.
     This filter splits long sms, and thus can increase the number of records."
  [cumm rec]  
  ;; filter-items
  (let [recs (split-long-sms rec)]
    (apply conj cumm recs)))

(defn identity-filter
  [cumm rec]
   (conj cumm rec))

(ann post-process-generic [(Seqable (HMap)) -> (Seqable (HMap))])

(def post-process-generic (process-list-func
                           "(post-process-generic): " 
                           (fn [rec]   ;; post-processing
                             (-> rec
                                 (expand-sms-params )
                                 (cleanse-validate-sms )
                              ;;   (update-state )
                                 ))
                           identity
			   identity-filter ;; split-sms-filter
))



(ann  add-ptntInfo [(Seqable (HMap)) (Seqable (HMap)) -> (Seqable (HMap))])

(defn add-ptntInfo
  "Add mobiel and SMS status to all records in data."
  [ptntInfo data]
  (let [lpf "(add-ptntInfo): "
        orgPtntInfo ptntInfo  ;; for debugging
        ptntInfo (into {} (map #(vector (:ptnt_nr %) %) ptntInfo))
        ;;  WEIRD: Here I shadow the name of the surrounding function (with a different arity  !!
        add-ptntInfo (fn [rec]
                       (if-let [pi (ptntInfo (:xt_ptnt_nr rec))]
			(if (:actief pi)
                          (-> (case (:sms_status pi)
                                      SMS_ON rec
                                      SMS_OFF (add-issue rec "SMS OFF")
                                      SMS_?   (add-issue rec "SMS status onbekend")
                                      (add-issue rec "Invalid SMS-state"))
                           (assoc 
                           :sms_mobiel (:sms_mobiel pi)
                           :sms_status (:sms_status pi)
                           :st_issues (vec (concat (:st_issues rec)
                                                        (:st_issues pi)))))
                         (add-issue rec PAT_UITGESCHR))
                         (do
                           (error lpf "No patient data for record: " rec)
                           (assoc rec :sms_mobiel nil
                                  :sms_status nil
                                  :st_issues (conj (vec (:st_issues rec))
                                                   NO_PATIENT_DATA)))))]
    (let [res (map add-ptntInfo data)
          frec (first res)
          fkey (:ptnt_nr frec)
          pi (ptntInfo fkey)
          ]
      (println lpf "Ready")
      (println lpf "first three result: " (take 3 res))
      (println lpf "first three ptntInfo: " (take 3 ptntInfo))
      (println lpf "ptntInfo of first three: "
           (into {} (map #(vector (:ptnt_nr %) %) (take 3 orgPtntInfo))))

      (println "first had key: " fkey " and info " pi)
      res)))


(defn check-seq-hm [shm]
  (let [lpf "(check-seq-hm): "]
     (when-let [incorrect (seq (remove map? shm))]
      (vExcept/throw-except lpf " Check failed on: " incorrect))
    shm))



(ann post-sms-messages [(Seqable (HMap)) (Seqable (HMap)) (Seqable (HMap)) -> (Seqable (HMap))])


(def TMPSTORE (atom {}))

(defn store-count-check
  " Store data, report size and check if it still is a sequence of hash-maps." 
   [lbl data]
   (swap! TMPSTORE assoc lbl data)
   (debug " (count-and-store): After stage " (name lbl) " counting "  (count data) " items")
   (check-seq-hm data)
   data)

(defn process-sms-messages 
  "Collecting all sms-messages and processing them. The journal and calNotif items are first processed separately
   and next the generic processing is applied to the combined list."
  [jour calNotif ptntInfo]
  (let [lpf "(process-sms-messages): " 
        ;; First do the separate processing
        _ (debug lpf " initial count of journal items: " (count jour))
        jour (process-jour jour)
        _ (store-count-check :processedJournalItems jour)
        _ (debug lpf " initial count of calNotif items: " (count calNotif))
        calNotif (process-calNotif calNotif)
        _ (store-count-check :processedCalNotif calNotif)
	;; Next do the generic postprocessing for jour and call-notif combined
        extrMsg (->> (concat calNotif jour)
                    (store-count-check :concatenated )
                    (post-process-generic )
                    (store-count-check :postProcessGeneric )
                    (add-ptntInfo ptntInfo )
                    (store-count-check :add-ptntInfo )
                    (update-state-recs )
                    (store-count-check :updateStateRecs )
                    (stringify-st_issues )
                    (store-count-check :stringifySt_issues )
                    )]
  extrMsg))


(ann init-sms-generator [ -> nil])

(defn init-sms-generator [{:keys [sms_AutoConfirm]}]
  ;; TODO:  to be implemented to grab settings from database
  (def AutoConfirm (= (str/upper-case (str/trim (str sms_AutoConfirm))) "JA")))


