(ns vinzi.sms.database
  (:use [vinzi.sms.globals]
        [vinzi.tools [vSql :only [sqs qs qsp]]]
         [clojure.tools 
         [logging :only [error info trace debug warn]]])
  (:require [clojure 
              [edn :as edn]
              [set :as set]
              [string :as str]]
            [clojure.java [jdbc :as sql]]
            [vinzi.tools
             [vDateTime :as vDate]
             [vExcept :as vExcept]
             [vSql :as vSql]]))

;;;;;;;;;;;;;;;;;;;;;;;;;; notes code ;;;;;;;;;;;;;;;;;;;;;;;;;;;
(def NoteFields [
                {:nme "id"  :tpe :serial :constraint "PRIMARY KEY"}
                {:nme "timestamp"  :tpe :timestamp :default "now()"}
                {:nme "note"  :tpe :text} ])

(def NoteTbl "system_notes")

(defn add-note 
  "Add a note to the system_notes table." 
  [note]
  (debug "(add-note): " note)
  (sql/insert-record (qsp Schema NoteTbl) {:note note}))

;;;;;;;;;;;;;;;;;;;;;;;;;; definitions ;;;;;;;;;;;;;;;;;;;;;;;;;;;

(def TagDefaults [
{:format "neemt u alstublieft uw ochtendurine mee naar de afspraak op %d% om %t%  met %z%", :tag "#urine", :type ST_NOTIF}
{:format "tip: oren uitspuiten gaat vaak makkelijker als u gedruppeld heeft", :tag "#oor", :type ST_NOTIF}
{:format "om een betrouwbare uitslag te krijgen is het van belang dat u niet gedronken en/of gegeten heeft voor uw afspraak op %d% om %t% met %z%", :tag "#nuchter", :type ST_NOTIF}
{:format "Op  %d% om %t% heeft u een afspraak met %z% ivm een reizigersadvies. Heeft u het reizigersformulier al ingevuld op onze website", :tag "#reisadvies", :type ST_NOTIF}
{:format "om uw longinhoud goed te kunnen beoordelen is het belangrijk dat u op de ochtend van de afpraak van %d% om %t% geen longmedicatie heeft gebruikt", :tag "#spiro", :type ST_NOTIF}
{:format "Op %d% om %t% Heeft u een afspraak met %z% in het kader van het bevolkingsonderzoek. Denkt u eraan het formulier mee te nemen", :tag "#bvo", :type ST_NOTIF}
{:format "Hierbij ontvangt u een herinnering voor de afspraak op %d% om %t% met %z%.", :tag "#spv", :type ST_CAL}
{:format "Hierbij ontvangt u een herinnering voor uw afspraak op het chirurgisch spreekuur op %d% om %t% met %z%.", :tag "#chi", :type ST_CAL}
{:format "Op %d% om %t% heeft u een afspraak met %z% ivm het plaatsen van een spiraaltje. Tip: het plaatsen is minder pijnlijk  als u 1 tot 2 uur voor de afspraak pijnstilling inneemt.", :tag "#iud", :type ST_NOTIF}
{:format "Hierbij ontvangt u een herinnering voor uw afspraak op het CVRM spreekuur van %z% op %d% om %t%.", :tag "#CVRM", :type ST_CAL}
{:format "Hierbij ontvangt u een herinnering voor de jaarcontrole op het COPD spreekuur van %z% op %d% om %t%.", :tag "#JCOPD", :type ST_CAL}
{:format "Hierbij ontvangt u een herinnering voor uw afspraak op het diabetesspreekuur van %z% op %d% om %t%.", :tag "#KDM", :type ST_CAL}
{:format "Op %d% om %t% heeft u een afspraak met %z% en vervolgens om %t2% met %z2% in verband met de jaarcontrole diabetes", :tag "#JDM", :type ST_CAL}
                  ])
                  


(defn read-all-tag-defs
  "Read all tag-definitions and return it as an listed ordered by tag."
  []
  (let [qry (str "SELECT * FROM " (qsp Schema TagTbl) " ORDER BY tag;")]
    (sql/with-query-results res [qry]
      (doall res))))


(defn read-calendar-name-mapping
  "Read the name-mapping for the calendar."
  []
  (let [qry (str "SELECT * FROM " (qsp Schema NameMapTbl) ";")]
    (sql/with-query-results res [qry]
      (doall res))))


(defn get-current-messages [{:keys [startTS endTS]}]
  (let [lpf "(get-current-messages): " 
        startStr (vDate/generate-sql-date-str startTS)
        endStr (vDate/generate-sql-date-str endTS)
        qry (str "SELECT * FROM " (qsp Schema MsgTbl)
              " WHERE  xt_key_date >= " (sqs startStr)
              "   AND  xt_key_date <= " (sqs endStr)
              "   AND  NOT(st_state = " (sqs STATE_DEL_UPDATE) ");")]
    (debug lpf " retrieving records with query: " qry 
         "\n\tNOTE: postgreSQL does not do UTC-conversions, contrary to Mysql!")
    (sql/with-query-results res [qry] (doall res))))



;(def SettingsFields [{:nme "setting"   :tpe :text :constraint "PRIMARY KEY"}
;                {:nme "edn_value"  :tpe :text}])
;
;;; SettingsDefaults is defined in globals as a hashmap
;;; Translate it to database format.
;;; TODO: assumes that values are already formatted as edn
;(doseq [[_ v] SettingsDefaults]
;  (when-not (string? v)
;    (vExcept/throw-except "vinzi.sms.database format-error "
;                          v " is not a string-value (edn-format).")))
;(def SettingsDefs (map #(hash-map :setting (name (first %))
;                                :edn_value (second %)) SettingsDefaults))

(def SettingsFields [{:nme "setting"   :tpe :text :constraint "PRIMARY KEY"}
                     {:nme "value"  :tpe :text}
                     {:nme "description" :tpe :text}
                     {:nme "input_descr" :tpe :text}
                     {:nme "access"      :tpe :text}])

(def SettingsTbl "settings")


(defn read-settings-from-db
  "Retrieve settings from the database and return them as a hashmap."
  []
  (sql/with-query-results settings [(str "SELECT * FROM "
                                         (qsp Schema SettingsTbl))]
;;    (create-settings (zipmap (map (comp keyword :setting) settings)
;;                             (map (comp edn/read-string :edn_value) settings))) ;; code when using edn-encoding
    (zipmap (map (comp keyword :setting) settings)
                             (map :value settings))))

(defn update-setting 
  "Used by cdp (external) interface. Entry point for more comprehensive checking in clojure.
   Returns a string value OK when everything is successful, otherwise an error-report is returned."
  [{:keys [setting value] :as pars}]
    (if (and setting value)
      (let [qry (str "UPDATE " (qsp Schema SettingsTbl) " SET value=" (sqs value)" WHERE setting="(sqs setting)";") 
            ret (sql/do-commands qry)]
        (if (= (first ret) 1)
          "OK"
          (if (= (first ret) 0)
             (str "UPDATE FAILED: probably setting " (sqs setting) " does not exist")
             (str "UPDATE FAILED: received database return value:" ret))))
      (str "Nil parameter received setting=" setting "  and value=" value)))

;;;;;;;;;;;;;;;;;;;;;;;;;;; manage time-Exclusions

;;   do not use this cache, as it might trash things when working with multiple locations
(def teCache (atom nil))
(defn invalidate-teCache [] (swap! teCache (fn [_] nil)))

(defn get-time-exclusions
   "Get time exclusions via the teCache if possible." 
   []
   (if-let [te @teCache]
     te
     (let [qry (str "SELECT * FROM " (qsp Schema TimeExcludeTbl))]
       (sql/with-query-results te [qry]
         ;; cache turned off
        ;; (swap! teCache (fn [_] (doall te)))
        (doall te)
         ))))


(defn get-time-exclusion-rec 
  "Find an exiting time-exclusion record for :zorgverlener and :dag."
  [timeExcl]
  (let [{:keys [zorgverlener dag]} timeExcl
        match-te #(and (= (:zorgverlener %) zorgverlener)
                      (= (:dag %) dag))]
    (first (filter match-te (get-time-exclusions)))))


(defn add-update-time-exclusion-raw
   "NOTE: consider using (timeExclusion/add-update-exclusion)
    Add time-exclusions to database by updating existing records
    or adding a new one. (Cache will be invalidated as this operation
    does not happen too often.).
    Assumes data is valid, so (te/cleanse-time-exclusion ...) is applied already." 
  [timeExcl]
  ;; When calling this function a grouping by :zorgverlener and :dag has been performed,
  ;; so the number of updates is limited (no caching needed).
  (let [lpf "(add-update-time-exclusion-raw): " 
        qTbl (qsp Schema TimeExcludeTbl)]
    (if-let [te (get-time-exclusion-rec timeExcl)]
      (let [{:keys [zorgverlener dag exclusie]} timeExcl
            qry (str "UPDATE " qTbl " SET exclusie= " (sqs exclusie)
                 "\nWHERE zorgverlener="  (sqs zorgverlener)
                 "\n\t AND dag=" (sqs dag)";")]
           ;; time-exclusion exists, so this is an update.
          (debug lpf "update " timeExcl "  with query: " qry)
          (sql/do-commands qry))
      (do 
         (debug lpf "Add time-exclusion: "  timeExcl)
         (sql/insert-record qTbl timeExcl)))
     (invalidate-teCache)))  ;; could be an update instead

;;;;;;;;;;;;;;;;;;;;;;;;;; initialization code ;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn check-initialize-sms
  "This function assumes an open database connection and checks whether the
   sms-schema and the required databases are present. When not present
   the are created."
  []
  (vSql/check-create-schema Schema)
  (vSql/create-table Schema MsgTbl MsgFields false)
  (vSql/create-table Schema PtntTbl PtntFields false)
  (vSql/create-table Schema TagTbl TagFields false)
  (vSql/add-missing-rows Schema TagTbl :tag TagDefaults)
;;  (when (= (vSql/table-length Schema TagTbl) 0)
;;    (apply sql/insert-records (qsp Schema TagTbl) TagDefaults))
  (vSql/create-table Schema NoteTbl NoteFields false)
  (vSql/create-table Schema TimeExcludeTbl TimeExcludeFields false)
  (vSql/create-table Schema NameMapTbl NameMapFields false)
  (vSql/create-table Schema SettingsTbl SettingsFields false)
  (vSql/add-missing-rows Schema SettingsTbl :setting SettingsDefaults)
;;  (when (= (vSql/table-length Schema SettingsTbl) 0)
;;    (apply sql/insert-records (qsp Schema SettingsTbl) SettingsDefs))
  )

(def ONEBYONE false)

(defn add-messages [items]
  (let [qTbl (qsp Schema MsgTbl)]
    (if (> (count items) 0)
      (do 
        (debug "\nInserting " (count items) " in table " qTbl)
	(if ONEBYONE
          (doseq [r items]
             (println "INS: " r)
(def TMP_LAST r)
	     (sql/insert-record qTbl r))
          (do
            (println "items are (first 3): ")
            (prn (take 3 items))
            (apply sql/insert-records qTbl items))))
      (debug "No records to insert in " qTbl))))

(defn update-messages
  "Perform an update of the records using id as a key."
  [recs]
  (vSql/update-recs Schema MsgTbl :id recs))

(defn update-state-messages
   [msgs newState]
  (let [lpf "(update-state-messages): " ]
    (if (seq msgs)
      (let [ qry (str " UPDATE " (qsp Schema MsgTbl)
                    " SET st_state = " (sqs newState)
                    " WHERE id IN (" (str/join ", "  (map :id msgs)) ");")]
        (debug lpf "Run query: " qry)
        (sql/do-commands qry))
      (debug lpf " No records to update."))))


(defn check-deadline-messages 
  "Run a check on all messages to see whether some messages should be timed-out."
  []
  (let [lpf "(check-deadline-messages): " 
        qry (str "UPDATE " (qsp Schema MsgTbl)
                 " SET st_state = " (sqs STATE_TIMEOUT)
                 " WHERE st_state IN ( " (->> (map sqs [STATE_READY STATE_CONFIRM STATE_SUBMITTING STATE_ISSUE])
                                              (str/join ", ")) ")" 
                 " AND st_submit_deadline < Now();")
        ret (sql/do-commands qry)
        note (str "Er zijn " (first ret) " berichten gemarkeerd als " STATE_TIMEOUT)
        msg (str "update query: " qry "\n\treturned: " ret)]
    (when (> (first ret) 0)
      (add-note note))
    (println lpf msg)
    (debug lpf msg)))


(comment

(require '(clojure [string :as str]))
  ;;; read a file and split to tags
(defn pl [l] (-> (str "(^#[\\w]*)[\\s]*([\\w\\s.-:()" (char 8230) "]*)")
              (re-pattern )
              (re-find  l)
                   (#(sorted-map :tag (second %)
                               :format (get % 2)
                               :type  ST_NOTIF))))

(doseq [l (map pl (-> (slurp "tags") (str/split-lines)))] (prn l))

) ;; end comment

