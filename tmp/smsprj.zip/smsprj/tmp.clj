;; check this source
(println "\n loading core.typed")
  (load "clojure/core/typed")
(println "\n Checking matchRecs")
(load "vinzi/sms/matchRecs")
;; loading a source-file
(load-file "src/vinzi/sms/core.clj")
;;  or require a file from the classpath
(require 'vinzi.sms.core)

(in-ns 'vinzi.sms.core)
;; inserting shell-script parameters is easy.
(test-run "sagtest")
