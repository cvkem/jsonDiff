#!/bin/sh


REPOBASE="/tmp/smsprj"


CLASSPATH="${REPOBASE}/org/apache/ant/ant-launcher/1.7.0/ant-launcher-1.7.0.jar:\
${REPOBASE}/org/clojure/data.zip/0.1.1/data.zip-0.1.1.jar"

echo "CLASSPATH=${CLASSPATH}"
exit 1

SRCFOLDER="/tmp/smsprj/src"
# NOTE: create folders and add the files.


JVMOPTS=



# OPTION 2: RUN as flexible script (does not require a main)
#   (WARNING: do not start the script twice as the temporary scriptfile
#    will be overwritten!)
#
CSCRIPT=tmp.clj
PARAM=sagtest
cat >${CSCRIPT} <<EOL
;; check this source
echo
echo "Checking matchRecs"
(load "vinzi/sms/matchRecs")
;; loading a source-file
(load-file "src/vinzi/sms/core.clj")
;;  or require a file from the classpath
(requires 'vinzi.sms.core)

(in-ns 'vinzi.sms.core)
;; inserting shell-script parameters is easy.
(test-run ${PARAM})
EOL

echo "executing:"
echo "java ${JVMOPTS} -cp ${SRCFOLDER}:${CLASSPATH} clojure.main - < ${CSCRIPT}"
java ${JVMOPTS} -cp ${SRCFOLDER}:${CLASSPATH} clojure.main - < ${CSCRIPT}
#rm ${CSCRIPT}
